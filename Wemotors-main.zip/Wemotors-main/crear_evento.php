<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Evento</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-white m-0 p-0 ">

    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="w-100 border border-black border-2 border-opacity-75" style="max-width: 600px;">
          <form class="p-4 shadow rounded-3 bg-light">
            <h2 class="text-center mb-4">Crear Evento</h2>
            <div id="errorMessage" class="alert alert-danger d-none"></div>
            
            <div class="mb-3">
                <label for="fotoEvento" class="form-label">Logo de evento</label>
                <input class="form-control" type="file" id="fotoEvento">
            </div>
            <div class="mb-3">
                <label for="nombreEvento" class="form-label">Nombre del evento</label>
                <input type="text" class="form-control" id="nombreEvento" placeholder="" required>
            </div>

            <div class="mb-3">
                <label for="descripcionEvento" class="form-label">Descripción</label>
                <textarea class="form-control" id="descripcionEvento" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="LugarEvento" class="form-label">Lugar del evento</label>
                <input type="text" class="form-control" id="LugarEvento" placeholder="Villarejo - Madrid" required>
            </div>
            <div class="mb-3">
                <label for="HoraEvento" class="form-label">Fecha y Hora del evento</label>
                <input type="datetime-local" class="form-control" id="HoraEvento" min="<?php echo date('Y-m-d\TH:i'); ?>" required>
            </div>
            
            <!-- Nuevos campos para filtros -->
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="aplicarFiltro">
                <label class="form-check-label" for="aplicarFiltro">Aplicar filtros de vehículos</label>
            </div>
            
            <div id="filtrosContainer" class="border p-3 mb-3 rounded" style="display: none;">
                <div class="mb-3">
                    <label for="marcaEvento" class="form-label">Marca</label>
                    <select class="form-select" id="marcaEvento" size="5">
                        <option value="" selected disabled>Selecciona una marca</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="modeloEvento" class="form-label">Modelo (opcional)</label>
                    <select class="form-select" id="modeloEvento" disabled>
                        <option value="" selected disabled>Primero selecciona una marca</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="tipoVehiculo" class="form-label">Tipo de vehículo (opcional)</label>
                    <select class="form-select" id="tipoVehiculo" size="5">
                        <option value="" selected disabled>Selecciona un tipo</option>
                        <?php
                        require_once 'php/funciones.php';
                        try {
                            $sql = "SELECT idTipo, TipoNombre FROM tipovehiculo ORDER BY TipoNombre";
                            $stmt = $pdo->query($sql);
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $row['idTipo'] . '">' . htmlspecialchars($row['TipoNombre']) . '</option>';
                            }
                        } catch (PDOException $e) {
                            error_log('Error al cargar tipos de vehículo: ' . $e->getMessage());
                        }
                        ?>
                    </select>
                </div>
            </div>
            
            <div class="d-grid gap-2">
              <button type="submit" id="CrearEvento" class="btn btn-primary">Crear evento</button>
            </div>
            
            <div class="text-center mt-3">
                <a href="eventos.php" class="text-decoration-none">Volver</a>
            </div>
          </form>
        </div>
    </div>
    <script src="javaScript/crear_eventos.js"></script>
</body>
</html>