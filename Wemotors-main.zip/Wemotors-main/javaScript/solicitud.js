// Función para cargar el perfil (manteniendo tu estructura)
function cargarPerfil() {
    var xmlhttp = new XMLHttpRequest();
    
    xmlhttp.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200) {
            document.getElementById("Perfil").innerHTML = this.responseText;
        } else if(this.readyState == 4) {
            document.getElementById("Perfil").innerHTML = "<div class='alert alert-danger'>Error al cargar el perfil</div>";
        }
    };
    
    var userId = new URLSearchParams(window.location.search).get('id') || '';
    var url = "php/funciones.php?accion=perfil" + (userId ? "&id=" + userId : "");
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

// Función para detectar si estamos en móvil
function isMobile() {
    return window.innerWidth <= 768;
}

// Función para manejar solicitudes de seguimiento
function manejarSolicitudes() {
    // Manejar clic en el enlace de solicitudes
    const solicitudesLink = document.querySelector('.dropdown-submenu > .dropdown-item');
    
    if (solicitudesLink) {
        solicitudesLink.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const submenu = this.nextElementSibling;
            const submenuParent = this.parentElement;
            const isVisible = submenu.style.display === 'block';
            
            if (isMobile()) {
                // Comportamiento para móviles
                
                // Cerrar todos los otros submenús
                document.querySelectorAll('.dropdown-submenu').forEach(otherSubmenu => {
                    if (otherSubmenu !== submenuParent) {
                        otherSubmenu.classList.remove('show');
                        const otherMenu = otherSubmenu.querySelector('.dropdown-menu');
                        if (otherMenu) {
                            otherMenu.style.display = 'none';
                        }
                        const otherToggle = otherSubmenu.querySelector('.dropdown-toggle');
                        if (otherToggle) {
                            otherToggle.setAttribute('aria-expanded', 'false');
                        }
                    }
                });
                
                // Alternar este submenú
                if (isVisible) {
                    submenu.style.display = 'none';
                    submenuParent.classList.remove('show');
                    this.setAttribute('aria-expanded', 'false');
                } else {
                    submenu.style.display = 'block';
                    submenuParent.classList.add('show');
                    this.setAttribute('aria-expanded', 'true');
                }
            } else {
                // Comportamiento para escritorio (original)
                
                // Cerrar todos los submenús primero
                document.querySelectorAll('.dropdown-submenu .dropdown-menu').forEach(menu => {
                    menu.style.display = 'none';
                });
                
                // Abrir/cerrar este submenú
                submenu.style.display = isVisible ? 'none' : 'block';
            }
        });
    }
}

// Función para procesar la solicitud
function procesarSolicitud(idSeguidor, accion) {
    var xmlhttp = new XMLHttpRequest();
    
    xmlhttp.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200) {
            var response = JSON.parse(this.responseText);
            if(response.success) {
                // Actualizar la lista de solicitudes
                actualizarListaSolicitudes();
                
                // Actualizar notificación (bola roja)
                var badge = document.getElementById('notificacionSolicitudes');
                if (badge) {
                    badge.style.display = response.pendientes ? 'block' : 'none';
                }
                
                // Si fue aceptación, actualizar contador de seguidores
                if(accion === 'aceptar') {
                    actualizarContadorSeguidores();
                }
            }
        }
    };
    
    var url = "php/funciones.php?accion=manejarSolicitud&idSeguidor=" + idSeguidor + "&tipo=" + accion;
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

// Función para actualizar la lista de solicitudes
function actualizarListaSolicitudes() {
    var xmlhttp = new XMLHttpRequest();
    
    xmlhttp.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200) {
            document.getElementById("listaSolicitudes").innerHTML = this.responseText;
            
            // Verificar si hay solicitudes para la bola roja
            var tienePendientes = document.querySelectorAll('.solicitud-item').length > 0;
            var badge = document.getElementById('notificacionSolicitudes');
            if (badge) {
                badge.style.display = tienePendientes ? 'block' : 'none';
            }
            
            // Reasignar eventos
            manejarSolicitudes();
        } else if(this.readyState == 4) {
            document.getElementById("listaSolicitudes").innerHTML = "<li><span class='dropdown-item text-danger'>Error cargando solicitudes</span></li>";
        }
    };
    
    xmlhttp.open("GET", "php/funciones.php?accion=obtenerHtmlSolicitudes", true);
    xmlhttp.send();
}

// Función para actualizar el contador de seguidores
function actualizarContadorSeguidores() {
    // Obtener el ID de usuario del perfil actual
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');
    
    if (!userId) return;

    // Actualizar el contador via AJAX
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            const data = JSON.parse(this.responseText);
            const contador = document.getElementById('contadorSeguidores');
            if (contador) {
                contador.textContent = data.seguidores;
            }
        }
    };
    xmlhttp.open("GET", "php/funciones.php?accion=obtenerSeguidores&id=" + userId, true);
    xmlhttp.send();
}

// Inicialización al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    // Iniciar funcionalidades
    cargarPerfil();
    manejarSolicitudes();
    
    // Verificar notificaciones cada 30 segundos
    setInterval(actualizarListaSolicitudes, 30000);
    
    // Manejar redimensionamiento de ventana
    window.addEventListener('resize', function() {
        // Cerrar submenús al cambiar de tamaño
        document.querySelectorAll('.dropdown-submenu .dropdown-menu').forEach(menu => {
            menu.style.display = 'none';
        });
        document.querySelectorAll('.dropdown-submenu').forEach(submenu => {
            submenu.classList.remove('show');
            const toggle = submenu.querySelector('.dropdown-toggle');
            if (toggle) {
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    });
});

// Event listener para botones de solicitudes
document.getElementById('listaSolicitudes')?.addEventListener('click', function(e) {
    const btn = e.target.closest('.aceptar-btn, .rechazar-btn');
    if (!btn) return;

    const idSeguidor = btn.getAttribute('data-id');
    const esAceptar = btn.classList.contains('aceptar-btn');
    
    procesarSolicitud(idSeguidor, esAceptar ? 'aceptar' : 'rechazar');
});

// Mejorado: cerrar el menú al hacer clic fuera
document.addEventListener('click', function(e) {
    // No cerrar si el clic fue dentro del dropdown o en el botón de solicitudes
    if (!e.target.closest('.dropdown-submenu') && !e.target.closest('#dropdownMenuButton')) {
        document.querySelectorAll('.dropdown-submenu .dropdown-menu').forEach(menu => {
            menu.style.display = 'none';
        });
        document.querySelectorAll('.dropdown-submenu').forEach(submenu => {
            submenu.classList.remove('show');
            const toggle = submenu.querySelector('.dropdown-toggle');
            if (toggle) {
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }
});