document.addEventListener('DOMContentLoaded', function() {
    // Cargar datos actuales del usuario al abrir el modal
    const editarPerfilModal = document.getElementById('editarPerfilModal');
    if (editarPerfilModal) {
        editarPerfilModal.addEventListener('show.bs.modal', function() {
            cargarDatosUsuario();
            cargarPublicacionesUsuario();
        });
        
        // Manejar cambio de pestañas
        const publicacionesTab = document.getElementById('publicaciones-tab');
        if (publicacionesTab) {
            publicacionesTab.addEventListener('click', function() {
                cargarPublicacionesUsuario();
            });
        }
    }

    // Manejar el envío del formulario de edición
    const formEditarPerfil = document.getElementById('formEditarPerfil');
    if (formEditarPerfil) {
        formEditarPerfil.addEventListener('submit', function(e) {
            e.preventDefault();
            guardarCambiosPerfil();
        });
    }

    // Manejar el botón de eliminar cuenta
    const btnEliminarCuenta = document.getElementById('btnEliminarCuenta');
    if (btnEliminarCuenta) {
        btnEliminarCuenta.addEventListener('click', function() {
            const confirmarModal = new bootstrap.Modal(document.getElementById('confirmarEliminarModal'));
            confirmarModal.show();
        });
    }

    // Confirmar eliminación de cuenta
    const confirmarEliminar = document.getElementById('confirmarEliminar');
    if (confirmarEliminar) {
        confirmarEliminar.addEventListener('click', function() {
            eliminarCuenta();
        });
    }
});

function cargarDatosUsuario() {
    fetch('php/funciones.php?accion=obtenerDatosUsuario')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('editNick').value = data.usuario.Nick;
                document.getElementById('editDescripcion').value = data.usuario.Descripcion || '';
                document.getElementById('editPrivada').checked = data.usuario.privada == 1;
            } else {
                mostrarError(data.message || 'Error al cargar datos del usuario');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarError('Error al conectar con el servidor');
        });
}
function cargarPublicacionesUsuario() {
    fetch('./php/funciones.php?accion=obtenerPublicacionesUsuario')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json().catch(() => {
                throw new Error('Respuesta no es JSON válido');
            });
        })
        .then(data => {
            if (!data.success) {
                throw new Error(data.message || 'Error al cargar publicaciones');
            }
            
            const listaPublicaciones = document.getElementById('listaPublicaciones');
            listaPublicaciones.innerHTML = '';
            
            if (data.publicaciones && data.publicaciones.length > 0) {
             
                data.publicaciones.forEach(publicacion => {
                    const publicacionElement = document.createElement('div');
                    publicacionElement.className = 'col-md-4 mb-3';
                    publicacionElement.innerHTML = `
                        <div class="card h-100">
                            <img src="${publicacion.Foto ? 'data:image/jpeg;base64,' + publicacion.Foto : 'img/default-post.jpg'}" 
                                class="card-img-top" 
                                style="height: 150px; object-fit: cover;">
                            <div class="card-body">
                                <p class="card-text">${publicacion.DescripcionPubli || 'Sin descripción'}</p>
                                <div class="d-flex justify-content-between">
                                    <small class="text-muted">${new Date(publicacion.fecPublicacion).toLocaleDateString()}</small>
                                    <div>
                                        <button class="btn btn-sm btn-outline-primary editar-publicacion" 
                                                data-id="${publicacion.idPubli}">
                                            <i class="bi bi-pencil"></i> Editar
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger eliminar-publicacion" 
                                                data-id="${publicacion.idPubli}">
                                            <i class="bi bi-trash"></i> Borrar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    listaPublicaciones.appendChild(publicacionElement);
                });
                
                // Agregar eventos a los botones
                document.querySelectorAll('.editar-publicacion').forEach(btn => {
                    btn.addEventListener('click', function() {
                        editarPublicacion(this.dataset.id);
                    });
                });
                
                document.querySelectorAll('.eliminar-publicacion').forEach(btn => {
                    btn.addEventListener('click', function() {
                        eliminarPublicacion(this.dataset.id);
                    });
                });
            } else {
                listaPublicaciones.innerHTML = '<div class="col-12 text-center py-4">No hay publicaciones</div>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const listaPublicaciones = document.getElementById('listaPublicaciones');
            listaPublicaciones.innerHTML = `
                <div class="col-12 text-center py-4 text-danger">
                    Error al cargar publicaciones: ${error.message}
                </div>`;
        });
}

function editarPublicacion(idPublicacion) {
    // Implementar lógica para editar publicación
    // Puedes abrir otro modal con el formulario de edición
    mostrarExito(`Editar publicación ${idPublicacion}`);
}

function eliminarPublicacion(idPublicacion) {
    if (!confirm('¿Estás seguro de que quieres eliminar esta publicación?')) {
        return;
    }
    
    fetch('php/funciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accionP=eliminarPublicacion&idPublicacion=${idPublicacion}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Publicación eliminada correctamente');
            cargarPublicacionesUsuario();
        } else {
            mostrarError(data.message || 'Error al eliminar la publicación');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}

function guardarCambiosPerfil() {
    const formData = new FormData(document.getElementById('formEditarPerfil'));
    formData.append('accionP', 'actualizarPerfil');

    fetch('php/funciones.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Perfil actualizado correctamente');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarError(data.message || 'Error al actualizar el perfil');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}

function eliminarCuenta() {
    const password = document.getElementById('confirmPassword').value;
    if (!password) {
        mostrarError('Por favor ingresa tu contraseña');
        return;
    }

    fetch('php/funciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accionP=eliminarCuenta&password=${encodeURIComponent(password)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Cuenta eliminada correctamente');
            setTimeout(() => window.location.href = 'pagina_entrada.php', 1500);
        } else {
            mostrarError(data.message || 'Error al eliminar la cuenta');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}

function mostrarExito(mensaje) {
    // Puedes reemplazar esto con Toast o SweetAlert
    const toast = document.createElement('div');
    toast.className = 'position-fixed bottom-0 end-0 p-3';
    toast.innerHTML = `
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <strong class="me-auto">Éxito</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${mensaje}
            </div>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function mostrarError(mensaje) {
    // Puedes reemplazar esto con Toast o SweetAlert
    const toast = document.createElement('div');
    toast.className = 'position-fixed bottom-0 end-0 p-3';
    toast.innerHTML = `
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-danger text-white">
                <strong class="me-auto">Error</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${mensaje}
            </div>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);

}

function editarPublicacion(idPublicacion) {
    // Crear modal de edición dinámicamente
    const modalHTML = `
        <div class="modal fade" id="editarPublicacionModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title">Editar Publicación</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <img id="publicacionImagen" src="" class="img-fluid rounded" style="max-height: 300px; object-fit: cover;">
                            </div>
                            <div class="col-md-6">
                                <form id="formEditarPublicacion">
                                    <input type="hidden" name="idPublicacion" value="${idPublicacion}">
                                    <div class="mb-3">
                                        <label for="editDescripcionPubli" class="form-label">Descripción</label>
                                        <textarea class="form-control" id="editDescripcionPubli" name="editDescripcionPubli" rows="3"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Comentarios</label>
                                        <div id="listaComentarios" class="mb-3" style="max-height: 200px; overflow-y: auto;"></div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" id="btnEliminarComentarios">
                           Eliminar Comentarios
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardarPublicacion">Guardar Cambios</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Agregar el modal al DOM
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Cargar datos de la publicación
    fetch(`php/funciones.php?accion=obtenerPublicacion&idPubli=${idPublicacion}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modal = new bootstrap.Modal(document.getElementById('editarPublicacionModal'));
                const imgElement = document.getElementById('publicacionImagen');
                const descElement = document.getElementById('editDescripcionPubli');
                
                // Mostrar imagen
                if (data.publicacion.Foto) {
                    imgElement.src = 'data:image/jpeg;base64,' + data.publicacion.Foto;
                } else {
                    imgElement.src = 'img/default-post.jpg';
                }
                
                // Mostrar descripción
                descElement.value = data.publicacion.DescripcionPubli || '';
                
                // Cargar comentarios
                cargarComentariosPublicacion(idPublicacion);
                
                // Mostrar modal
                modal.show();
                
                // Configurar eventos
                document.getElementById('btnGuardarPublicacion').addEventListener('click', () => {
                    guardarCambiosPublicacion(idPublicacion);
                });

               document.querySelectorAll('.btn-eliminar-comentario').forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        const idComentario = this.closest('.comment-card').getAttribute('data-id');
                        eliminarComentario(idComentario, idPublicacion, e);
                    });
                });
                
                document.getElementById('btnEliminarComentarios').addEventListener('click', () => {
                    if (confirm('¿Estás seguro de que quieres eliminar todos los comentarios de esta publicación?')) {
                        eliminarTodosComentarios(idPublicacion);
                    }
                });
                
                // Eliminar el modal cuando se cierre
                document.getElementById('editarPublicacionModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
            } else {
                mostrarError(data.message || 'Error al cargar la publicación');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarError('Error al conectar con el servidor');
        });
}

function cargarComentariosPublicacion(idPublicacion) {
    fetch(`php/funciones.php?accion=obtener_comentarios&idPubli=${idPublicacion}`)
        .then(response => response.json())
        .then(data => {
            const listaComentarios = document.getElementById('listaComentarios');
            listaComentarios.innerHTML = '';
            
            if (data.success && data.html) {
                listaComentarios.innerHTML = data.html;
                
                // Agregar botones de eliminar a cada comentario
                document.querySelectorAll('.comment-card').forEach(card => {
                    const btnEliminar = document.createElement('button');
                    btnEliminar.className = 'btn btn-sm btn-outline-danger btn-eliminar-comentario ms-2';
                    btnEliminar.innerHTML = '<i class="bi bi-trash"></i>  Eliminar';
                    btnEliminar.style.float = 'right';
                    
                    // Agregar el botón al card-body del comentario
                    const cardBody = card.querySelector('.card-body');
                    if (cardBody) {
                        // Verificar si ya existe un botón de eliminar
                        const existingBtn = cardBody.querySelector('.btn-eliminar-comentario');
                        if (!existingBtn) {
                            cardBody.appendChild(btnEliminar);
                        }
                    }
                });

                // Asignar eventos a los botones de eliminar
                document.querySelectorAll('.btn-eliminar-comentario').forEach(btn => {
                    btn.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        const idComentario = this.closest('.comment-card').getAttribute('data-id');
                        if (idComentario) {
                            eliminarComentario(idComentario, idPublicacion);
                        }
                    });
                });
            } else {
                listaComentarios.innerHTML = '<div class="text-muted">No hay comentarios</div>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('listaComentarios').innerHTML = '<div class="text-danger">Error al cargar comentarios</div>';
        });
}

function guardarCambiosPublicacion(idPublicacion) {
    const descripcion = document.getElementById('editDescripcionPubli').value;
    
    fetch('php/funciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accionP=actualizarPublicacion&idPublicacion=${idPublicacion}&descripcion=${encodeURIComponent(descripcion)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Publicación actualizada correctamente');
            document.getElementById('editarPublicacionModal').querySelector('.btn-close').click();
            cargarPublicacionesUsuario();
        } else {
            mostrarError(data.message || 'Error al actualizar la publicación');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}

function eliminarComentario(idComentario, idPublicacion) {
    if (!confirm('¿Estás seguro de que quieres eliminar este comentario?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('accionP', 'eliminarComentario');
    formData.append('idComentario', idComentario);
    
    fetch('php/funciones.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Comentario eliminado correctamente');
            // Recargar los comentarios sin cerrar el modal
            cargarComentariosPublicacion(idPublicacion);
        } else {
            mostrarError(data.message || 'Error al eliminar el comentario');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}


function eliminarTodosComentarios(idPublicacion) {
    if (!confirm('¿Estás seguro de que quieres eliminar TODOS los comentarios de esta publicación?')) {
        return;
    }
    
    fetch('php/funciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accionP=eliminarTodosComentarios&idPublicacion=${idPublicacion}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Todos los comentarios han sido eliminados');
            cargarComentariosPublicacion(idPublicacion);
        } else {
            mostrarError(data.message || 'Error al eliminar los comentarios');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al conectar con el servidor');
    });
}

// vehiculos.js
document.addEventListener('DOMContentLoaded', function() {
    // Cargar vehículos cuando se muestra la pestaña
    const vehiculosTab = document.getElementById('vehiculos-tab');
    if (vehiculosTab) {
        vehiculosTab.addEventListener('shown.bs.tab', function() {
            cargarVehiculos();
        });
    }
    
    // Confirmar eliminación de vehículo
    const btnConfirmarEliminarVehiculo = document.getElementById('btnConfirmarEliminarVehiculo');
    if (btnConfirmarEliminarVehiculo) {
        btnConfirmarEliminarVehiculo.addEventListener('click', function() {
            eliminarVehiculo();
        });
    }
});

function mostrarConfirmacionEliminar(idVehiculo) {
    document.getElementById('idVehiculoEliminar').value = idVehiculo;
    const modal = new bootstrap.Modal(document.getElementById('confirmarEliminarVehiculoModal'));
    modal.show();
}

function cargarVehiculos() {
    fetch('php/funciones.php?accion=obtenerVehiculosUsuario')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarVehiculos(data.vehiculos);
            } else {
                mostrarError(data.message || 'Error al cargar vehículos');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarError('Error al conectar con el servidor');
        });
}

function mostrarVehiculos(vehiculos) {
    const listaVehiculos = document.getElementById('listaVehiculos');
    listaVehiculos.innerHTML = '';
    
    if (vehiculos.length === 0) {
        listaVehiculos.innerHTML = `
            <div class="col-12 text-center py-4">
                <p>No tienes vehículos registrados</p>
            </div>
        `;
        return;
    }
    
    vehiculos.forEach(vehiculo => {
        const fotoSrc = vehiculo.FotoCoche ? 
            `data:image/jpeg;base64,${vehiculo.FotoCoche}` : 
            'img/default-car.png';
        
        const vehiculoCard = document.createElement('div');
        vehiculoCard.className = 'col-12 col-md-6 col-lg-4 mb-3';
        vehiculoCard.innerHTML = `
            <div class="vehiculo-card">
                <img src="${fotoSrc}" class="vehiculo-img" alt="Vehículo">
                <h6>${vehiculo.marcaNombre || 'Marca no especificada'}</h6>
                <p class="mb-1">${vehiculo.modeloNombre || 'Modelo no especificado'}</p>
                <p class="text-muted">Año: ${vehiculo.Agno || 'No especificado'}</p>
                <p>
                <button class="btn btn-danger btn-sm btn-eliminar-vehiculo" 
                        data-id="${vehiculo.idVehiculo}">Eliminar
                </button></p>
            </div>
        `;
        
        // Agregar evento de clic al botón de eliminar
        const btnEliminar = vehiculoCard.querySelector('.btn-eliminar-vehiculo');
        btnEliminar.addEventListener('click', function(e) {
            e.preventDefault();
            mostrarConfirmacionEliminar(vehiculo.idVehiculo);
        });
        
        listaVehiculos.appendChild(vehiculoCard);
    });
}

function eliminarVehiculo() {
    const idVehiculo = document.getElementById('idVehiculoEliminar').value;
    
    fetch('php/funciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `accionP=eliminarVehiculo&idVehiculo=${idVehiculo}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarExito('Vehículo eliminado correctamente');
            cargarVehiculos();
            const modal = bootstrap.Modal.getInstance(document.getElementById('confirmarEliminarVehiculoModal'));
            modal.hide();
        } else {
            mostrarError(data.message || 'Error al eliminar vehículo');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarError('Error al eliminar vehículo');
    });
}