document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('like-btn')) {
            const corazon = e.target;
            const contador = corazon.nextElementSibling;
            const idPubli = corazon.getAttribute('data-publi-id');
            const yaDioLike = corazon.classList.contains('bi-heart-fill');
            
            // Verificar si el usuario está autenticado antes de hacer la petición
            if (!document.querySelector('#userDropdown').contains(document.querySelector('a[href="inicio_sesion.php"]'))) {
                const accion = yaDioLike ? 'quitar_like' : 'dar_like';
                
                const xhr = new XMLHttpRequest();
                xhr.open('POST', `./php/funciones.php?accion=${accion}&idPubli=${encodeURIComponent(idPubli)}`, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                xhr.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        try {
                            const response = JSON.parse(this.responseText);
                            if (response.success) {
                                if (accion === 'dar_like') {
                                    corazon.classList.replace('bi-heart', 'bi-heart-fill');
                                    corazon.classList.add('text-danger');
                                } else {
                                    corazon.classList.replace('bi-heart-fill', 'bi-heart');
                                    corazon.classList.remove('text-danger');
                                }
                                contador.textContent = response.nuevoConteo;
                            } else {
                                if (response.unauthenticated) {
                                    window.location.href = 'inicio_sesion.php';
                                } else {
                                    alert(response.error);
                                }
                            }
                        } catch (e) {
                            console.error('Error:', e);
                            alert('Error procesando respuesta');
                        }
                    }
                };
                
                xhr.send(`accion=${accion}&idPubli=${encodeURIComponent(idPubli)}`);
            } else {
                window.location.href = 'inicio_sesion.php';
            }
        }
    });
});