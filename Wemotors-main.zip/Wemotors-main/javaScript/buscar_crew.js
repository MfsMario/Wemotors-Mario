
document.addEventListener('DOMContentLoaded', function() {
    const crewSearch = document.getElementById("crewSearch");
    const crewResults = document.getElementById("crewResults");
    const searchCrewForm = document.getElementById("searchEventForm");
    const crewsContainer = document.getElementById("iddivCrews");
    
    function mostrarCrews() {
        const texto = crewSearch.value.trim();
        
        if(texto !== "") {
            fetch(`./php/funciones.php?accion=BuscCrew&texto=${encodeURIComponent(texto)}`)
                .then(response => response.text())
                .then(data => {
                    crewResults.innerHTML = data;
                    crewResults.classList.remove("d-none");
                })
                .catch(error => console.error('Error:', error));
        } else {
            crewResults.innerHTML = "";
            crewResults.classList.add("d-none");
        }
    }
    
    function listarCrews() {
        const searchTerm = crewSearch.value.trim();
        
        fetch(`./php/funciones.php?accion=listcrews&search=${encodeURIComponent(searchTerm)}`)
            .then(response => response.text())
            .then(data => {
                crewsContainer.innerHTML = data;
                crewResults.classList.add("d-none");
            })
            .catch(error => console.error('Error:', error));
    }
    
    crewSearch.addEventListener("keyup", mostrarCrews);
    
    crewResults.addEventListener('click', function(e) {
        if(e.target.tagName === 'A') {
            e.preventDefault();
            crewSearch.value = e.target.textContent.trim();
            crewResults.classList.add("d-none");
        }
    });
    
    document.addEventListener('click', function(e) {
        if (!e.target.closest('#eventSearch') && !e.target.closest('#eventResults')) {
            crewResults.classList.add("d-none");
        }
    });
    
    searchCrewForm.addEventListener('submit', function(e) {
        e.preventDefault();
        listarCrews();
    });
});