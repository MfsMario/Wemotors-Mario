document.getElementById('btnRegistro').addEventListener('click', function() {
    const nombre = document.getElementById("nombre").value.trim();
    const apellidos = document.getElementById("apellidos").value.trim();
    const nick = document.getElementById("nick").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;
    const fotoInput = document.getElementById("foto");
    const errorMessage = document.getElementById("errorMessage");
    const cuentaPrivada = document.getElementById("cuentaPrivada").checked;
    
    errorMessage.classList.add("d-none");
    document.getElementById("passwordError").classList.add("d-none");
    
    if (!nombre || !apellidos || !nick || !email || !password || !confirmPassword) {
        showError("Todos los campos marcados con * son obligatorios");
        return;
    }
    
    if (password !== confirmPassword) {
        document.getElementById("passwordError").classList.remove("d-none");
        return;
    }
    
    if (password.length < 6) {
        showError("La contraseña debe tener al menos 6 caracteres");
        return;
    }
    
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showError("Por favor, introduce un email válido");
        return;
    }
    
    // Validar foto antes de continuar
    if (fotoInput.files.length > 0) {
        const file = fotoInput.files[0];
        
        if (file.size > 2097152) { // 2MB
            showError("La imagen no debe superar los 2MB");
            return;
        }
        
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!allowedTypes.includes(file.type)) {
            showError("Solo se permiten imágenes JPEG, PNG o GIF");
            return;
        }
    }
    
    // NUEVA VALIDACIÓN: Verificar si el email o nick ya existen ANTES de enviar el correo
    validarEmailYNick(email, nick, function(esValido, mensaje) {
        if (!esValido) {
            showError(mensaje);
            return;
        }
        
        // Si la validación es exitosa, proceder con el registro
        procederConRegistro(nombre, apellidos, nick, email, password, cuentaPrivada, fotoInput);
    });
});

function validarEmailYNick(email, nick, callback) {
    const formData = new FormData();
    formData.append("accionP", "validarEmailYNick");
    formData.append("email", email);
    formData.append("nick", nick);
    
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "php/funciones.php", true);
    
    xhr.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            try {
                const response = JSON.parse(this.responseText);
                callback(response.success, response.message);
            } catch (e) {
                callback(false, "Error al procesar la respuesta del servidor");
            }
        }
    };
    
    xhr.send(formData);
}

function procederConRegistro(nombre, apellidos, nick, email, password, cuentaPrivada, fotoInput) {
    // Generar código de verificación
    const codigoVerificacion = generarCodigo();
    
    // Guardar datos en sessionStorage temporalmente (sin la foto)
    const datosUsuario = {
        nombre,
        apellidos,
        nick,
        email,
        password,
        cuentaPrivada: cuentaPrivada ? "1" : "0",
        codigoVerificacion,
        timestamp: Date.now()
    };

    sessionStorage.setItem('datosRegistro', JSON.stringify(datosUsuario));
    
    // Convertir la foto a base64 si existe para poder almacenarla
    if (fotoInput.files.length > 0) {
        const file = fotoInput.files[0];
        
        const reader = new FileReader();
        reader.onload = function(e) {
            // Guardar la foto en base64 en sessionStorage
            datosUsuario.fotoBase64 = e.target.result;
            datosUsuario.fotoName = file.name;
            datosUsuario.fotoType = file.type;
            sessionStorage.setItem('datosRegistro', JSON.stringify(datosUsuario));
            
            // Enviar código de verificación
            enviarCodigoVerificacion(email, codigoVerificacion);
        };
        reader.readAsDataURL(file);
    } else {
        // Sin foto, enviar código directamente
        enviarCodigoVerificacion(email, codigoVerificacion);
    }
}

function enviarCodigoVerificacion(email, codigo) {
    const formData = new FormData();
    formData.append("accionP", "enviarCodigoVerificacion");
    formData.append("email", email);
    formData.append("codigo", codigo);
    
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "php/funciones.php", true);
    
    xhr.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            try {
                const response = JSON.parse(this.responseText);
                if (response.success) {
                    window.location.href = "verificar_codigo.php";
                } else {
                    showError(response.message);
                }
            } catch (e) {
                showError("Error al procesar la respuesta del servidor");
            }
        }
    };
    
    xhr.send(formData);
}

function generarCodigo() {
    const letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numeros = '0123456789';
    let codigo = '';
    
    // 3 letras aleatorias
    for (let i = 0; i < 3; i++) {
        codigo += letras.charAt(Math.floor(Math.random() * letras.length));
    }
    
    // 3 números aleatorios
    for (let i = 0; i < 3; i++) {
        codigo += numeros.charAt(Math.floor(Math.random() * numeros.length));
    }
    
    return codigo;
}

function showError(message) {
    const errorMessage = document.getElementById("errorMessage");
    errorMessage.textContent = message;
    errorMessage.classList.remove("d-none");
}

document.querySelectorAll('.password-toggle').forEach(toggle => {
    toggle.addEventListener('click', function() {
        const input = this.closest('.input-group').querySelector('input');
        const icon = this.querySelector('i');
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        } else {
            input.type = 'password';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        }
    });
});

document.getElementById("confirm_password").addEventListener("input", function() {
    const password = document.getElementById("password").value;
    const confirmPassword = this.value;
    const errorElement = document.getElementById("passwordError");
    
    if (password && confirmPassword && password !== confirmPassword) {
        errorElement.classList.remove("d-none");
    } else {
        errorElement.classList.add("d-none");
    }
});