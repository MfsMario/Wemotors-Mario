function verContraseña() {
    const passwordInput = document.getElementById('Password');
    const passwordIcon = document.getElementById('passwordIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        passwordIcon.classList.remove('bi-eye');
        passwordIcon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        passwordIcon.classList.remove('bi-eye-slash');
        passwordIcon.classList.add('bi-eye');
    }
}

function IniciarSesion() {
    const email = document.getElementById('emailusu').value;
    const contraseña = document.getElementById('Password').value;
    const errorMessage = document.getElementById('errorMessage');
    
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            const capa = this.responseText;

            if (capa !== "") {
                const verificarAdmin = new XMLHttpRequest();
                verificarAdmin.onreadystatechange = function() {
                    if (this.readyState === 4 && this.status === 200) {
                        const esAdmin = JSON.parse(this.responseText).admin;
                        if (esAdmin) {
                            window.location.href = "admin/panel_admin.php";
                        } else {
                            window.location.href = "inicio.php?nom=" + capa;
                        }
                    }
                };
                verificarAdmin.open("GET", "php/funciones.php?accion=verificarAdmin");
                verificarAdmin.send();
            } else {
                document.getElementById('Password').value="";
                errorMessage.style.display = 'block';
            }
        }
    };
    xmlhttp.open("GET", "php/funciones.php?accion=login&Nick=" + email + "&contra=" + contraseña);
    xmlhttp.send();
}