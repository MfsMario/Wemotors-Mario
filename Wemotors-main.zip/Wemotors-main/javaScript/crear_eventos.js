document.addEventListener('DOMContentLoaded', function() {
    const crearEventoBtn = document.getElementById("CrearEvento");
    const aplicarFiltroCheckbox = document.getElementById("aplicarFiltro");
    const filtrosContainer = document.getElementById("filtrosContainer");
    const marcaSelect = document.getElementById("marcaEvento");
    const modeloSelect = document.getElementById("modeloEvento");
    const tipoVehiculoSelect = document.getElementById("tipoVehiculo");

    // Cargar marcas al iniciar
    cargarMarcas();

    // Mostrar/ocultar filtros según checkbox
    aplicarFiltroCheckbox.addEventListener('change', function() {
        filtrosContainer.style.display = this.checked ? 'block' : 'none';
    });

    // Cargar modelos cuando se selecciona una marca
    marcaSelect.addEventListener('change', function() {
        const idMarca = this.value;
        if (idMarca) {
            cargarModelos(idMarca);
            modeloSelect.disabled = false;
        } else {
            modeloSelect.innerHTML = '<option value="" selected disabled>Primero selecciona una marca</option>';
            modeloSelect.disabled = true;
        }
    });

    crearEventoBtn.addEventListener('click', function(e) {
        e.preventDefault();

        const fotoEvento = document.getElementById("fotoEvento");
        const Nombre = document.getElementById("nombreEvento").value.trim();
        const descripcion = document.getElementById("descripcionEvento").value.trim();
        const lugar = document.getElementById("LugarEvento").value.trim();
        const fechaInput = document.getElementById("HoraEvento");
        const fechaValue = fechaInput.value;
        const aplicarFiltro = aplicarFiltroCheckbox.checked;
        const idMarca = aplicarFiltro ? marcaSelect.value : null;
        const idModelo = aplicarFiltro && modeloSelect.value ? modeloSelect.value : null;
        const idTipo = aplicarFiltro && tipoVehiculoSelect.value ? tipoVehiculoSelect.value : null;

        if (!Nombre || !descripcion || !lugar || !fechaValue) {
            showError("Todos los campos marcados con * son obligatorios");
            return;
        }

        const fechaEvento = new Date(fechaValue);
        const fechaActual = new Date();
        
        if (isNaN(fechaEvento.getTime())) {
            showError("La fecha y hora seleccionada no es válida");
            return;
        }

        if (fechaEvento < fechaActual) {
            showError("No puedes crear un evento con fecha pasada");
            return;
        }

        const formData = new FormData();
        formData.append("accionP", "CrearEvento");
        formData.append("nomb", Nombre);
        formData.append("desc", descripcion);
        formData.append("lugar", lugar);
        formData.append("fecha", fechaValue);
        formData.append("aplicarFiltro", aplicarFiltro ? "1" : "0");
        
        if (aplicarFiltro) {
            if (idMarca) formData.append("idMarca", idMarca);
            if (idModelo) formData.append("idModelo", idModelo);
            if (idTipo) formData.append("idTipo", idTipo);
        }
        
        if (fotoEvento.files.length > 0) {
            formData.append("foto", fotoEvento.files[0]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "php/funciones.php", true);
        
        xhr.onreadystatechange = function() {
            if (this.readyState === 4) {
                console.log("Respuesta del servidor:", this.responseText);
                if (this.status === 200) {
                    try {
                        const response = JSON.parse(this.responseText);
                        if (response.success) {
                            window.location.href = "eventos.php"; 
                        } else {
                            showError(response.message);
                        }
                    } catch (e) {
                        showError("Error al procesar la respuesta del servidor");
                    }
                } else {
                    showError("Error en la conexión con el servidor");
                }
            }
        };
        
        xhr.send(formData);
    });

    function cargarMarcas() {
        fetch('php/funciones.php?accion=cargarMarcas')
            .then(response => response.text())
            .then(data => {
                marcaSelect.innerHTML = data;
            })
            .catch(error => {
                console.error('Error al cargar marcas:', error);
            });
    }

    function cargarModelos(idMarca) {
        fetch(`php/funciones.php?accion=cargarModelos&idMarca=${idMarca}`)
            .then(response => response.text())
            .then(data => {
                modeloSelect.innerHTML = data;
            })
            .catch(error => {
                console.error('Error al cargar modelos:', error);
            });
    }

    function showError(message) {
        const errorMessage = document.getElementById("errorMessage");
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.classList.remove("d-none");
        } else {
            console.error("No se encontró el elemento para mostrar errores");
        }
    }
});