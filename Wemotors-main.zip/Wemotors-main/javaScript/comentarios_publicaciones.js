document.addEventListener('DOMContentLoaded', function() {
    // Variables globales
    let currentPubliId = null;
    let sidebarInstance = null;
    const commentsBackdrop = document.getElementById('commentsBackdrop');
    let isSending = false; // Bandera para evitar envíos duplicados
    
    // Configuración inicial del backdrop
    commentsBackdrop.style.transition = 'opacity 0.15s linear';
    commentsBackdrop.addEventListener('click', closeCommentsSidebar);

    // Función optimizada para cerrar el sidebar
    function closeCommentsSidebar() {
        if (sidebarInstance) {
            sidebarInstance.hide();
        }
        hideBackdrop();
    }

    // Mostrar backdrop con animación suave
    function showBackdrop() {
        commentsBackdrop.style.display = 'block';
        setTimeout(() => {
            commentsBackdrop.classList.add('show');
        }, 10);
    }

    // Ocultar backdrop con animación suave
    function hideBackdrop() {
        commentsBackdrop.classList.remove('show');
        setTimeout(() => {
            commentsBackdrop.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 150);
    }

    // Manejar clic en botones de comentarios
    document.addEventListener('click', function(e) {
        if (e.target.closest('.comment-btn')) {
            const btn = e.target.closest('.comment-btn');
            currentPubliId = btn.getAttribute('data-publi-id');
            
            // Verificar autenticación
            if (!document.querySelector('#userDropdown').contains(document.querySelector('a[href="inicio_sesion.php"]'))) {
                initializeSidebar();
                showBackdrop();
                document.body.style.overflow = 'hidden';
                sidebarInstance.show();
                loadComments(currentPubliId);
            } else {
                window.location.href = 'inicio_sesion.php';
            }
        }
    });

    // Inicializar sidebar solo una vez
    function initializeSidebar() {
        if (!sidebarInstance) {
            const sidebarElement = document.getElementById('commentsSidebar');
            sidebarInstance = new bootstrap.Offcanvas(sidebarElement);
            
            sidebarElement.addEventListener('hidden.bs.offcanvas', function() {
                hideBackdrop();
            });
            
            // Manejador único para el botón de enviar
            document.getElementById('sendComment').addEventListener('click', function() {
                const commentInput = document.getElementById('commentInput');
                const commentText = commentInput.value.trim();
                const errorElement = document.getElementById('commentError');
                
                // Limpiar error previo
                if (errorElement) {
                    errorElement.remove();
                }
                
                if (!commentText) {
                    showInlineError('Por favor escribe un comentario');
                    return;
                }
                
                if (!currentPubliId) {
                    showInlineError('Error al identificar la publicación');
                    return;
                }
                
                if (!isSending) {
                    isSending = true;
                    sendComment(currentPubliId, commentText);
                }
            });
        }
    }

    // Mostrar error debajo del botón
    function showInlineError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.id = 'commentError';
        errorDiv.className = 'text-danger mt-2 small';
        errorDiv.textContent = message;
        
        const container = document.querySelector('#commentsSidebar .border-top');
        container.appendChild(errorDiv);
    }

    // Cargar comentarios via AJAX
function loadComments(publiId) {
    const commentsContainer = document.getElementById('commentsContainer');
    commentsContainer.innerHTML = `
        <div class="text-center py-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Cargando...</span>
            </div>
        </div>`;
    
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `./php/funciones.php?accion=obtener_comentarios&idPubli=${encodeURIComponent(publiId)}`, true);
    
    xhr.onreadystatechange = function() {
        if (this.readyState === 4) {
            if (this.status === 200) {
                try {
                    const response = JSON.parse(this.responseText);
                    if (response.success) {
                        commentsContainer.innerHTML = response.html;
                        updateCommentCount(publiId, response.count);
                        
                        // Agregar event listeners a los botones de eliminar
                        document.querySelectorAll('.delete-comment-btn').forEach(btn => {
                            btn.addEventListener('click', function() {
                                const commentId = this.getAttribute('data-comment-id');
                                deleteComment(publiId, commentId);
                            });
                        });
                    } else {
                        showError(response.error || 'Error al cargar comentarios');
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                    showError('Error procesando los comentarios');
                }
            } else {
                showError('Error de conexión: ' + this.status);
            }
        }
    };
    
    xhr.send();
}
    function deleteComment(publiId, commentId) {
    if (!confirm('¿Estás seguro de que quieres eliminar este comentario?')) {
        return;
    }
    
    const xhr = new XMLHttpRequest();
    xhr.open('POST', './php/funciones.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xhr.onreadystatechange = function() {
        if (this.readyState === 4) {
            if (this.status === 200) {
                try {
                    const response = JSON.parse(this.responseText);
                    if (response.success) {
                        // Recargar los comentarios
                        loadComments(publiId);
                    } else {
                        alert(response.message || 'Error al eliminar el comentario');
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                    alert('Error procesando la respuesta del servidor');
                }
            } else {
                alert('Error de conexión: ' + this.status);
            }
        }
    };
    
    const params = new URLSearchParams();
    params.append('accionP', 'eliminarComentario');
    params.append('idComentario', commentId);
    
    xhr.send(params.toString());
}


    // Actualizar contador de comentarios
    function updateCommentCount(publiId, count) {
        const countElement = document.querySelector(`.comment-btn[data-publi-id="${publiId}"] + span`);
        if (countElement) {
            countElement.textContent = count;
        }
    }

    // Mostrar errores en el contenedor
    function showError(message) {
        const commentsContainer = document.getElementById('commentsContainer');
        commentsContainer.innerHTML = `
            <div class="alert alert-danger">
                ${message}
            </div>`;
    }

    // Enviar comentario al servidor
    function sendComment(publiId, text) {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', './php/funciones.php?accion=agregar_comentario', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onreadystatechange = function() {
            if (this.readyState === 4) {
                isSending = false;
                
                if (this.status === 200) {
                    try {
                        const response = JSON.parse(this.responseText);
                        if (response.success) {
                            document.getElementById('commentInput').value = '';
                            loadComments(publiId);
                            // Actualizar contador en la publicación
                            const countElement = document.querySelector(`.comment-btn[data-publi-id="${publiId}"] + span`);
                            if (countElement && response.count) {
                                countElement.textContent = response.count;
                            }
                        } else {
                            showInlineError(response.error || 'Error al enviar comentario');
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        showInlineError('Error procesando respuesta del servidor');
                    }
                } else {
                    showInlineError('Error de conexión: ' + this.status);
                }
            }
        };
        
        // Codificar parámetros correctamente
        const params = new URLSearchParams();
        params.append('accion', 'agregar_comentario');
        params.append('idPubli', publiId);
        params.append('texto', text);
        
        xhr.send(params.toString());
    }
});
