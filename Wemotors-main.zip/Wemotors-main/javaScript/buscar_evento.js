document.addEventListener('DOMContentLoaded', function() {
    const eventSearch = document.getElementById("eventSearch");
    const eventResults = document.getElementById("eventResults");
    const searchEventForm = document.getElementById("searchEventForm");
    const eventosContainer = document.getElementById("eventosContainer");
    
    let debounceTimer;
    const debounceDelay = 300;
    
    function mostrarSugerencias() {
        const texto = eventSearch.value.trim();
        
        if(texto.length >= 1) {
            clearTimeout(debounceTimer);
            
            debounceTimer = setTimeout(() => {
                fetch(`./php/funciones.php?accion=BuscEvento&texto=${encodeURIComponent(texto)}`)
                    .then(response => response.ok ? response.text() : Promise.reject('Error'))
                    .then(data => {
                        eventResults.innerHTML = data || '<div class="p-2">No se encontraron eventos</div>';
                        eventResults.classList.remove("d-none");
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        eventResults.innerHTML = '<div class="p-2 text-danger">Error al buscar</div>';
                        eventResults.classList.remove("d-none");
                    });
            }, debounceDelay);
        } else {
            eventResults.innerHTML = "";
            eventResults.classList.add("d-none");
        }
    }
    
    function cargarEventos(texto = '') {
        fetch(`./php/funciones.php?accion=ListarEventos&texto=${encodeURIComponent(texto)}`)
            .then(response => response.ok ? response.text() : Promise.reject('Error'))
            .then(data => {
                eventosContainer.innerHTML = data;
                eventResults.classList.add("d-none");
            })
            .catch(error => {
                console.error('Error:', error);
                eventosContainer.innerHTML = '<div class="alert alert-danger">Error al cargar eventos</div>';
            });
    }

    // Event listeners
    eventSearch.addEventListener("input", mostrarSugerencias);
    
    eventSearch.addEventListener("focus", function() {
        if(eventSearch.value.trim() !== "" && eventResults.innerHTML === "") {
            mostrarSugerencias();
        }
    });
    
    eventResults.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if(link) {
            e.preventDefault();
            const selectedText = link.textContent.trim();
            eventSearch.value = selectedText;
            cargarEventos(selectedText);
        }
    });
    
    document.addEventListener('click', function(e) {
        if (!eventSearch.contains(e.target) && !eventResults.contains(e.target)) {
            eventResults.classList.add("d-none");
        }
    });
    
    searchEventForm.addEventListener('submit', function(e) {
        e.preventDefault();
        cargarEventos(eventSearch.value.trim());
    });
    
    // Cargar eventos al inicio
    cargarEventos();
});