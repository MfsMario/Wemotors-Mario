document.addEventListener('DOMContentLoaded', function() {
    const crearEventoBtn = document.getElementById("CrearCrew");

    crearEventoBtn.addEventListener('click', function(e) {
        e.preventDefault();

        const fotoEvento = document.getElementById("LogoCrew");
        const Nombre = document.getElementById("NomCrew").value.trim();
        const descripcion = document.getElementById("DescCrew").value.trim();
 

        if (!Nombre || !descripcion) {
            showError("Todos los campos marcados con * son obligatorios");
            return;
        }

        const formData = new FormData();
        formData.append("accionP", "CrearCrew");
        formData.append("nomb", Nombre);
        formData.append("desc", descripcion);
        
        if (fotoEvento.files.length > 0) {
            formData.append("foto", fotoEvento.files[0]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "php/funciones.php", true);
        
        xhr.onreadystatechange = function() {
            if (this.readyState === 4) {
                console.log("Respuesta del servidor:", this.responseText);
                if (this.status === 200) {
                    try {
                        const response = JSON.parse(this.responseText);
                        if (response.success) {
                            window.location.href = "crews.php"; 
                        } else {
                            showError(response.message);
                        }
                    } catch (e) {
                        showError("Error al procesar la respuesta del servidor");
                    }
                } else {
                    showError("Error en la conexión con el servidor");
                }
            }
        };
        
        xhr.send(formData);
    });

    function showError(message) {
        const errorMessage = document.getElementById("errorMessage");
        if (errorMessage) {
            errorMessage.textContent = message;
            errorMessage.classList.remove("d-none");
        } else {
            console.error("No se encontró el elemento para mostrar errores");
        }
    }
});