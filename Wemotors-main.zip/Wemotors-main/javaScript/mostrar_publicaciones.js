document.addEventListener('DOMContentLoaded', function() {
    let isLoading = false;
    let currentOffset = 0;
    const limit = 7;
    let currentFilter = 'todos'; // 'todos', 'siguiendo' o 'marca'
    let currentMarcaId = null;
    let canLoadMore = true;
    let currentPais = null;

    function cargarPublicaciones(reset = false) {
           if (isLoading || !canLoadMore) return;
    
    isLoading = true;
    
    if (reset) {
        document.getElementById('cont-publi').innerHTML = '<div class="text-center mt-4"><div class="spinner-border" role="status"><span class="visually-hidden">Cargando...</span></div></div>';
        currentOffset = 0;
    }
    
    const formData = new FormData();
    formData.append('accionP', 'filtrar_publicaciones'); 
    formData.append('filtro', currentFilter); 
    
    // Añadir parámetros según el filtro actual
    if (currentFilter === 'marca') {
        formData.append('idMarca', currentMarcaId);
    }
    if (currentFilter === 'pais') {
        formData.append('pais', currentPais); 
    }
    
    formData.append('limit', limit);
    formData.append('offset', currentOffset);
    
    fetch('php/funciones.php', {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) throw new Error('Error en la red');
            return response.text();
        })
        .then(html => {
            if (!html.trim()) {
                canLoadMore = false;
                if (currentOffset > 0) {
                    const noMore = document.createElement('div');
                    noMore.className = 'text-center my-3 text-muted';
                    noMore.textContent = 'No hay más publicaciones';
                    document.getElementById('cont-publi').appendChild(noMore);
                } else if (reset) {
                    document.getElementById('cont-publi').innerHTML = '<div class="text-center mt-4">No hay publicaciones</div>';
                }
                return;
            }
            
            if (reset) {
                document.getElementById('cont-publi').innerHTML = html;
            } else {
                document.getElementById('cont-publi').insertAdjacentHTML('beforeend', html);
            }
            currentOffset += limit;
        })
        .catch(error => {
            console.error('Error:', error);
            if (reset) {
                document.getElementById('cont-publi').innerHTML = '<div class="alert alert-danger">Error al cargar publicaciones</div>';
            }
        })
        .finally(() => {
            isLoading = false;
        });
    }

    // Infinite scroll
    window.addEventListener('scroll', function() {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 500) {
            cargarPublicaciones();
        }
    });

    // Botón Todos
    document.getElementById('btnTodos').addEventListener('click', function() {
        if (currentFilter !== 'todos') {
            currentFilter = 'todos';
            currentMarcaId = null;
            canLoadMore = true;
            document.getElementById('btnTodos').classList.add('active');
            document.getElementById('btnSiguiendo').classList.remove('active');
            cargarPublicaciones(true);
        }
    });

    // Botón Siguiendo
    document.getElementById('btnSiguiendo').addEventListener('click', function() {
        if (currentFilter !== 'siguiendo') {
            currentFilter = 'siguiendo';
            currentMarcaId = null;
            canLoadMore = true;
            document.getElementById('btnSiguiendo').classList.add('active');
            document.getElementById('btnTodos').classList.remove('active');
            cargarPublicaciones(true);
        }
    });

    // Filtrado por marca
    document.querySelectorAll('.dropdown-item[data-marca-id]').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            currentFilter = 'marca';
            currentMarcaId = this.getAttribute('data-marca-id');
            canLoadMore = true;
            document.getElementById('btnTodos').classList.remove('active');
            document.getElementById('btnSiguiendo').classList.remove('active');
            cargarPublicaciones(true);
        });
    });

    // Todas las marcas
    document.getElementById('todasMarcas').addEventListener('click', function(e) {
        e.preventDefault();
        currentFilter = 'todos';
        currentMarcaId = null;
        canLoadMore = true;
        document.getElementById('btnTodos').classList.add('active');
        document.getElementById('btnSiguiendo').classList.remove('active');
        cargarPublicaciones(true);
    });

 document.querySelectorAll('.dropdown-item[data-pais]').forEach(item => {
    item.addEventListener('click', function(e) {
        e.preventDefault();
        currentFilter = 'pais'; // Cambiamos el filtro a 'pais'
        currentPais = this.getAttribute('data-pais');
        currentMarcaId = null;
        canLoadMore = true;
        document.getElementById('btnTodos').classList.remove('active');
        document.getElementById('btnSiguiendo').classList.remove('active');
        cargarPublicaciones(true);
    });
});

// Evento para "Todos los países"
document.getElementById('todosPaises').addEventListener('click', function(e) {
    e.preventDefault();
    currentFilter = 'todos';
    currentPais = null;
    canLoadMore = true;
    document.getElementById('btnTodos').classList.add('active');
    document.getElementById('btnSiguiendo').classList.remove('active');
    cargarPublicaciones(true);
});
    // Carga inicial
    cargarPublicaciones(true);
});