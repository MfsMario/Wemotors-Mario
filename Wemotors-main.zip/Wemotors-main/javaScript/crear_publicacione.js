function cargarDatosIniciales() {
    var capaMarca = document.getElementById("marcaCoche");
    var capaCrew = document.getElementById("crewSection");
    var capaEvento = document.getElementById("eventoSection");
    
    capaMarca.innerHTML = '<option value="">Cargando marcas...</option>';
    capaCrew.style.display = "none";
    capaEvento.style.display = "none";
    
    fetch("./php/funciones.php?accion=cargarDatosPublicacion")
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log("Datos recibidos:", data);
            
            if (!data.success) {
                console.error("Error del servidor:", data.message);
                throw new Error(data.message || "Error desconocido del servidor");
            }
            
            // Procesar marcas (siempre deberían estar)
            if (data.marcas && Array.isArray(data.marcas)) {
                capaMarca.innerHTML = '<option value="" selected disabled>Seleccione marca...</option>';
                data.marcas.forEach(marca => {
                    let option = document.createElement('option');
                    option.value = marca.idMarca;
                    option.textContent = marca.Nombre;
                    capaMarca.appendChild(option);
                });
            } else {
                console.warn("No se recibieron marcas");
                capaMarca.innerHTML = '<option value="">No hay marcas disponibles</option>';
            }
             
            // Procesar crew (puede ser null)
            if (data.crew && data.crew.idCrew) {
                console.log("Usuario tiene crew:", data.crew);
                capaCrew.style.display = "block";
                document.getElementById("nombreCrew").textContent = data.crew.Nombre;
                document.getElementById("idCrew").value = data.crew.idCrew;
                document.getElementById("crewInfo").style.display = "block";
            } else {
                console.log("Usuario no tiene crew");
                capaCrew.style.display = "none";
            }
            
            // Procesar eventos (puede estar vacío)
            if (data.eventos && Array.isArray(data.eventos) && data.eventos.length > 0) {
                console.log("Usuario tiene eventos:", data.eventos);
                capaEvento.style.display = "block";
                let selectEvento = document.getElementById("selectEvento");
                selectEvento.innerHTML = '<option value="" selected disabled>Seleccione evento...</option>';
                
                data.eventos.forEach(evento => {
                    let option = document.createElement('option');
                    option.value = evento.idEvento;
                    option.textContent = evento.Nombre;
                    selectEvento.appendChild(option);
                });
            } else {
                console.log("Usuario no tiene eventos");
                capaEvento.style.display = "none";
            }
        })
        .catch(error => {
            console.error("Error completo:", error);
            capaMarca.innerHTML = '<option value="">Error al cargar: ' + error.message + '</option>';
            alert("Error al cargar datos: " + error.message);
        });
}

// Resto del código se mantiene igual...
function enviarFormulario(event) {
    event.preventDefault();
    var form = document.getElementById("formPublicacion");
    var formData = new FormData(form);
    
    // Solo añadir estos valores si los checkboxes están marcados
    if (document.getElementById("añadirACrew").checked) {
        formData.append("añadirACrew", "1");
    }
    
    if (document.getElementById("añadirAEvento").checked) {
        formData.append("añadirAEvento", "1");
    }
    
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                try {
                    var response = JSON.parse(this.responseText);
                    if (response.success) {
                        alert("Publicación creada con éxito");
                        window.location.href = "perfil_usuario.php";
                    } else {
                        alert("Error: " + response.message);
                    }
                } catch (e) {
                    console.error("Error al parsear respuesta:", e);
                    alert("Error procesando la respuesta del servidor");
                }
            } else {
                alert("Error en la conexión con el servidor");
            }
        }
    };
    xmlhttp.open("POST", "./php/funciones.php?accion=crearPublicacion", true);
    xmlhttp.send(formData);
}

function manejarCheckboxes() {
    document.getElementById("añadirAEvento").addEventListener("change", function() {
        document.getElementById("selectEvento").disabled = !this.checked;
    });
}

document.addEventListener('DOMContentLoaded', function() {
    cargarDatosIniciales();
    manejarCheckboxes();
    document.getElementById("formPublicacion").addEventListener("submit", enviarFormulario);
});