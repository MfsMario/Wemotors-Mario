document.addEventListener('DOMContentLoaded', function() {
    const formVerificacion = document.getElementById('formVerificacion');
    const btnReenviar = document.getElementById('btnReenviar');
    const contadorElement = document.getElementById('contador');
    const errorMessage = document.getElementById('errorMessage');
    
    // Tiempo de expiración en segundos (2 minutos)
    const tiempoExpiracion = 120;
    let tiempoRestante = tiempoExpiracion;
    
    // Iniciar contador
    const intervalo = setInterval(actualizarContador, 1000);
    
    function actualizarContador() {
        tiempoRestante--;
        
        const minutos = Math.floor(tiempoRestante / 60);
        const segundos = tiempoRestante % 60;
        
        contadorElement.textContent = `${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
        
        if (tiempoRestante <= 0) {
            clearInterval(intervalo);
            document.getElementById('reenviarContador').classList.add('d-none');
            btnReenviar.disabled = false;
        }
    }
    
    // Verificar código
    formVerificacion.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const codigoIngresado = document.getElementById('codigo').value.trim().toUpperCase();
        const datosRegistro = JSON.parse(sessionStorage.getItem('datosRegistro'));
        
        if (!datosRegistro) {
            showError('No se encontraron datos de registro. Por favor, regresa e intenta de nuevo.');
            return;
        }
        
        if (codigoIngresado !== datosRegistro.codigoVerificacion) {
            showError('El código de verificación es incorrecto.');
            return;
        }
        
        // El código es correcto, proceder a crear la cuenta
        crearCuenta(datosRegistro);
    });
    
    // Reenviar código
    btnReenviar.addEventListener('click', function() {
        const datosRegistro = JSON.parse(sessionStorage.getItem('datosRegistro'));
        
        if (!datosRegistro) {
            showError('No se encontraron datos de registro. Por favor, regresa e intenta de nuevo.');
            return;
        }
        
        // Generar nuevo código
        const nuevoCodigo = generarCodigo();
        datosRegistro.codigoVerificacion = nuevoCodigo;
        datosRegistro.timestamp = Date.now();
        sessionStorage.setItem('datosRegistro', JSON.stringify(datosRegistro));
        
        // Enviar nuevo código por correo
        const formData = new FormData();
        formData.append("accionP", "enviarCodigoVerificacion");
        formData.append("email", datosRegistro.email);
        formData.append("codigo", nuevoCodigo);
        
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "php/funciones.php", true);
        
        xhr.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200) {
                try {
                    const response = JSON.parse(this.responseText);
                    if (!response.success) {
                        showError(response.message);
                    } else {
                        // Reiniciar contador
                        tiempoRestante = tiempoExpiracion;
                        document.getElementById('reenviarContador').classList.remove('d-none');
                        btnReenviar.disabled = true;
                        clearInterval(intervalo);
                        setInterval(actualizarContador, 1000);
                        
                        // Mostrar mensaje de éxito
                        errorMessage.classList.remove('alert-danger');
                        errorMessage.classList.add('alert-success');
                        showError('Se ha enviado un nuevo código a tu correo electrónico.');
                        setTimeout(() => {
                            errorMessage.classList.add('d-none');
                            errorMessage.classList.remove('alert-success');
                            errorMessage.classList.add('alert-danger');
                        }, 3000);
                    }
                } catch (e) {
                    showError("Error al procesar la respuesta del servidor");
                }
            }
        };
        
        xhr.send(formData);
    });
    
    function generarCodigo() {
        const letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numeros = '0123456789';
        let codigo = '';
        
        for (let i = 0; i < 3; i++) {
            codigo += letras.charAt(Math.floor(Math.random() * letras.length));
        }
        
        for (let i = 0; i < 3; i++) {
            codigo += numeros.charAt(Math.floor(Math.random() * numeros.length));
        }
        
        return codigo;
    }
    
    function crearCuenta(datos) {
        const formData = new FormData();
        formData.append("accionP", "singIn");
        formData.append("nomb", datos.nombre);
        formData.append("apell", datos.apellidos);
        formData.append("nick", datos.nick);
        formData.append("email", datos.email);
        formData.append("contra", datos.password);
        formData.append("privada", datos.cuentaPrivada);
        
        // Manejar la foto si existe en los datos guardados
        if (datos.fotoBase64) {
            // Convertir base64 de vuelta a blob
            const base64Data = datos.fotoBase64.split(',')[1];
            const byteCharacters = atob(base64Data);
            const byteNumbers = new Array(byteCharacters.length);
            
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: datos.fotoType });
            
            formData.append("foto", blob, datos.fotoName);
        }
        
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "php/funciones.php", true);
            
        xhr.onreadystatechange = function() {
            if (this.readyState === 4) {
                if (this.status === 200) {
                    try {
                        const response = JSON.parse(this.responseText);
                        if (response.success) {
                            sessionStorage.removeItem('datosRegistro');
                            window.location.href = "inicio_sesion.php";
                        } else {
                            showError(response.message);
                        }
                    } catch (e) {
                        showError("Error al procesar la respuesta del servidor");
                    }
                } else {
                    showError("Error de conexión con el servidor");
                }
            }
        };
        
        xhr.send(formData);
    }
    
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.remove("d-none");
    }
});