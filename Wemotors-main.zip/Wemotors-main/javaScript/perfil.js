function cargarPerfil() {
    var xmlhttp = new XMLHttpRequest();
    
    xmlhttp.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200) {
            document.getElementById("Perfil").innerHTML = this.responseText;
        } else if(this.readyState == 4) {
            document.getElementById("Perfil").innerHTML = "<div class='alert alert-danger'>Error al cargar el perfil</div>";
        }
    };
    
    var userId = new URLSearchParams(window.location.search).get('id') || '';
    var url = "php/funciones.php?accion=perfil" + (userId ? "&id=" + userId : "");
    
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

document.addEventListener('DOMContentLoaded', cargarPerfil);