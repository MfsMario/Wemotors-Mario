document.addEventListener('DOMContentLoaded', function() {
    cargarMarcas();
    
    const marcaSelect = document.getElementById('marcaCoche');
    marcaSelect.addEventListener('change', function() {
        if (this.value) {
            cargarModelos(this.value);
        } else {
            document.getElementById('modeloCoche').innerHTML = '<option value="" selected disabled>Selecciona una marca primero</option>';
        }
    });

    const form = document.querySelector('form');
    const errorMessage = document.getElementById('errorMessage');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!validarFormulario()) {
            return;
        }

        const formData = new FormData();
        formData.append('accionP', 'crearVehiculo');
        formData.append('idMarca', document.getElementById('marcaCoche').value);
        formData.append('idModelo', document.getElementById('modeloCoche').value); // Añadido
        formData.append('agno', document.getElementById('vehiculoAgno').value);
        
        const fotoInput = document.getElementById('FotoVehiculo');
        if (fotoInput.files.length > 0) {
            formData.append('foto', fotoInput.files[0]);
        }

        fetch('./php/funciones.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'perfil_usuario.php';
            } else {
                mostrarError(data.message);
            }
        })
        .catch(error => {
            mostrarError('Error en la conexión');
        });
    });

    function cargarMarcas() {
        fetch('./php/funciones.php?accion=cargarMarcas')
            .then(response => response.text())
            .then(data => {
                document.getElementById('marcaCoche').innerHTML = data;
            });
    }

    function cargarModelos(idMarca) {
        fetch(`./php/funciones.php?accion=cargarModelos&idMarca=${idMarca}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('modeloCoche').innerHTML = data;
            });
    }

    function validarFormulario() {
        const marca = document.getElementById('marcaCoche').value;
        const modeloSelect = document.getElementById('modeloCoche').value; // Añadido
        const agno = document.getElementById('vehiculoAgno').value;
        const foto = document.getElementById('FotoVehiculo').files[0];

        if (!marca) {
            mostrarError('Selecciona una marca');
            return false;
        }

        if (!modeloSelect) { // Añadido
            mostrarError('Selecciona un modelo');
            return false;
        }


        if (!agno) {
            mostrarError('Selecciona el año del vehículo');
            return false;
        }

        if (!foto) {
            mostrarError('Selecciona una foto del vehículo');
            return false;
        }

        const tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif'];
        if (!tiposPermitidos.includes(foto.type)) {
            mostrarError('Solo se permiten imágenes JPEG, PNG o GIF');
            return false;
        }

        if (foto.size > 2097152) {
            mostrarError('La imagen no debe superar los 2MB');
            return false;
        }

        return true;
    }

    function mostrarError(mensaje) {
        errorMessage.textContent = mensaje;
        errorMessage.classList.remove('d-none');
    }
});