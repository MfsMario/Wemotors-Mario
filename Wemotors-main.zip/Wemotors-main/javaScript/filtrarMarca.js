function filtrarPorMarca(idMarca) {
    document.getElementById('cont-publi').innerHTML = '<div class="text-center mt-4"><div class="spinner-border" role="status"><span class="visually-hidden">Cargando...</span></div></div>';
    
    var xml = new XMLHttpRequest();
    xml.open('POST', window.location.href, true);
    xml.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    xml.onload = function() {
        if (this.status == 200) {
            document.getElementById('cont-publi').innerHTML = this.responseText;
        } else {
            document.getElementById('cont-publi').innerHTML = '<div class="alert alert-danger">Error al cargar las publicaciones</div>';
        }
    };
    
    // Enviamos el filtro como 'siguiendo' para que el backend aplique las restricciones
    xml.send('accion=filtrar_marca&idMarca=' + encodeURIComponent(idMarca) + '&filtro=siguiendo');
}