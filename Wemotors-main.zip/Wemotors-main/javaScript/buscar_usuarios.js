function listarusuarios() {
    var texto = document.getElementById("userSearch").value;
    var capa = document.getElementById("searchResults");
    
    if(texto !== "") {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if(this.readyState == 4 && this.status == 200) {
                capa.innerHTML = this.responseText;
                capa.classList.remove("d-none");
                
                // Añadir event listeners a los nuevos elementos
                document.querySelectorAll('.usuario-item').forEach(item => {
                    item.addEventListener('click', function() {
                        const userId = this.getAttribute('data-user-id');
                        window.location.href = 'perfil_ajeno.php?id=' + userId;
                    });
                });
            }
        };
        xmlhttp.open("GET", "./php/buscar_usuario.php?texto=" + texto);
        xmlhttp.send();
    } else {
        capa.innerHTML = "";
        capa.classList.add("d-none");
    }
}

// Función global para redireccionar
function redirigirAPerfil(userId) {
    window.location.href = 'perfil_ajeno.php?id=' + userId;
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("userSearch").addEventListener("keyup", listarusuarios);
    
    document.addEventListener('click', function(e) {
        if (!e.target.closest('#userSearch') && !e.target.closest('#searchResults')) {
            document.getElementById("searchResults").classList.add("d-none");
        }
    });
});