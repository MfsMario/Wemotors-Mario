<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Código</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="node_modules/bootstrap-icons/font/bootstrap-icons.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-white m-0 p-0">
    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="w-100 border border-black border-2 border-opacity-75" style="max-width: 400px;">
            <form class="p-4 shadow rounded-3 bg-light" id="formVerificacion">
                <h2 class="text-center mb-4">Verificar Código</h2>
                <div id="errorMessage" class="alert alert-danger d-none"></div>
                
                <p class="text-center">Hemos enviado un código de verificación a tu correo electrónico. Por favor, introdúcelo a continuación.</p>
                
                <div class="mb-3">
                    <label for="codigo" class="form-label">Código de verificación</label>
                    <input type="text" class="form-control text-uppercase" id="codigo" placeholder="ABC123" maxlength="6">
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" id="btnVerificar" class="btn btn-primary">Verificar</button>
                </div>
                
                <div class="text-center mt-3">
                    <p id="reenviarContador">Puedes solicitar un nuevo código en <span id="contador">02:00</span></p>
                    <button type="button" id="btnReenviar" class="btn btn-link p-0" disabled>Reenviar código</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="javaScript/verificar_codigo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>