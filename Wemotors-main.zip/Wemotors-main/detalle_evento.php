<?php
require_once("php/funciones.php"); // Esto debe ir primero
    
$ID = "";
if(isset($_GET["idEvento"])){
    $ID = $_GET["idEvento"];
}

// Manejar acción de participar/salir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accionEvento'])) {
    manejarParticipacionEvento($pdo);
    exit; // Terminamos la ejecución aquí para las peticiones AJAX
}

// Verificar si el usuario es admin del evento
$esAdminEvento = false;
if(isset($_SESSION['usuario_id'])) {
    $sql = "SELECT idUsuAdmin FROM eventos WHERE idEvento = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$ID]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    $esAdminEvento = ($evento && $evento['idUsuAdmin'] == $_SESSION['usuario_id']);
}

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if(!isset($_SESSION['usuario_id'])){
    header("Location: pagina_entrada.php"); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="solicitudes.css">
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="node_modules\bootstrap-icons\font\bootstrap-icons.css"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="javaScript\buscar_usuarios.js"></script>
   <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
    <style>
        .profile-img {
            width: 200px;
            height: 200px;
            object-fit: cover;
        }
        .gallery-img {
            max-width: 100px;
            max-height: 150px;
            object-fit: cover;
        }
        .participante-item {
            transition: background-color 0.2s;
        }
        .participante-item:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link " href="inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="eventos.php">Eventos</a>
                </li>
                <li class="nav-item position-relative">
                    <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                    <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                </li>
            </ul>
            <div class="dropdown">
                <button 
                    class="btn btn-outline-light dropdown-toggle" 
                    type="button" 
                    id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false">
                    <?php echo $usuario; ?>

                     <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                            style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                            <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                   <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#" aria-expanded="false">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo generarHtmlSolicitudes($pdo); ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
    </nav>
    
    <?php echo detalleEvento($pdo, $ID, $esAdminEvento); ?>
    
    <!-- Modal para editar evento (solo para admin) -->
    <?php if($esAdminEvento): ?>
    <div class="modal fade" id="editarEventoModal" tabindex="-1" aria-labelledby="editarEventoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editarEventoModalLabel">Editar Evento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs" id="eventoTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="infoEvento-tab" data-bs-toggle="tab" data-bs-target="#infoEvento-tab-pane" type="button" role="tab" aria-controls="infoEvento-tab-pane" aria-selected="true">Información</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="participantes-tab" data-bs-toggle="tab" data-bs-target="#participantes-tab-pane" type="button" role="tab" aria-controls="participantes-tab-pane" aria-selected="false">Participantes</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="publicacionesEvento-tab" data-bs-toggle="tab" data-bs-target="#publicacionesEvento-tab-pane" type="button" role="tab" aria-controls="publicacionesEvento-tab-pane" aria-selected="false">Publicaciones</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="eventoTabsContent">
                        <!-- Pestaña de información -->
                        <div class="tab-pane fade show active" id="infoEvento-tab-pane" role="tabpanel" aria-labelledby="infoEvento-tab" tabindex="0">
                            <form id="formEditarEvento" class="mt-3">
                                <div class="mb-3">
                                    <label for="nombreEvento" class="form-label">Nombre</label>
                                    <input type="text" class="form-control" id="nombreEvento" name="nombreEvento" >
                                </div>
                                <div class="mb-3">
                                    <label for="descripcionEvento" class="form-label">Descripción</label>
                                    <textarea class="form-control" id="descripcionEvento" name="descripcionEvento" rows="3"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="lugarEvento" class="form-label">Lugar</label>
                                    <input type="text" class="form-control" id="lugarEvento" name="lugarEvento">
                                </div>
                                <div class="mb-3">
                                    <label for="fechaEvento" class="form-label">Fecha y Hora</label>
                                    <input type="datetime-local" class="form-control" id="fechaEvento" name="fechaEvento">
                                </div>
                                <div class="mb-3">
                                    <label for="fotoEvento" class="form-label">Foto de perfil</label>
                                    <input class="form-control" type="file" id="fotoEvento" name="fotoEvento" accept="image/*">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Pestaña de participantes -->
                        <div class="tab-pane fade" id="participantes-tab-pane" role="tabpanel" aria-labelledby="participantes-tab" tabindex="0">
                            <div class="mt-3" id="listaParticipantes">
                                <!-- Los participantes se cargarán aquí via AJAX -->
                                Cargando participantes...
                            </div>
                        </div>
                        
                        <!-- Pestaña de publicaciones -->
                        <div class="tab-pane fade" id="publicacionesEvento-tab-pane" role="tabpanel" aria-labelledby="publicacionesEvento-tab" tabindex="0">
                            <div class="mt-3" id="listaPublicacionesEvento">
                                <!-- Las publicaciones se cargarán aquí via AJAX -->
                                Cargando publicaciones...
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Modal para transferir admin (solo para admin) -->
    <?php if($esAdminEvento): ?>
    <div class="modal fade" id="transferirAdminEventoModal" tabindex="-1" aria-labelledby="transferirAdminEventoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="transferirAdminEventoModalLabel">Transferir administración</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Selecciona un nuevo administrador para el evento o el evento será eliminado si no hay participantes.</p>
                    <div class="list-group" id="listaParticipantesTransferencia">
                        <!-- Los participantes se cargarán aquí via AJAX -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="btnEliminarEvento">Eliminar Evento</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php require_once("footer.html");?>
    <script>
    function manejarParticipacionEvento() {
        var xmlhttp = new XMLHttpRequest();
        
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                try {
                    var response = JSON.parse(this.responseText);
                    
                    if (response.success) {
                        // Actualizar el botón
                        var btn = document.querySelector('.btn-participar');
                        if (response.action === 'unirse') {
                            btn.textContent = 'Participar';
                            btn.classList.replace('btn-outline-danger', 'btn-outline-warning');
                        } else {
                            btn.textContent = 'Salir';
                            btn.classList.replace('btn-outline-warning', 'btn-outline-danger');
                        }
                        btn.dataset.action = response.action;
                        
                        // Actualizar contador de participantes
                        var contador = document.querySelector('.participantes-count');
                        contador.textContent = response.nuevoConteo;
                    } else {
                        alert(response.message || 'Error al procesar la solicitud');
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                    alert('Error al procesar la respuesta del servidor');
                }
            } else if (this.readyState == 4 && this.status !== 200) {
                alert('Error en la conexión con el servidor');
            }
        };
        
        <?php if(!isset($_SESSION['usuario_id'])): ?>
            window.location.href = 'inicio_sesion.php';
            return;
        <?php endif; ?>
        
        var btn = document.querySelector('.btn-participar');
        var currentAction = btn.dataset.action;
        var idEvento = <?= json_encode($ID) ?>;
        
        // Si es admin y está intentando salir, mostrar modal de transferencia
        <?php if($esAdminEvento): ?>
        if(currentAction === 'salir') {
            manejarSalidaAdminEvento();
            return; // Salir de la función después de mostrar el modal
        }
        <?php endif; ?>
        
        var params = new URLSearchParams();
        params.append('accionEvento', currentAction);
        params.append('idEvento', idEvento);
        
        xmlhttp.open("POST", window.location.href, true);
        xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xmlhttp.send(params.toString());
    }

    // Asignar el evento cuando el DOM esté cargado
    document.addEventListener('DOMContentLoaded', function() {
        var btn = document.querySelector('.btn-participar');
        if (btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                manejarParticipacionEvento();
            });
        }
        
       
    });

     <?php if($esAdminEvento): ?>
        // Función para manejar la salida del admin del evento
      function manejarSalidaAdminEvento() {
    fetch(`php/funciones.php?accion=obtenerParticipantesEventoEditar&idEvento=<?=$ID?>`)
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                const lista = document.getElementById('listaParticipantesTransferencia');
                lista.innerHTML = '';
                
                // Filtrar al usuario actual
                const participantesFiltrados = data.participantes.filter(p => p.idUsu != <?=$_SESSION['usuario_id'] ?? 0 ?>);
                
                if(participantesFiltrados.length > 0) {
                    participantesFiltrados.forEach(participante => {
                        const item = document.createElement('button');
                        item.className = 'list-group-item list-group-item-action';
                        item.innerHTML = `
                            <div class="d-flex align-items-center">
                                <img src="${participante.FotoPerfil ? 'data:image/jpeg;base64,' + participante.FotoPerfil : 'img/default-profile.png'}" 
                                     class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                <span>${participante.Nick}</span>
                            </div>
                        `;
                        item.onclick = () => transferirAdminEvento(participante.idUsu);
                        lista.appendChild(item);
                    });
                } else {
                    lista.innerHTML = '<p class="text-center">No hay otros participantes en el evento</p>';
                }
                
                // Mostrar el modal
                const modal = new bootstrap.Modal(document.getElementById('transferirAdminEventoModal'));
                modal.show();
            }
        });
}

        // Función para transferir admin del evento
      function transferirAdminEvento(idNuevoAdmin) {
            if(confirm('¿Estás seguro de transferir la administración a este participante? Esto te sacará del evento.')) {
                // Primero transferir la administración
                fetch(`php/funciones.php?accion=transferirAdminEvento&idEvento=<?=$ID?>&idNuevoAdmin=${idNuevoAdmin}`)
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            // Luego salir del evento
                            return fetch(`php/funciones.php?accion=salir_evento&idEvento=<?=$ID?>&idUsuario=<?=$_SESSION['usuario_id'] ?? 0 ?>`);
                        }
                        throw new Error(data.message || 'Error al transferir administración');
                    })
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            alert('Administración transferida con éxito. Has salido del evento.');
                            window.location.href = 'eventos.php';
                        } else {
                            throw new Error(data.message || 'Error al salir del evento');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error: ' + error.message);
                    });
            }
         }

        // Función para eliminar el evento
        document.getElementById('btnEliminarEvento').addEventListener('click', function() {
            if(confirm('¿Estás seguro de eliminar permanentemente este evento? Esta acción no se puede deshacer.')) {
                fetch(`php/funciones.php?accion=eliminarEvento&idEvento=<?=$ID?>`)
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            alert('Evento eliminado con éxito');
                            window.location.href = 'eventos.php';
                        } else {
                            alert('Error: ' + data.message);
                        }
                    });
            }
        });

        // Cargar datos del evento al abrir el modal
        document.getElementById('editarEventoModal').addEventListener('shown.bs.modal', function () {
            cargarDatosEvento();
            cargarParticipantesEvento();
            cargarPublicacionesEvento();
        });

        // Función para cargar datos del evento
        function cargarDatosEvento() {
            fetch(`php/funciones.php?accion=obtenerDatosEvento&idEvento=<?=$ID?>`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        document.getElementById('nombreEvento').value = data.evento.Nombre;
                        document.getElementById('descripcionEvento').value = data.evento.Descripcion;
                        document.getElementById('lugarEvento').value = data.evento.Lugar;
                        
                        // Formatear la fecha para el input datetime-local
                        const fechaEvento = new Date(data.evento.fecEvento);
                        const fechaFormateada = fechaEvento.toISOString().slice(0, 16);
                        document.getElementById('fechaEvento').value = fechaFormateada;
                    }
                });
        }

        // Función para cargar participantes del evento
       function cargarParticipantesEvento() {
        fetch(`php/funciones.php?accion=obtenerParticipantesEventoEditar&idEvento=<?=$ID?>`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    let html = '';
                    // Filtrar al usuario actual
                    const participantesFiltrados = data.participantes.filter(p => p.idUsu != <?=$_SESSION['usuario_id'] ?? 0 ?>);
                    
                    if(participantesFiltrados.length > 0) {
                        html = '<div class="list-group">';
                        participantesFiltrados.forEach(participante => {
                            html += `
                            <div class="list-group-item d-flex justify-content-between align-items-center participante-item">
                                <div class="d-flex align-items-center">
                                    <img src="${participante.FotoPerfil ? 'data:image/jpeg;base64,' + participante.FotoPerfil : 'img/default-profile.png'}" 
                                        class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                    <span>${participante.Nick}</span>
                                </div>
                                <button class="btn btn-sm btn-danger" onclick="expulsarParticipante(${participante.idUsu})">
                                    <i class="bi bi-person-x"></i> Expulsar
                                </button>
                            </div>`;
                        });
                        html += '</div>';
                    } else {
                        html = '<p class="text-center">No hay otros participantes en este evento.</p>';
                    }
                    document.getElementById('listaParticipantes').innerHTML = html;
                }
            });
    }
        // Función para cargar publicaciones del evento
        function cargarPublicacionesEvento() {
    fetch(`php/funciones.php?accion=obtenerPublicacionesEventoAdmin&idEvento=<?=$ID?>`)
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                const listaPublicaciones = document.getElementById('listaPublicacionesEvento');
                listaPublicaciones.innerHTML = '';
                
                if(data.publicaciones && data.publicaciones.length > 0) {
                    // Crear un contenedor de fila
                    const row = document.createElement('div');
                    row.className = 'row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4';
                    
                    data.publicaciones.forEach(publi => {
                        const col = document.createElement('div');
                        col.className = 'col';
                        col.innerHTML = `
                            <div class="card h-100">
                                <img src="${publi.Foto ? 'data:image/jpeg;base64,' + publi.Foto : 'img/default-post.jpg'}" 
                                    class="card-img-top" 
                                    style="height: 150px; object-fit: cover;">
                                <div class="card-body">
                                    <p class="card-text">${publi.DescripcionPubli || 'Sin descripción'}</p>
                                    <div class="d-flex justify-content-between">
                                        <small class="text-muted">${new Date(publi.fecPublicacion).toLocaleDateString()}</small>
                                        <button class="btn btn-sm btn-outline-danger eliminar-publicacion" 
                                                data-id="${publi.idPubli}">
                                            <i class="bi bi-trash"></i> Borrar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                        row.appendChild(col);
                    });
                    
                    listaPublicaciones.appendChild(row);
                    
                    // Agregar eventos a los botones de eliminar
                    document.querySelectorAll('.eliminar-publicacion').forEach(btn => {
                        btn.addEventListener('click', function() {
                            eliminarPublicacionEvento(this.dataset.id);
                        });
                    });
                } else {
                    listaPublicaciones.innerHTML = '<div class="col-12 text-center py-4">No hay publicaciones en este evento</div>';
                }
            } else {
                document.getElementById('listaPublicacionesEvento').innerHTML = `
                    <div class="col-12 text-center py-4 text-danger">
                        Error al cargar publicaciones: ${data.message || 'Error desconocido'}
                    </div>`;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('listaPublicacionesEvento').innerHTML = `
                <div class="col-12 text-center py-4 text-danger">
                    Error al cargar publicaciones: ${error.message}
                </div>`;
        });
}

        // Función para expulsar a un participante
        function expulsarParticipante(idUsuario) {
            if(confirm('¿Estás seguro de que deseas expulsar a este participante?')) {
                fetch(`php/funciones.php?accion=expulsarParticipanteEvento&idEvento=<?=$ID?>&idUsuario=${idUsuario}`)
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            cargarParticipantesEvento();
                            // Actualizar contador de participantes en la página principal
                            if(document.querySelector('.participantes-count')) {
                                document.querySelector('.participantes-count').textContent = data.nuevoConteo;
                            }
                        }
                    });
            }
        }

        // Función para eliminar una publicación del evento
        function eliminarPublicacionEvento(idPublicacion) {
            if(confirm('¿Estás seguro de que deseas eliminar esta publicación?')) {
                fetch(`php/funciones.php?accion=eliminarPublicacionEvento&idEvento=<?=$ID?>&idPubli=${idPublicacion}`)
                    .then(response => response.json())
                    .then(data => {
                        if(data.success) {
                            cargarPublicacionesEvento();
                        }
                    });
            }
        }

        
        // Manejar el envío del formulario de edición
       document.getElementById('formEditarEvento').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData();
    
    // Solo añadir los campos que tienen valor
    const nombreEvento = document.getElementById('nombreEvento').value;
    if (nombreEvento) formData.append('nombre', nombreEvento);
    
    const descripcionEvento = document.getElementById('descripcionEvento').value;
    if (descripcionEvento) formData.append('descripcion', descripcionEvento);
    
    const lugarEvento = document.getElementById('lugarEvento').value;
    if (lugarEvento) formData.append('lugar', lugarEvento);
    
    const fechaEvento = document.getElementById('fechaEvento').value;
    if (fechaEvento) formData.append('fecha', fechaEvento);
    
    const fotoInput = document.getElementById('fotoEvento');
    if (fotoInput.files[0]) {
        formData.append('foto', fotoInput.files[0]);
    }
    
    formData.append('idEvento', <?=$ID?>);
    formData.append('accionP', 'actualizarEvento');

    fetch('php/funciones.php?accionP=actualizarEvento', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Evento actualizado correctamente');
            // Recargar la página para ver los cambios
            location.reload();
        } else {
            alert('Error al actualizar: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Ocurrió un error al actualizar el evento');
    });
});
        <?php endif; ?>
    </script>
    
    <script src="navegDesplegable.js"></script>
    <script src="javaScript/solicitud.js"></script>
</body>
</html>