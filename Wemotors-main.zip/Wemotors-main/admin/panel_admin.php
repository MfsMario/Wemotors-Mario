<?php
require_once("funciones_admin/llamadabdd.php");
require_once("funciones_admin/usuarios.php");
require_once("funciones_admin/crews.php");
require_once("funciones_admin/eventos.php");
require_once("funciones_admin/reportes.php");

session_start();
$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Admin';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Wemotors</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../styles.css">
    <link rel="stylesheet" href="panel_admin.css">
    <link rel="stylesheet" href="../css_inicio.css"/>
    <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">
</head>
<body class="admin-container">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="funciones_admin/cerrar_sesion.php"><i class="bi bi-arrow-left"></i> Volver al Inicio</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-lg-12">
            <ul class="nav nav-tabs" id="adminTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="usuarios-tab" data-bs-toggle="tab" data-bs-target="#usuarios" type="button">
                        <i class="bi bi-people-fill"></i> Usuarios
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="crews-tab" data-bs-toggle="tab" data-bs-target="#crews" type="button">
                        <i class="bi bi-car-front-fill"></i> Crews
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="eventos-tab" data-bs-toggle="tab" data-bs-target="#eventos" type="button">
                        <i class="bi bi-calendar-event-fill"></i> Eventos
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="publicaciones-tab" data-bs-toggle="tab" data-bs-target="#publicaciones" type="button">
                        <i class="bi bi-image-fill"></i> Publicaciones
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="reportes-tab" data-bs-toggle="tab" data-bs-target="#reportes" type="button">
                        <i class="bi bi-flag-fill"></i> Reportes
                    </button>
                </li>
            </ul>

            <div class="tab-content p-3 bg-white rounded-bottom shadow-sm" id="adminTabsContent">
                <!-- Pestaña Usuarios -->
                <div class="tab-pane fade show active" id="usuarios" role="tabpanel">
                    <div class="search-box">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" class="form-control search-input" id="searchUsuarios" placeholder="Buscar usuarios...">
                    </div>
                    <?php echo mostrarUsuarios($pdo); ?>
                </div>

                <!-- Pestaña Crews -->
                <div class="tab-pane fade" id="crews" role="tabpanel">
                    <div class="search-box">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" class="form-control search-input" id="searchCrews" placeholder="Buscar crews...">
                    </div>
                    <?php echo mostrarCrews($pdo); ?>
                </div>

                <!-- Pestaña Eventos -->
                <div class="tab-pane fade" id="eventos" role="tabpanel">
                    <div class="search-box">
                        <i class="bi bi-search search-icon"></i>
                        <input type="text" class="form-control search-input" id="searchEventos" placeholder="Buscar eventos...">
                    </div>
                    <?php echo mostrarEventos($pdo); ?>
                </div>

                <!-- Pestaña Publicaciones -->
                <div class="tab-pane fade" id="publicaciones" role="tabpanel">
                    <div class="row"  id="contenedor-publicaciones">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body text-center py-5">
                                    <h5>Selecciona un usuario para ver sus publicaciones</h5>
                                    <p class="text-muted">Busca un usuario en el campo de búsqueda</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                  <div class="tab-pane fade" id="reportes" role="tabpanel">
                        <div class="search-box">
                            <i class="bi bi-search search-icon"></i>
                            <input type="text" class="form-control search-input" id="searchReportes" placeholder="Buscar reportes...">
                        </div>
                        <?php echo mostrarReportes($pdo); ?>
                    </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal para cambiar nombre -->
<div class="modal fade" id="editarUsuarioModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarUsuario">
                    <input type="hidden" id="usuarioIdEditar">
                    <div class="mb-3">
                        <label for="usuarioNickEditar" class="form-label">Nick</label>
                        <input type="text" class="form-control" id="usuarioNickEditar" required>
                    </div>
                    <div class="mb-3">
                        <label for="usuarioFotoEditar" class="form-label">Foto de perfil</label>
                        <div class="d-flex align-items-center mb-2">
                            <img id="previewFotoUsuario" src="" class="rounded-circle me-3" width="80" height="80" style="object-fit: cover;">
                            <input type="file" class="form-control" id="usuarioFotoEditar" accept="image/*">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarCambiosUsuario">Guardar cambios</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal para editar evento -->
<div class="modal fade" id="editarEventoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Evento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarEvento">
                    <input type="hidden" id="eventoIdEditar">
                    <div class="mb-3">
                        <label for="eventoNombreEditar" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="eventoNombreEditar" required>
                    </div>
                    <div class="mb-3">
                        <label for="eventoLugarEditar" class="form-label">Lugar</label>
                        <input type="text" class="form-control" id="eventoLugarEditar" required>
                    </div>
                    <div class="mb-3">
                        <label for="eventoFechaEditar" class="form-label">Fecha y Hora</label>
                        <input type="datetime-local" class="form-control" id="eventoFechaEditar" required>
                    </div>
                    <div class="mb-3">
                        <label for="eventoAdminEditar" class="form-label">Administrador</label>
                        <select class="form-select" id="eventoAdminEditar" required>
                            <option value="">Cargando participantes...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="eventoFotoEditar" class="form-label">Imagen del evento</label>
                        <div class="d-flex align-items-center mb-2">
                            <img id="previewFotoEvento" src="" class="rounded me-3" width="150" height="100" style="object-fit: cover;">
                            <input type="file" class="form-control" id="eventoFotoEditar" accept="image/*">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarCambiosEvento">Guardar cambios</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para editar crew -->
<div class="modal fade" id="editarCrewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Crew</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarCrew">
                    <input type="hidden" id="crewIdEditar">
                    <div class="mb-3">
                        <label for="crewNombreEditar" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="crewNombreEditar" required>
                    </div>
                    <div class="mb-3">
                        <label for="crewAdminEditar" class="form-label">Administrador</label>
                        <select class="form-select" id="crewAdminEditar" required>
                            <option value="">Seleccionar administrador</option>
                            <!-- Aquí se cargarán los miembros dinámicamente -->
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="crewFotoEditar" class="form-label">Imagen del crew</label>
                        <div class="d-flex align-items-center mb-2">
                            <img id="previewFotoCrew" src="" class="rounded me-3" width="150" height="100" style="object-fit: cover;">
                            <input type="file" class="form-control" id="crewFotoEditar" accept="image/*">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarCambiosCrew">Guardar cambios</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal para editar publicación -->
<div class="modal fade" id="editarPublicacionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- Cambiado a modal-lg para más espacio -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Publicación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formEditarPublicacion">
                    <input type="hidden" id="publicacionIdEditar">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="publicacionMarcaEditar" class="form-label">Marca</label>
                                <select class="form-select" id="publicacionMarcaEditar" required>
                                    <option value="">Seleccionar marca</option>
                                    <!-- Las marcas se cargarán dinámicamente -->
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="publicacionDescripcionEditar" class="form-label">Descripción</label>
                                <textarea class="form-control" id="publicacionDescripcionEditar" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="publicacionFotoEditar" class="form-label">Imagen</label>
                                <div class="d-flex align-items-center mb-2">
                                    <img id="previewFotoPublicacion" src="" class="rounded me-3" width="150" height="150" style="object-fit: cover;">
                                    <input type="file" class="form-control" id="publicacionFotoEditar" accept="image/*">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div id="contenedor-comentarios" class="overflow-auto" style="max-height: 400px;">
                                <!-- Los comentarios se cargarán aquí dinámicamente -->
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarCambiosPublicacion">Guardar cambios</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="miembrosCrewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Miembros del Crew: <span id="nombreCrewMiembros"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="search-box mb-3">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" class="form-control search-input" id="searchMiembrosCrew" placeholder="Buscar miembros...">
                </div>
                <div id="listaMiembrosCrew" class="overflow-auto" style="max-height: 400px;">
                    <!-- Lista de miembros se carga aquí -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Toast de éxito -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="toastExito" class="toast align-items-center text-white bg-success" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="toastMessage"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<!-- Toast de error -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="toastError" class="toast align-items-center text-white bg-danger" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="errorMessage"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="javaScript_admin/usuarios.js"></script>
<script src="javaScript_admin/crew.js"></script>
<script src="javaScript_admin/evento.js"></script>
<script src="javaScript_admin/publicacion.js"></script>
<script src="javaScript_admin/reportes.js"></script>
</body>
</html>