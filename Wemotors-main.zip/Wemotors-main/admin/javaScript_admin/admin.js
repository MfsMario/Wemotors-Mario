// Inicialización de tabs y modal
document.addEventListener('DOMContentLoaded', function() {
    // Activar el primer tab al cargar
    const firstTab = new bootstrap.Tab(document.getElementById('usuarios-tab'));
    firstTab.show();
    
    // Configurar el modal de cambiar nombre
    const cambiarNombreModal = document.getElementById('cambiarNombreModal');
    if (cambiarNombreModal) {
        cambiarNombreModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const userId = button.getAttribute('data-user-id');
            const nombreActual = button.getAttribute('data-nombre-actual');
            const apellidosActuales = button.getAttribute('data-apellidos-actuales');
            
            document.getElementById('userIdCambiarNombre').value = userId;
            document.getElementById('nuevoNombre').value = nombreActual;
            document.getElementById('nuevosApellidos').value = apellidosActuales;
        });
    }
    
    // Configurar el botón de confirmación del modal
    document.getElementById('confirmarCambioNombre')?.addEventListener('click', function() {
        const userId = document.getElementById('userIdCambiarNombre').value;
        const nuevoNombre = document.getElementById('nuevoNombre').value;
        const nuevosApellidos = document.getElementById('nuevosApellidos').value;
        
        fetch('funciones_admin.php?accion=cambiar_nombre_usuario', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${userId}&nombre=${encodeURIComponent(nuevoNombre)}&apellidos=${encodeURIComponent(nuevosApellidos)}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error al cambiar nombre: ' + (data.error || ''));
            }
        });
    });
});