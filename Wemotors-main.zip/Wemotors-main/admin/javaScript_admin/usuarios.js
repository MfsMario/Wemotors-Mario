document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchUsuarios');
    const tablaUsuarios = document.getElementById('tabla-usuarios');
    let timeoutId;

    // Elementos del modal de edición
    const editarUsuarioModal = new bootstrap.Modal(document.getElementById('editarUsuarioModal'));
    const previewFotoUsuario = document.getElementById('previewFotoUsuario');
    const usuarioFotoEditar = document.getElementById('usuarioFotoEditar');
    const usuarioNickEditar = document.getElementById('usuarioNickEditar');
    const usuarioIdEditar = document.getElementById('usuarioIdEditar');
    const guardarCambiosUsuario = document.getElementById('guardarCambiosUsuario');

    // Evento para previsualizar la imagen seleccionada
    usuarioFotoEditar.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewFotoUsuario.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Evento para abrir el modal de edición
    tablaUsuarios.addEventListener('click', function(e) {
        const botonEditar = e.target.closest('.editar-usuario');
        if (botonEditar) {
            usuarioIdEditar.value = botonEditar.dataset.id;
            usuarioNickEditar.value = botonEditar.dataset.nick;
            
            if (botonEditar.dataset.foto) {
                previewFotoUsuario.src = botonEditar.dataset.foto;
            } else {
                previewFotoUsuario.src = 'assets/img/default-profile.png';
            }
            
            // Resetear el input de archivo
            usuarioFotoEditar.value = '';
            
            editarUsuarioModal.show();
        }
    });

    // Evento para guardar los cambios
guardarCambiosUsuario.addEventListener('click', function() {
    const formData = new FormData();
    formData.append('accion', 'actualizar');
    formData.append('id', usuarioIdEditar.value);
    formData.append('nick', usuarioNickEditar.value);
    
    if (usuarioFotoEditar.files[0]) {
        formData.append('foto', usuarioFotoEditar.files[0]);
    }

    fetch('funciones_admin/usuarios.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            return response.text().then(text => {
                throw new Error(`El servidor respondió con: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            buscarUsuarios(searchInput.value);
            editarUsuarioModal.hide();
            
            const toast = new bootstrap.Toast(document.getElementById('toastExito'));
            document.getElementById('toastMessage').textContent = 'Usuario actualizado correctamente';
            toast.show();
        } else {
            // Mostrar error específico si el nick ya existe
            if (data.error && data.error.includes('El nick ya está en uso')) {
                // Resaltar el campo de nick
                usuarioNickEditar.classList.add('is-invalid');
                
                // Crear feedback de error si no existe
                if (!document.getElementById('nickErrorFeedback')) {
                    const feedback = document.createElement('div');
                    feedback.id = 'nickErrorFeedback';
                    feedback.className = 'invalid-feedback';
                    feedback.textContent = data.error;
                    usuarioNickEditar.parentNode.appendChild(feedback);
                } else {
                    document.getElementById('nickErrorFeedback').textContent = data.error;
                }
            }
            
            throw new Error(data.error || 'Error desconocido');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const toast = new bootstrap.Toast(document.getElementById('toastError'));
        document.getElementById('errorMessage').textContent = error.message;
        toast.show();
    });
});

// Limpiar el estado de error cuando el usuario edita el nick
usuarioNickEditar.addEventListener('input', function() {
    this.classList.remove('is-invalid');
});
    // Función de búsqueda
    searchInput.addEventListener('input', function(e) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            buscarUsuarios(e.target.value);
        }, 300);
    });

    // Manejar eventos de admin
    tablaUsuarios.addEventListener('click', function(e) {
        const botonAdmin = e.target.closest('.hacer-admin');
        const botonQuitarAdmin = e.target.closest('.quitar-admin');
        
        if (botonAdmin) {
            if (confirm('¿Estás seguro de que quieres hacer admin a este usuario?')) {
                const userId = botonAdmin.dataset.id;
                cambiarEstadoAdmin(userId, 'hacer_admin', 'Usuario convertido en admin correctamente');
            }
        }
        
        if (botonQuitarAdmin) {
            if (confirm('¿Estás seguro de que quieres quitar los permisos de admin a este usuario?')) {
                const userId = botonQuitarAdmin.dataset.id;
                cambiarEstadoAdmin(userId, 'quitar_admin', 'Permisos de admin quitados correctamente');
            }
        }
    });

    // Manejar salir de crew
    tablaUsuarios.addEventListener('click', function(e) {
        const botonSalirCrew = e.target.closest('.btn-salir-crew');
        if (botonSalirCrew) {
            const userId = botonSalirCrew.dataset.id;
            const crewNombre = botonSalirCrew.dataset.crew;
            
            if (confirm(`¿Estás seguro de que quieres sacar a este usuario del crew "${crewNombre}"?`)) {
                cambiarEstadoCrew(userId, 'salir_crew', `Usuario sacado del crew "${crewNombre}" correctamente`);
            }
        }
    });

    // Manejar salir de evento
   tablaUsuarios.addEventListener('click', function(e) {
    const botonSalirEvento = e.target.closest('.btn-salir-evento');
    if (botonSalirEvento) {
        // Detener la propagación del evento
        const userId = botonSalirEvento.dataset.idUsuario;
        const eventoId = botonSalirEvento.dataset.idEvento;
        const eventoNombre = botonSalirEvento.dataset.evento;
        
        if (confirm(`¿Estás seguro de que quieres sacar a este usuario del evento "${eventoNombre}"?`)) {
            salirDeEvento(userId, eventoId, `Usuario sacado del evento "${eventoNombre}" correctamente`);
        }
    }
});
    async function cambiarEstadoAdmin(userId, accion, mensajeExito) {
        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=${accion}&id=${userId}`
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Error en la respuesta del servidor');
            }
            
            let data;
            try {
                data = await response.json();
            } catch (e) {
                throw new Error('La respuesta del servidor no es válida');
            }
            
            if (data.success) {
                buscarUsuarios(searchInput.value);
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = mensajeExito;
                toast.show();
            } else {
                throw new Error(data.error || 'Error desconocido al procesar la solicitud');
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    }

   async function cambiarEstadoCrew(userId, accion, crewNombre) {
    try {
        const response = await fetch('funciones_admin/usuarios.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=${accion}&id=${userId}`
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText || 'Error en la respuesta del servidor');
        }
        
        let data;
        try {
            data = await response.json();
        } catch (e) {
            throw new Error('La respuesta del servidor no es válida');
        }
        
        if (data.necesita_reemplazo_crew) {
            // Mostrar modal para seleccionar nuevo admin
            mostrarModalReemplazoCrew(data, userId, crewNombre);
        } else if (data.success) {
            buscarUsuarios(searchInput.value);
            
            const toast = new bootstrap.Toast(document.getElementById('toastExito'));
            document.getElementById('toastMessage').textContent = `Usuario sacado del crew "${crewNombre}" correctamente`;
            toast.show();
        } else {
            throw new Error(data.error || 'Error desconocido al procesar la solicitud');
        }
    } catch (error) {
        console.error('Error:', error);
        const toast = new bootstrap.Toast(document.getElementById('toastError'));
        document.getElementById('errorMessage').textContent = error.message;
        toast.show();
    }
}

    async function salirDeEvento(userId, eventoId, eventoNombre) {
        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=salir_evento&idUsuario=${userId}&idEvento=${eventoId}`
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Error en la respuesta del servidor');
            }
            
            let data;
            try {
                data = await response.json();
            } catch (e) {
                throw new Error('La respuesta del servidor no es válida');
            }
            
            if (data.necesita_reemplazo_evento) {
                // Mostrar modal para seleccionar nuevo admin
                mostrarModalReemplazoEvento(data, userId, eventoId, eventoNombre);
            } else if (data.success) {
                buscarUsuarios(searchInput.value);
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = `Usuario sacado del evento "${eventoNombre}" correctamente`;
                toast.show();
            } else {
                throw new Error(data.error || 'Error desconocido al procesar la solicitud');
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    }

    function mostrarModalReemplazoCrew(data, userId, crewNombre) {
        const modalHTML = `
            <div class="modal fade" id="reemplazoCrewModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-warning">
                            <h5 class="modal-title">Reemplazar administrador del crew</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Este usuario es administrador del crew "${crewNombre}". Seleccione un nuevo administrador o el crew será eliminado.</p>
                            
                            ${data.miembros.length > 0 ? `
                            <div class="mb-3">
                                <label class="form-label">Seleccionar nuevo administrador:</label>
                                <select class="form-select" id="nuevoAdminCrew">
                                    <option value="">Seleccionar...</option>
                                    ${data.miembros.map(miembro => `
                                        <option value="${miembro.idUsu}">${miembro.Nick}</option>
                                    `).join('')}
                                </select>
                            </div>
                            ` : `
                            <div class="alert alert-warning">
                                No hay otros miembros en este crew. El crew será eliminado.
                            </div>
                            `}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn btn-primary" id="confirmarSalirCrew">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        const modal = new bootstrap.Modal(document.getElementById('reemplazoCrewModal'));
        modal.show();
        
        document.getElementById('confirmarSalirCrew').addEventListener('click', async function() {
            const idNuevoAdmin = document.getElementById('nuevoAdminCrew')?.value || null;
            
            try {
                const response = await fetch('funciones_admin/usuarios.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=reemplazar_admin_crew&idUsuario=${userId}&idCrew=${data.idCrew}&idNuevoAdmin=${idNuevoAdmin}`
                });
                
                if (!response.ok) {
                    throw new Error('Error en la respuesta del servidor');
                }
                
                const responseData = await response.json();
                
                if (responseData.success) {
                    buscarUsuarios(searchInput.value);
                    modal.hide();
                    
                    const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                    document.getElementById('toastMessage').textContent = idNuevoAdmin 
                        ? `Nuevo administrador asignado y usuario sacado del crew "${crewNombre}"`
                        : `Crew "${crewNombre}" eliminado y usuario sacado`;
                    toast.show();
                    
                    document.getElementById('reemplazoCrewModal').addEventListener('hidden.bs.modal', function() {
                        this.remove();
                    });
                } else {
                    throw new Error(responseData.error || 'Error desconocido');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
            }
        });
        
        document.getElementById('reemplazoCrewModal').addEventListener('hidden.bs.modal', function() {
            this.remove();
        });
    }

        function mostrarModalReemplazoEvento(data, userId, eventoId, eventoNombre) {
        const modalHTML = `
            <div class="modal fade" id="reemplazoEventoModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-warning">
                            <h5 class="modal-title">Reemplazar administrador del evento</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Este usuario es administrador del evento "${eventoNombre}". Seleccione un nuevo administrador o el evento será eliminado.</p>
                            
                            ${data.participantes.length > 0 ? `
                            <div class="mb-3">
                                <label class="form-label">Seleccionar nuevo administrador:</label>
                                <select class="form-select" id="nuevoAdminEvento">
                                    <option value="">Seleccionar...</option>
                                    ${data.participantes.map(participante => `
                                        <option value="${participante.idUsu}">${participante.Nick}</option>
                                    `).join('')}
                                </select>
                            </div>
                            ` : `
                            <div class="alert alert-warning">
                                No hay otros participantes en este evento. El evento será eliminado.
                            </div>
                            `}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn btn-primary" id="confirmarSalirEvento">Confirmar</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        const modal = new bootstrap.Modal(document.getElementById('reemplazoEventoModal'));
        modal.show();
        
        document.getElementById('confirmarSalirEvento').addEventListener('click', async function() {
            const idNuevoAdmin = document.getElementById('nuevoAdminEvento')?.value || null;
             
            try {
                const response = await fetch('funciones_admin/usuarios.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=reemplazar_admin_evento&idUsuario=${userId}&idEvento=${eventoId}&idNuevoAdmin=${idNuevoAdmin}`
                });
                
                if (!response.ok) {
                    throw new Error('Error en la respuesta del servidor');
                }
                
                const responseData = await response.json();
                
                if (responseData.success) {
                    buscarUsuarios(searchInput.value);
                    modal.hide();
                    
                    const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                    document.getElementById('toastMessage').textContent = idNuevoAdmin 
                        ? `Nuevo administrador asignado y usuario sacado del evento "${eventoNombre}"`
                        : `Evento "${eventoNombre}" eliminado y usuario sacado`;
                    toast.show();
                    
                    document.getElementById('reemplazoEventoModal').addEventListener('hidden.bs.modal', function() {
                        this.remove();
                    });
                } else {
                    throw new Error(responseData.error || 'Error desconocido');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
            }
        });
        
        document.getElementById('reemplazoEventoModal').addEventListener('hidden.bs.modal', function() {
            this.remove();
        });
        }
 function mostrarModalEliminarUsuario(data, userId) {
    // Eliminar cualquier modal existente
    const existingModal = document.getElementById('eliminarUsuarioModal');
    if (existingModal) {
        existingModal.remove();
    }

    let modalHTML = `
        <div class="modal fade" id="eliminarUsuarioModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">Eliminar Usuario</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>¿Estás seguro de que deseas eliminar este usuario permanentemente?</p>
    `;

    // Sección para crews si el usuario es admin de alguno
    if (data.es_admin_crew && data.crews && data.crews.length > 0) {
        modalHTML += `
            <div class="mb-4">
                <h6 class="fw-bold">Reemplazar administrador en crews:</h6>
                ${data.crews.map(crew => `
                    <div class="mb-3">
                        <label class="form-label">Crew: ${crew.Nombre}</label>
                        ${crew.miembros && crew.miembros.length > 0 ? `
                        <select class="form-select mb-2 select-reemplazo-crew" data-crew-id="${crew.idCrew}">
                            <option value="">Seleccionar nuevo admin...</option>
                            ${crew.miembros.map(miembro => `
                                <option value="${miembro.idUsu}">${miembro.Nick}</option>
                            `).join('')}
                        </select>
                        ` : `
                        <div class="alert alert-warning">
                            No hay otros miembros en este crew. El crew será eliminado.
                        </div>
                        `}
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Sección para eventos si el usuario es admin de alguno
    if (data.es_admin_evento && data.eventos && data.eventos.length > 0) {
        modalHTML += `
            <div class="mb-4">
                <h6 class="fw-bold">Reemplazar administrador en eventos:</h6>
                ${data.eventos.map(evento => `
                    <div class="mb-3">
                        <label class="form-label">Evento: ${evento.Nombre}</label>
                        ${evento.participantes && evento.participantes.length > 0 ? `
                        <select class="form-select mb-2 select-reemplazo-evento" data-evento-id="${evento.idEvento}">
                            <option value="">Seleccionar nuevo admin...</option>
                            ${evento.participantes.map(participante => `
                                <option value="${participante.idUsu}">${participante.Nick}</option>
                            `).join('')}
                        </select>
                        ` : `
                        <div class="alert alert-warning">
                            No hay otros participantes en este evento. El evento será eliminado.
                        </div>
                        `}
                    </div>
                `).join('')}
            </div>
        `;
    }

    modalHTML += `
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-danger" id="confirmarEliminarUsuario">Eliminar</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Insertar el modal en el DOM
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Mostrar el modal
    const modal = new bootstrap.Modal(document.getElementById('eliminarUsuarioModal'));
    modal.show();

    // Manejar el evento de confirmación
    document.getElementById('confirmarEliminarUsuario').addEventListener('click', async function() {
        const reemplazos = {
            crew: {},
            evento: {}
        };

        // Validar y recolectar reemplazos para crews
        if (data.es_admin_crew && data.crews) {
            for (const crew of data.crews) {
                const selectElement = document.querySelector(`.select-reemplazo-crew[data-crew-id="${crew.idCrew}"]`);
                
                if (selectElement) {
                    // Hay miembros disponibles para seleccionar
                    reemplazos.crew[crew.idCrew] = selectElement.value || null;
                } else {
                    // No hay miembros, se eliminará el crew
                    reemplazos.crew[crew.idCrew] = null;
                }
            }
        }

        // Validar y recolectar reemplazos para eventos
        if (data.es_admin_evento && data.eventos) {
            for (const evento of data.eventos) {
                const selectElement = document.querySelector(`.select-reemplazo-evento[data-evento-id="${evento.idEvento}"]`);
                
                if (selectElement) {
                    // Hay participantes disponibles para seleccionar
                    reemplazos.evento[evento.idEvento] = selectElement.value || null;
                } else {
                    // No hay participantes, se eliminará el evento
                    reemplazos.evento[evento.idEvento] = null;
                }
            }
        }

        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=eliminar_con_reemplazo&id=${userId}&reemplazos=${JSON.stringify(reemplazos)}`
            });

            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }

            const responseData = await response.json();

            if (responseData.success) {
                buscarUsuarios(document.getElementById('searchUsuarios').value);
                modal.hide();

                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = 'Usuario eliminado correctamente';
                toast.show();
            } else {
                throw new Error(responseData.error || 'Error desconocido');
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    });

    // Limpiar el modal cuando se cierre
    document.getElementById('eliminarUsuarioModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

    async function buscarUsuarios(termino) {
        try {
            const response = await fetch(`funciones_admin/buscar.php?tipo=usuarios&q=${encodeURIComponent(termino)}`);
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            const html = await response.text();
            tablaUsuarios.innerHTML = html || '<tr><td colspan="7" class="text-center">No se encontraron usuarios</td></tr>';
        } catch (error) {
            console.error('Error al buscar usuarios:', error);
            tablaUsuarios.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Error al cargar los datos</td></tr>';
        }
    }

    // usuario.js - Agregar esto dentro del evento DOMContentLoaded

// Evento para eliminar usuario
 tablaUsuarios.addEventListener('click', async function(e) {
    const botonEliminar = e.target.closest('.eliminar-usuario');
    if (botonEliminar) {
        const userId = botonEliminar.dataset.id;
        
        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=verificar_eliminar&id=${userId}`
            });
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const data = await response.json();
            
            if (data.necesita_reemplazo) {
                // Mostrar el modal de eliminación con opciones de reemplazo
                mostrarModalEliminarUsuario(data, userId);
            } else {
                // Confirmación simple para usuarios no admin
                if (confirm('¿Estás seguro de que quieres eliminar este usuario?')) {
                    eliminarUsuarioDirecto(userId);
                }
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    }
});

function mostrarModalReemplazoCrew(data, userId, crewNombre) {
    const modalHTML = `
        <div class="modal fade" id="reemplazoCrewModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-warning">
                        <h5 class="modal-title">Reemplazar administrador del crew</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Este usuario es administrador del crew "${crewNombre}".</p>
                        ${data.miembros && data.miembros.length > 0 ? `
                        <div class="mb-3">
                            <label class="form-label">Seleccionar nuevo administrador:</label>
                            <select class="form-select" id="nuevoAdminCrew">
                                <option value="">Seleccionar...</option>
                                ${data.miembros.map(miembro => `
                                    <option value="${miembro.idUsu}">${miembro.Nick}</option>
                                `).join('')}
                            </select>
                        </div>
                        ` : `
                        <div class="alert alert-warning">
                            No hay otros miembros en este crew. El crew será eliminado si continúa.
                        </div>
                        `}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" id="confirmarSalirCrew">Confirmar</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    const modal = new bootstrap.Modal(document.getElementById('reemplazoCrewModal'));
    modal.show();
    
    document.getElementById('confirmarSalirCrew').addEventListener('click', async function() {
        const selectElement = document.getElementById('nuevoAdminCrew');
        const idNuevoAdmin = selectElement ? selectElement.value : null;
        
        // Validación solo si hay miembros disponibles
        if (data.miembros && data.miembros.length > 0 && !idNuevoAdmin) {
            alert('Por favor seleccione un nuevo administrador');
            return;
        }
        
        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=reemplazar_admin_crew&idUsuario=${userId}&idCrew=${data.idCrew}&idNuevoAdmin=${idNuevoAdmin || ''}`
            });
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const responseData = await response.json();
            
            if (responseData.success) {
                buscarUsuarios(searchInput.value);
                modal.hide();
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = idNuevoAdmin 
                    ? `Nuevo administrador asignado y usuario sacado del crew "${crewNombre}"`
                    : `Crew "${crewNombre}" eliminado correctamente`;
                toast.show();
                
                document.getElementById('reemplazoCrewModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
            } else {
                throw new Error(responseData.error || 'Error desconocido');
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    });
    
    document.getElementById('reemplazoCrewModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
    }

    function mostrarModalReemplazoEvento(data, userId, eventoId, eventoNombre) {
    const modalHTML = `
        <div class="modal fade" id="reemplazoEventoModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-warning">
                        <h5 class="modal-title">Reemplazar administrador del evento</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Este usuario es administrador del evento "${eventoNombre}".</p>
                        ${data.participantes && data.participantes.length > 0 ? `
                        <div class="mb-3">
                            <label class="form-label">Seleccionar nuevo administrador:</label>
                            <select class="form-select" id="nuevoAdminEvento">
                                <option value="">Seleccionar...</option>
                                ${data.participantes.map(participante => `
                                    <option value="${participante.idUsu}">${participante.Nick}</option>
                                `).join('')}
                            </select>
                        </div>
                        ` : `
                        <div class="alert alert-warning">
                            No hay otros participantes en este evento. El evento será eliminado si continúa.
                        </div>
                        `}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn btn-primary" id="confirmarSalirEvento">Confirmar</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    const modal = new bootstrap.Modal(document.getElementById('reemplazoEventoModal'));
    modal.show();
    
    document.getElementById('confirmarSalirEvento').addEventListener('click', async function() {
        const selectElement = document.getElementById('nuevoAdminEvento');
        const idNuevoAdmin = selectElement ? selectElement.value : null;
        
        // Validación solo si hay participantes disponibles
        if (data.participantes && data.participantes.length > 0 && !idNuevoAdmin) {
            alert('Por favor seleccione un nuevo administrador');
            return;
        }
        
        try {
            const response = await fetch('funciones_admin/usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=reemplazar_admin_evento&idUsuario=${userId}&idEvento=${eventoId}&idNuevoAdmin=${idNuevoAdmin || ''}`
            });
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const responseData = await response.json();
            
            if (responseData.success) {
                buscarUsuarios(searchInput.value);
                modal.hide();
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = idNuevoAdmin 
                    ? `Nuevo administrador asignado y usuario sacado del evento "${eventoNombre}"`
                    : `Evento "${eventoNombre}" eliminado correctamente`;
                toast.show();
                
                document.getElementById('reemplazoEventoModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
            } else {
                throw new Error(responseData.error || 'Error desconocido');
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    });
    
    document.getElementById('reemplazoEventoModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}   

async function eliminarUsuarioDirecto(userId) {
    try {
        // Primero verificamos si necesita reemplazo
        const verifyResponse = await fetch('funciones_admin/usuarios.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=verificar_eliminar&id=${userId}`
        });
        
        if (!verifyResponse.ok) {
            throw new Error('Error al verificar el usuario');
        }
        
        const verifyData = await verifyResponse.json();
        
        // Si necesita reemplazo, mostramos el modal
        if (verifyData.necesita_reemplazo) {
            mostrarModalEliminarUsuario(verifyData, userId);
            return;
        }
        
        // Si no necesita reemplazo, primero sacamos al usuario de su crew y eventos
        const prepararEliminacion = await fetch('funciones_admin/usuarios.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=preparar_eliminar&id=${userId}`
        });
        
        if (!prepararEliminacion.ok) {
            throw new Error('Error al preparar la eliminación');
        }
        
        // Luego procedemos con la eliminación
        const response = await fetch('funciones_admin/usuarios.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=eliminar&id=${userId}`
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(errorText || 'Error en la respuesta del servidor');
        }
        
        const data = await response.json();
        
        if (data.success) {
            buscarUsuarios(document.getElementById('searchUsuarios').value);
            
            const toast = new bootstrap.Toast(document.getElementById('toastExito'));
            document.getElementById('toastMessage').textContent = 'Usuario eliminado correctamente';
            toast.show();
        } else {
            throw new Error(data.error || 'Error desconocido');
        }
    } catch (error) {
        console.error('Error:', error);
        const toast = new bootstrap.Toast(document.getElementById('toastError'));
        document.getElementById('errorMessage').textContent = error.message;
        toast.show();
    }
}
});