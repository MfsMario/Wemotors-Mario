document.addEventListener('DOMContentLoaded', function() {
    // Manejar la eliminación de reportes
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('eliminar-reporte') || e.target.closest('.eliminar-reporte')) {
            const btn = e.target.classList.contains('eliminar-reporte') ? e.target : e.target.closest('.eliminar-reporte');
            const idReporte = btn.getAttribute('data-idreporte');
            const tipo = btn.getAttribute('data-tipo');
            const id = btn.getAttribute('data-id');
            
            if (confirm('¿Estás seguro de que deseas eliminar este reporte?')) {
                eliminarReporte(idReporte, tipo, id, btn);
            }
        }
    });
    
    // Función para buscar reportes
    const searchReportes = document.getElementById('searchReportes');
    if (searchReportes) {
        searchReportes.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#reportes tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});

function eliminarReporte(idReporte, tipo, id, btnElement) {
    fetch('funciones_admin/reportes.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=eliminar&idReporte=${idReporte}&tipo=${tipo}&id=${id}`
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Mostrar toast de éxito
            const toast = new bootstrap.Toast(document.getElementById('toastExito'));
            document.getElementById('toastMessage').textContent = data.message || 'Reporte eliminado correctamente';
            toast.show();
            
            // Eliminar la fila de la tabla
            btnElement.closest('tr').remove();
        } else {
            // Mostrar toast de error
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = data.message || 'Error al eliminar el reporte';
            toast.show();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const toast = new bootstrap.Toast(document.getElementById('toastError'));
        document.getElementById('errorMessage').textContent = 'Error en la conexión';
        toast.show();
        
        // Forzar recarga si hubo error pero el reporte se eliminó
        setTimeout(() => {
            window.location.reload();
        }, 2000);
    });
}