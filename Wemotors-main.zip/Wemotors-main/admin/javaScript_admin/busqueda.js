document.addEventListener('DOMContentLoaded', function() {
    // Búsqueda de usuarios
    const searchUsuarios = document.getElementById('searchUsuarios');
    if (searchUsuarios) {
        searchUsuarios.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tabla-usuarios tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda de crews
    const searchCrews = document.getElementById('searchCrews');
    if (searchCrews) {
        searchCrews.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tabla-crews tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda de eventos
    const searchEventos = document.getElementById('searchEventos');
    if (searchEventos) {
        searchEventos.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tabla-eventos tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
    
    // Búsqueda de publicaciones
    const searchPublicaciones = document.getElementById('searchPublicaciones');
    if (searchPublicaciones) {
        searchPublicaciones.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const cards = document.querySelectorAll('#contenedor-publicaciones .card');
            
            cards.forEach(card => {
                const text = card.textContent.toLowerCase();
                card.closest('.col-md-4').style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});