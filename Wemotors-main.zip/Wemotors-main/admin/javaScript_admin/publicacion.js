document.addEventListener('DOMContentLoaded', function() {
    // Mover las declaraciones de variables aquí dentro
    const contenedorPublicaciones = document.getElementById('contenedor-publicaciones');
    let usuarioSeleccionado = null;

    // Estado inicial - Mostrar instrucciones
    mostrarEstadoInicial();

    function mostrarEstadoInicial() {
        if (!contenedorPublicaciones) return;
        
        contenedorPublicaciones.innerHTML = `
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <h5>Buscar publicaciones por usuario</h5>
                        <p class="text-muted">Utiliza el buscador para encontrar usuarios</p>
                    </div>
                </div>
            </div>
        `;
    }

    // Mostrar buscador de usuarios al entrar a la pestaña
    const publicacionesTab = document.getElementById('publicaciones-tab');
    if (publicacionesTab) {
        publicacionesTab.addEventListener('click', mostrarBuscadorUsuarios);
    }

    function mostrarBuscadorUsuarios() {
        if (!contenedorPublicaciones) return;
        
        usuarioSeleccionado = null;
        contenedorPublicaciones.innerHTML = `
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <h5>Buscar publicaciones por usuario</h5>
                        <div class="search-box mt-3 mx-auto" style="max-width: 500px;">
                            <i class="bi bi-search search-icon"></i>
                            <input type="text" class="form-control search-input" 
                                   id="searchUsuariosPublicaciones" placeholder="Escribe el nombre o email del usuario...">
                        </div>
                        <div id="resultados-usuarios" class="mt-3">
                            <p class="text-muted">Los resultados aparecerán aquí</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        const searchInput = document.getElementById('searchUsuariosPublicaciones');
        if (searchInput) {
            searchInput.addEventListener('input', function(e) {
                buscarUsuariosPublicaciones(e.target.value);
            });
        }
        
        // Mostrar todos los usuarios inicialmente
        buscarUsuariosPublicaciones('');
    }

    async function buscarUsuariosPublicaciones(termino) {
        const resultadosDiv = document.getElementById('resultados-usuarios');
        if (!resultadosDiv) return;
        
        try {
            const response = await fetch(`funciones_admin/buscar.php?tipo=usuarios_publicaciones&q=${encodeURIComponent(termino)}`);
            const usuarios = await response.json();
            
            let html = '<div class="list-group">';
            if (usuarios.length > 0) {
                usuarios.forEach(usuario => {
                 html += `
                    <a href="#" class="list-group-item list-group-item-action usuario-seleccionado" 
                    data-id="${usuario.idUsu}" data-nombre="${usuario.Nombre}">
                        <div class="d-flex align-items-center">
                            <img src="${usuario.FotoPerfil}" class="rounded-circle me-3" style="width: 40px; height: 40px; object-fit: cover;">
                            <div>
                                <strong>${usuario.Nombre}</strong><br>
                                <small>${usuario.Email}</small>
                            </div>
                        </div>
                    </a>
                `;
                });
            } else {
                html += '<div class="list-group-item">No se encontraron usuarios</div>';
            }
            html += '</div>';

            resultadosDiv.innerHTML = html;

            // Configurar evento click para los usuarios
            document.querySelectorAll('.usuario-seleccionado').forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    usuarioSeleccionado = {
                        id: this.dataset.id,
                        nombre: this.dataset.nombre
                    };
                    cargarPublicacionesUsuario(usuarioSeleccionado.id, usuarioSeleccionado.nombre);
                });
            });
        } catch (error) {
            console.error('Error al buscar usuarios:', error);
            resultadosDiv.innerHTML = '<div class="alert alert-danger">Error al buscar usuarios</div>';
        }
    }

    async function cargarPublicacionesUsuario(idUsuario, nombreUsuario) {
        if (!contenedorPublicaciones) return;
        
        try {
            const response = await fetch(`funciones_admin/publicaciones.php?idUsuario=${idUsuario}`);
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const publicacionesHTML = await response.text();
            
            contenedorPublicaciones.innerHTML = `
                <div class="col-12 mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4>Publicaciones de ${nombreUsuario}</h4>
                        <button class="btn btn-sm btn-outline-secondary" id="volver-busqueda">
                            <i class="bi bi-arrow-left"></i> Volver a buscar
                        </button>
                    </div>
                    <hr>
                </div>
                <div class="row" id="galeria-publicaciones">
                    ${publicacionesHTML}
                </div>
            `;

            const volverBtn = document.getElementById('volver-busqueda');
            if (volverBtn) {
                volverBtn.addEventListener('click', mostrarBuscadorUsuarios);
            }

            // Configurar eventos para los botones de editar y eliminar
            configurarEventosPublicaciones();
        } catch (error) {
            console.error('Error al cargar publicaciones:', error);
            contenedorPublicaciones.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-danger">
                        Error al cargar las publicaciones del usuario
                    </div>
                </div>
            `;
        }
    }

     async function cargarMarcas() {
        try {
            const response = await fetch('funciones_admin/buscar.php?tipo=marcas');
            return await response.json();
        } catch (error) {
            console.error('Error al cargar marcas:', error);
            return [];
        }
    }

  async function cargarComentariosPublicacion(idPublicacion) {
    try {
        const response = await fetch(`./funciones_admin/buscar.php?idPublicacion=${idPublicacion}&tipo=comentarios`);

        if (!response.ok) {
            throw new Error('Error al cargar comentarios: ' + response.statusText);
        }
        
        const result = await response.json();
        
        // Verificar si la respuesta tiene éxito y datos
        if (!result.success || !result.data) {
            throw new Error(result.error || 'Datos de comentarios no válidos');
        }
        
        const comentarios = result.data;
        const contenedorComentarios = document.getElementById('contenedor-comentarios');
        
        if (!contenedorComentarios) return;
        
        let html = '<h6 class="mt-3 mb-3">Comentarios</h6>';
        
        if (comentarios.length > 0) {
            comentarios.forEach(comentario => {
                const fotoPerfil = comentario.FotoPerfil ? 
                    'data:image/jpeg;base64,' + comentario.FotoPerfil : 
                    'assets/img/default-profile.png';
                
                        html += `
            <div class="card mb-2 comentario-item" data-id="${comentario.idComentario}">
                <div class="card-body p-2">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="d-flex">
                            <img src="${fotoPerfil}" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                            <div>
                                <strong>${comentario.Nick}</strong>
                                <p class="mb-1 small">${comentario.texto}</p>
                                <small class="text-muted">${new Date(comentario.fecCom).toLocaleString()}</small>
                            </div>
                        </div>
                        <button class="btn btn-sm btn-outline-danger eliminar-comentario">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
`;
            });
        } else {
            html += '<p class="text-muted small">No hay comentarios</p>';
        }
        
        contenedorComentarios.innerHTML = html;
        
        // Configurar eventos para los botones de eliminar
      document.querySelectorAll('.eliminar-comentario').forEach(btn => {
        btn.addEventListener('click', async function(e) {
        e.preventDefault(); // Prevenir el comportamiento por defecto
        
        const comentarioItem = this.closest('.comentario-item');
        const idComentario = comentarioItem.dataset.id;
        
        if (confirm('¿Estás seguro de que quieres eliminar este comentario?')) {
            try {
                const response = await fetch('./funciones_admin/publicaciones.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=eliminar_comentario&idComentario=${idComentario}`
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Mostrar toast de éxito
                    const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                    document.getElementById('toastMessage').textContent = result.message || 'Comentario eliminado correctamente';
                    toast.show();
                    
                    // Eliminar el comentario del DOM sin recargar
                    comentarioItem.remove();
                    
                    // Opcional: Mostrar mensaje si no quedan comentarios
                    if (document.querySelectorAll('.comentario-item').length === 0) {
                        document.getElementById('contenedor-comentarios').innerHTML += 
                            '<p class="text-muted small">No hay comentarios</p>';
                    }
                } else {
                    throw new Error(result.message || 'Error al eliminar el comentario');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
             }
            }
        });
    });
    } catch (error) {
        console.error('Error al cargar comentarios:', error);
        const contenedorComentarios = document.getElementById('contenedor-comentarios');
        if (contenedorComentarios) {
            contenedorComentarios.innerHTML = `
                <div class="alert alert-danger">
                    Error al cargar los comentarios: ${error.message}
                </div>
            `;
        }
    }
}

// Modificar la función configurarEventosPublicaciones para incluir los comentarios
function configurarEventosPublicaciones() {
    // Configurar evento click para editar publicación
    document.querySelectorAll('.editar-publicacion').forEach(async btn => {
        btn.addEventListener('click', async function() {
            const id = this.dataset.id;
            const descripcion = this.dataset.descripcion;
            const foto = this.dataset.foto;
            const marcaId = this.dataset.marcaId;
            
            // Cargar marcas disponibles
            const marcas = await cargarMarcas();
            
            // Mostrar modal de edición
            const modal = new bootstrap.Modal(document.getElementById('editarPublicacionModal'));
            const marcaSelect = document.getElementById('publicacionMarcaEditar');
            
            // Limpiar y llenar el select de marcas
            marcaSelect.innerHTML = '<option value="">Seleccionar marca</option>';
            marcas.forEach(marca => {
                const option = document.createElement('option');
                option.value = marca.idMarca;
                option.textContent = marca.Nombre;
                option.selected = (marca.idMarca == marcaId);
                marcaSelect.appendChild(option);
            });
            
            document.getElementById('publicacionIdEditar').value = id;
            document.getElementById('publicacionDescripcionEditar').value = descripcion;
            document.getElementById('previewFotoPublicacion').src = foto;
            
            // Cargar comentarios
            await cargarComentariosPublicacion(id);
            
            modal.show();
        });
    });
        // Configurar evento para previsualizar imagen
        const fotoInput = document.getElementById('publicacionFotoEditar');
        if (fotoInput) {
            fotoInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        document.getElementById('previewFotoPublicacion').src = event.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        // Configurar evento para guardar cambios
         const guardarBtn = document.getElementById('guardarCambiosPublicacion');
        if (guardarBtn) {
            guardarBtn.addEventListener('click', async function() {
                const id = document.getElementById('publicacionIdEditar').value;
                const marcaId = document.getElementById('publicacionMarcaEditar').value;
                const descripcion = document.getElementById('publicacionDescripcionEditar').value;
                const fotoInput = document.getElementById('publicacionFotoEditar');
                const fotoFile = fotoInput.files[0];
                
                const formData = new FormData();
                formData.append('id', id);
                formData.append('marcaId', marcaId);
                formData.append('descripcion', descripcion);
                if (fotoFile) {
                    formData.append('foto', fotoFile);
                }

                try {
                    const response = await fetch('funciones_admin/publicaciones.php', {
                        method: 'POST',
                        body: formData
                    });

                    const result = await response.json();
                    
                    if (result.success) {
                        // Mostrar toast de éxito
                        const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                        document.getElementById('toastMessage').textContent = 'Publicación actualizada correctamente';
                        toast.show();
                        
                        // Cerrar modal
                        const modal = bootstrap.Modal.getInstance(document.getElementById('editarPublicacionModal'));
                        modal.hide();
                        
                        // Recargar publicaciones si estamos viendo las de un usuario
                        if (usuarioSeleccionado) {
                            cargarPublicacionesUsuario(usuarioSeleccionado.id, usuarioSeleccionado.nombre);
                        }
                    } else {
                        throw new Error(result.message || 'Error al actualizar la publicación');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    const toast = new bootstrap.Toast(document.getElementById('toastError'));
                    document.getElementById('errorMessage').textContent = error.message;
                    toast.show();
                }
            });
        }
        document.querySelectorAll('.eliminar-publicacion').forEach(btn => {
    btn.addEventListener('click', async function() {
        const id = this.dataset.id;
        
        if (confirm('¿Estás seguro de que quieres eliminar esta publicación? Esta acción no se puede deshacer.')) {
            try {
                const response = await fetch('funciones_admin/publicaciones.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=eliminar_publicacion&id=${id}`
                });

                const result = await response.json();
                
                if (result.success) {
                    // Mostrar toast de éxito
                    const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                    document.getElementById('toastMessage').textContent = result.message || 'Publicación eliminada correctamente';
                    toast.show();
                    
                    // Eliminar la tarjeta de publicación del DOM
                    this.closest('.col-md-4').remove();
                    
                    // Mostrar mensaje si no quedan publicaciones
                    if (document.querySelectorAll('#galeria-publicaciones .col-md-4').length === 0) {
                        document.getElementById('galeria-publicaciones').innerHTML = `
                            <div class="col-12 text-center py-5">
                                <h5>No hay publicaciones para mostrar</h5>
                            </div>
                        `;
                    }
                } else {
                    throw new Error(result.message || 'Error al eliminar la publicación');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
            }
        }
    });
});
}




    // Mostrar buscador al cargar la página si está en la pestaña activa
    if (publicacionesTab && publicacionesTab.classList.contains('active')) {
        mostrarBuscadorUsuarios();
    }

    
});