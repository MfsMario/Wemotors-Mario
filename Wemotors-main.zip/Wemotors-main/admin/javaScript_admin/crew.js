document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchCrews');
    const tablaCrews = document.getElementById('tabla-crews');
    let timeoutId;

    // Elementos del modal de edición
    const editarCrewModal = new bootstrap.Modal(document.getElementById('editarCrewModal'));
    const previewFotoCrew = document.getElementById('previewFotoCrew');
    const crewFotoEditar = document.getElementById('crewFotoEditar');
    const crewNombreEditar = document.getElementById('crewNombreEditar');
    const crewAdminEditar = document.getElementById('crewAdminEditar');
    const crewIdEditar = document.getElementById('crewIdEditar');
    const guardarCambiosCrew = document.getElementById('guardarCambiosCrew');

    // Evento para previsualizar la imagen seleccionada
    crewFotoEditar.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewFotoCrew.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Evento para abrir el modal de edición
    tablaCrews.addEventListener('click', async function(e) {
        const botonEditar = e.target.closest('.editar-crew');
        if (botonEditar) {
            crewIdEditar.value = botonEditar.dataset.id;
            crewNombreEditar.value = botonEditar.dataset.nombre;
            
            if (botonEditar.dataset.imagen) {
                previewFotoCrew.src = botonEditar.dataset.imagen;
            } else {
                previewFotoCrew.src = 'assets/img/default-crew.jpg';
            }
            
            // Resetear el input de archivo
            crewFotoEditar.value = '';
            
            // Cargar miembros del crew
            try {
                const response = await fetch('funciones_admin/crews.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=obtener_miembros&idCrew=${botonEditar.dataset.id}`
                });
                
                if (!response.ok) {
                    throw new Error('Error al cargar miembros');
                }
                
                const data = await response.json();
                
                if (data.success) {
                    // Limpiar select
                    crewAdminEditar.innerHTML = '<option value="">Seleccionar administrador</option>';
                    
                    // Agregar miembros
                    data.miembros.forEach(miembro => {
                        const option = document.createElement('option');
                        option.value = miembro.idUsu;
                        option.textContent = miembro.Nick;
                        option.selected = (miembro.idUsu == botonEditar.dataset.admin);
                        crewAdminEditar.appendChild(option);
                    });
                } else {
                    throw new Error(data.error || 'Error al cargar miembros');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
            }
            
            editarCrewModal.show();
        }
    });

    // Evento para guardar los cambios
    guardarCambiosCrew.addEventListener('click', async function() {
    const nuevoNombre = crewNombreEditar.value.trim();
    const idCrew = crewIdEditar.value;
    
    // Primero validar si el nombre ya existe
    try {
        const validationResponse = await fetch('funciones_admin/crews.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=validar_nombre&nombre=${encodeURIComponent(nuevoNombre)}&id=${idCrew}`
        });
        
        const validationData = await validationResponse.json();
        
        if (!validationData.disponible) {
            // Mostrar error si el nombre ya existe
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = 'Ya existe una crew con ese nombre. Por favor, elige otro.';
            toast.show();
            return;
        }
        
        // Si el nombre está disponible, proceder con la actualización
        const formData = new FormData();
        formData.append('accion', 'actualizar');
        formData.append('id', idCrew);
        formData.append('nombre', nuevoNombre);
        formData.append('admin', crewAdminEditar.value);
        
        if (crewFotoEditar.files[0]) {
            formData.append('foto', crewFotoEditar.files[0]);
        }

        const updateResponse = await fetch('funciones_admin/crews.php', {
            method: 'POST',
            body: formData
        });
        
        if (!updateResponse.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        
        const data = await updateResponse.json();
        
        if (data.success) {
            buscarCrews(searchInput.value);
            editarCrewModal.hide();
            
            // Mostrar notificación de éxito
            const toast = new bootstrap.Toast(document.getElementById('toastExito'));
            document.getElementById('toastMessage').textContent = 'Crew actualizado correctamente';
            toast.show();
        } else {
            throw new Error(data.error || 'Error desconocido');
        }
    } catch (error) {
        console.error('Error:', error);
        // Mostrar notificación de error
        const toast = new bootstrap.Toast(document.getElementById('toastError'));
        document.getElementById('errorMessage').textContent = error.message;
        toast.show();
    }
});

    // Función de búsqueda
    searchInput.addEventListener('input', function(e) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            buscarCrews(e.target.value);
        }, 300);
    });

    async function buscarCrews(termino) {
        try {
            const response = await fetch(`funciones_admin/buscar.php?tipo=crews&q=${encodeURIComponent(termino)}`);
            const html = await response.text();
            tablaCrews.innerHTML = html || '<tr><td colspan="5" class="text-center">No se encontraron crews</td></tr>';
        } catch (error) {
            console.error('Error al buscar crews:', error);
            tablaCrews.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error al cargar los datos</td></tr>';
        }
    }

    tablaCrews.addEventListener('click', async function(e) {
    const botonEliminar = e.target.closest('.eliminar-crew');
    if (botonEliminar) {
        if (!confirm('¿Estás seguro de que quieres eliminar este crew? Todos los usuarios serán removidos del crew y las publicaciones dejarán de estar asociadas.')) {
            return;
        }
        
        try {
            const response = await fetch('funciones_admin/crews.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=eliminar&id=${botonEliminar.dataset.id}`
            });
            
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            
            const data = await response.json();
            
            if (data.success) {
                // Actualizar la tabla
                buscarCrews(searchInput.value);
                
                // Mostrar notificación de éxito
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = 'Crew eliminado correctamente';
                toast.show();
            } else {
                throw new Error(data.error || 'Error desconocido al eliminar');
            }
        } catch (error) {
            console.error('Error:', error);
            // Mostrar notificación de error
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    }
    });

    const miembrosCrewModal = new bootstrap.Modal(document.getElementById('miembrosCrewModal'));
const searchMiembrosCrew = document.getElementById('searchMiembrosCrew');
const listaMiembrosCrew = document.getElementById('listaMiembrosCrew');
const nombreCrewMiembros = document.getElementById('nombreCrewMiembros');
let crewIdActual = null;

// Evento para abrir modal de miembros
tablaCrews.addEventListener('click', function(e) {
    const botonVerMiembros = e.target.closest('.ver-miembros');
    if (botonVerMiembros) {
        crewIdActual = botonVerMiembros.dataset.id;
        nombreCrewMiembros.textContent = botonVerMiembros.dataset.nombre;
        searchMiembrosCrew.value = '';
        cargarMiembrosCrew('');
        miembrosCrewModal.show();
    }
});

// Búsqueda de miembros
let timeoutMiembros;
searchMiembrosCrew.addEventListener('input', function(e) {
    clearTimeout(timeoutMiembros);
    timeoutMiembros = setTimeout(() => {
        cargarMiembrosCrew(e.target.value);
    }, 300);
});

// Función para cargar miembros
async function cargarMiembrosCrew(busqueda) {
    try {
        const response = await fetch('funciones_admin/crews.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `accion=obtener_miembros_detalle&idCrew=${crewIdActual}&busqueda=${encodeURIComponent(busqueda)}`
        });
        
        if (!response.ok) {
            throw new Error(`Error HTTP! estado: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Error al obtener miembros');
        }

        let html = '';
        data.miembros.forEach(miembro => {
            // Manejar la foto de perfil
            const fotoSrc = miembro.FotoPerfil 
                ? `data:image/jpeg;base64,${miembro.FotoPerfil}`
                : 'assets/img/default-avatar.jpg';
            
            const esAdmin = miembro.idUsu == data.debug.idAdmin;
            
            html += `
                <div class="d-flex align-items-center justify-content-between p-3 border-bottom">
                    <div class="d-flex align-items-center">
                        <img src="${fotoSrc}" class="rounded-circle me-3" width="50" height="50" style="object-fit: cover;">
                        <div>
                            <h6 class="mb-0">${miembro.Nick}</h6>
                            ${esAdmin ? '<span class="badge bg-warning text-dark">Admin</span>' : ''}
                        </div>
                    </div>
                    ${!esAdmin ? `
                        <button class="btn btn-sm btn-outline-danger expulsar-miembro" 
                                data-id="${miembro.idUsu}" 
                                data-nick="${miembro.Nick}">
                            <i class="bi bi-person-dash"></i> Expulsar
                        </button>
                    ` : ''}
                </div>
            `;
        });
        
        if (html === '') {
            html = '<div class="text-center p-4 text-muted">No se encontraron miembros</div>';
        }
        
        listaMiembrosCrew.innerHTML = html;
    } catch (error) {
        console.error('Error:', error);
        listaMiembrosCrew.innerHTML = '<div class="text-center p-4 text-danger">Error al cargar miembros: ' + error.message + '</div>';
    }
}

// Evento para expulsar miembro
listaMiembrosCrew.addEventListener('click', async function(e) {
    const botonExpulsar = e.target.closest('.expulsar-miembro');
    if (botonExpulsar) {
        if (!confirm(`¿Estás seguro de que quieres expulsar a ${botonExpulsar.dataset.nick} del crew?`)) {
            return;
        }
        
        try {
            const response = await fetch('funciones_admin/crews.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `accion=expulsar_miembro&idUsuario=${botonExpulsar.dataset.id}`
            });
            
            const data = await response.json();
            
            if (data.success) {
                cargarMiembrosCrew(searchMiembrosCrew.value);
                buscarCrews(searchInput.value); // Actualizar tabla principal
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = 'Miembro expulsado correctamente';
                toast.show();
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = error.message;
            toast.show();
        }
    }
});

    
});