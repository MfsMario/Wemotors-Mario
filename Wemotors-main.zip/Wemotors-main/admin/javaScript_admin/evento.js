document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchEventos');
    const tablaEventos = document.getElementById('tabla-eventos');
    let nombreOriginalEvento = '';
    let timerVerificacion = null;

    let timeoutId;

    // Elementos del modal de edición
    const editarEventoModal = new bootstrap.Modal(document.getElementById('editarEventoModal'));
    const previewFotoEvento = document.getElementById('previewFotoEvento');
    const eventoFotoEditar = document.getElementById('eventoFotoEditar');
    const eventoNombreEditar = document.getElementById('eventoNombreEditar');
    const eventoLugarEditar = document.getElementById('eventoLugarEditar');
    const eventoFechaEditar = document.getElementById('eventoFechaEditar');
    const eventoIdEditar = document.getElementById('eventoIdEditar');
    const guardarCambiosEvento = document.getElementById('guardarCambiosEvento');

    // Evento para previsualizar la imagen seleccionada
    eventoFotoEditar.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewFotoEvento.src = e.target.result;
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    // Evento para abrir el modal de edición
   tablaEventos.addEventListener('click', function(e) {
    const botonEditar = e.target.closest('.editar-evento');
    if (botonEditar) {
        eventoIdEditar.value = botonEditar.dataset.id;
        eventoNombreEditar.value = botonEditar.dataset.nombre;
        eventoLugarEditar.value = botonEditar.dataset.lugar;
        eventoFechaEditar.value = botonEditar.dataset.fecha;
        
        // Mostrar la imagen actual del evento
        if (botonEditar.dataset.imagen && botonEditar.dataset.imagen !== 'assets/img/default-event.jpg') {
            previewFotoEvento.src = botonEditar.dataset.imagen;
        } else {
            // Si no hay imagen o es la default, puedes dejarlo vacío o mostrar un placeholder
            previewFotoEvento.src = 'assets/img/default-event.jpg';
        }
        
        // Resetear el input de archivo
        eventoFotoEditar.value = '';
        
        // Cargar participantes del evento
        cargarParticipantesEvento(botonEditar.dataset.id);
        
        editarEventoModal.show();
    }
    });
    // Función para cargar participantes del evento
    async function cargarParticipantesEvento(idEvento) {
        try {
            const response = await fetch(`funciones_admin/buscar.php?tipo=participantes_evento&idEvento=${idEvento}`);
            if (!response.ok) {
                throw new Error('Error al cargar participantes');
            }
            const participantes = await response.json();
            
            const selectAdmin = document.getElementById('eventoAdminEditar');
            selectAdmin.innerHTML = '';
            
            if (participantes.length === 0) {
                selectAdmin.innerHTML = '<option value="">No hay participantes</option>';
                return;
            }
            
            participantes.forEach(participante => {
                const option = document.createElement('option');
                option.value = participante.idUsu;
                option.textContent = participante.Nombre;
                if (participante.esAdmin) {
                    option.selected = true;
                }
                selectAdmin.appendChild(option);
            });
        } catch (error) {
            console.error('Error:', error);
            document.getElementById('eventoAdminEditar').innerHTML = '<option value="">Error al cargar participantes</option>';
        }
    }

    // Evento para guardar los cambios (modificar para incluir admin)
    guardarCambiosEvento.addEventListener('click', function() {
        const formData = new FormData();
        formData.append('accion', 'actualizar');
        formData.append('id', eventoIdEditar.value);
        formData.append('nombre', eventoNombreEditar.value);
        formData.append('lugar', eventoLugarEditar.value);
        formData.append('fecha', eventoFechaEditar.value);
        formData.append('admin', document.getElementById('eventoAdminEditar').value);
        
        if (eventoFotoEditar.files[0]) {
            formData.append('imagen', eventoFotoEditar.files[0]);
        }

        fetch('funciones_admin/eventos.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => {
                    throw new Error(text || 'Error en la respuesta del servidor');
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                buscarEventos(searchInput.value);
                editarEventoModal.hide();
                
                const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                document.getElementById('toastMessage').textContent = 'Evento actualizado correctamente';
                toast.show();
            } else {
                throw new Error(data.error || 'Error desconocido');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const toast = new bootstrap.Toast(document.getElementById('toastError'));
            document.getElementById('errorMessage').textContent = 'Error al actualizar el evento: ' + error.message;
            toast.show();
        });
    });

    // Función de búsqueda
    searchInput.addEventListener('input', function(e) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            buscarEventos(e.target.value);
        }, 300);
    });

    async function buscarEventos(termino) {
        try {
            const response = await fetch(`funciones_admin/buscar.php?tipo=eventos&q=${encodeURIComponent(termino)}`);
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            const html = await response.text();
            tablaEventos.innerHTML = html || '<tr><td colspan="6" class="text-center">No se encontraron eventos</td></tr>';
        } catch (error) {
            console.error('Error al buscar eventos:', error);
            tablaEventos.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Error al cargar los datos</td></tr>';
        }
    }

    document.addEventListener('click', async function(e) {
    const botonEliminar = e.target.closest('.eliminar-evento');
    if (botonEliminar) {
        const idEvento = botonEliminar.dataset.id;
        
        if (confirm('¿Estás seguro de que deseas eliminar este evento? Esta acción también desvinculará todas las publicaciones asociadas.')) {
            try {
                const response = await fetch('funciones_admin/eventos.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `accion=eliminar&id=${idEvento}`
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Mostrar toast de éxito
                    const toast = new bootstrap.Toast(document.getElementById('toastExito'));
                    document.getElementById('toastMessage').textContent = result.message || 'Evento eliminado correctamente';
                    toast.show();
                    
                    // Volver a cargar la tabla de eventos
                    buscarEventos(searchInput.value);
                } else {
                    throw new Error(result.error || 'Error al eliminar el evento');
                }
            } catch (error) {
                console.error('Error:', error);
                const toast = new bootstrap.Toast(document.getElementById('toastError'));
                document.getElementById('errorMessage').textContent = error.message;
                toast.show();
            }
        }
    }
    });
});