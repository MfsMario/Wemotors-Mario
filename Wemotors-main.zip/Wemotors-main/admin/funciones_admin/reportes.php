<?php
require_once("llamadabdd.php");

function mostrarReportes($pdo) {
    try {
        // Consulta actualizada para usar idReporte
        $query = "SELECT 
                    r.idReporte,
                    r.UsuNotificador, 
                    r.UsuReportado, 
                    r.crewReportada, 
                    r.EventoReportado, 
                    r.Descripcion,
                    un.Nick AS notificador_nick,
                    ur.Nick AS reportado_nick,
                    c.Nombre AS crew_nombre,
                    e.Nombre AS evento_nombre
                  FROM reportes r
                  LEFT JOIN usuarios un ON r.UsuNotificador = un.idUsu
                  LEFT JOIN usuarios ur ON r.UsuReportado = ur.idUsu
                  LEFT JOIN crews c ON r.crewReportada = c.idCrew
                  LEFT JOIN eventos e ON r.EventoReportado = e.idEvento";
        
        $stmt = $pdo->query($query);
        $reportes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($reportes)) {
            return '<div class="alert alert-info">No hay reportes pendientes.</div>';
        }
        
        $html = '<div class="table-responsive mobile-table-container">
                    <p class="mobile-table-hint d-md-none">Desliza horizontalmente para ver más contenido</p>
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">Notificador</th>
                                <th scope="col">Reportado</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>';
        
        foreach ($reportes as $reporte) {
            // Determinar qué fue reportado
            $reportado = '';
            if (!empty($reporte['UsuReportado'])) {
                $reportado = 'Usuario: ' . htmlspecialchars($reporte['reportado_nick']);
            } elseif (!empty($reporte['crewReportada'])) {
                $reportado = 'Crew: ' . htmlspecialchars($reporte['crew_nombre']);
            } elseif (!empty($reporte['EventoReportado'])) {
                $reportado = 'Evento: ' . htmlspecialchars($reporte['evento_nombre']);
            }
            
            // Mostrar "Anónimo" si no hay notificador
            $notificador = !empty($reporte['notificador_nick']) ? 
                htmlspecialchars($reporte['notificador_nick']) : 'Anónimo';
            
            $html .= '<tr>
                        <td>' . $notificador . '</td>
                        <td>' . $reportado . '</td>
                        <td>' . htmlspecialchars($reporte['Descripcion']) . '</td>
                        <td>
                            <button class="btn btn-outline-danger btn-sm eliminar-reporte" 
                                    data-idreporte="' . $reporte['idReporte'] . '"
                                    data-tipo="' . (!empty($reporte['UsuReportado']) ? 'usuario' : (!empty($reporte['crewReportada']) ? 'crew' : 'evento')) . '"
                                    data-id="' . (!empty($reporte['UsuReportado']) ? $reporte['UsuReportado'] : (!empty($reporte['crewReportada']) ? $reporte['crewReportada'] : $reporte['EventoReportado'])) . '">
                                <i class="bi bi-trash"></i> Eliminar
                            </button>
                        </td>
                      </tr>';
        }
        
        $html .= '</tbody></table></div>';
        return $html;
    } catch (PDOException $e) {
        error_log("Error al cargar reportes: " . $e->getMessage());
        return '<div class="alert alert-danger">Error al cargar los reportes. Por favor, inténtalo de nuevo más tarde.</div>';
    }
}

// Función para eliminar reporte - Manteniendo la lógica del tipo
function eliminarReporte($pdo, $idReporte, $tipo, $id) {
    try {
        $pdo->beginTransaction();
        
        // Primero actualizamos el campo correspondiente a NULL
        $campo = '';
        switch ($tipo) {
            case 'usuario':
                $campo = 'UsuReportado';
                break;
            case 'crew':
                $campo = 'crewReportada';
                break;
            case 'evento':
                $campo = 'EventoReportado';
                break;
            default:
                throw new Exception("Tipo de reporte no válido");
        }
        
        // Actualizar SOLO el reporte específico
        $query = "UPDATE reportes SET $campo = NULL 
                 WHERE idReporte = :idReporte";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':idReporte', $idReporte, PDO::PARAM_INT);
        $stmt->execute();
        
        // Verificar si todos los campos de reporte son NULL para este reporte específico
        $query = "SELECT UsuReportado, crewReportada, EventoReportado 
                 FROM reportes 
                 WHERE idReporte = :idReporte";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':idReporte', $idReporte, PDO::PARAM_INT);
        $stmt->execute();
        $reporte = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($reporte && 
            is_null($reporte['UsuReportado']) && 
            is_null($reporte['crewReportada']) && 
            is_null($reporte['EventoReportado'])) {
            // Eliminar el reporte si todos los campos son NULL
            $query = "DELETE FROM reportes WHERE idReporte = :idReporte";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':idReporte', $idReporte, PDO::PARAM_INT);
            $stmt->execute();
        }
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error al eliminar reporte: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'eliminar') {
        $idReporte = $_POST['idReporte'] ?? null;
        $tipo = $_POST['tipo'] ?? null;
        $id = $_POST['id'] ?? null;
        
        if ($idReporte && $tipo && $id) {
            $result = eliminarReporte($pdo, $idReporte, $tipo, $id);
            header('Content-Type: application/json');
            echo json_encode(['success' => $result, 'message' => $result ? 'Reporte eliminado correctamente' : 'Error al eliminar el reporte']);
            exit;
        } else {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
            exit;
        }
    }
}
?>