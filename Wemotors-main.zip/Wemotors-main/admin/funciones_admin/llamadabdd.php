<?php
$data=parse_ini_file("config.ini");

try {
    $pdo = new PDO(
        "mysql:host=" . $data["host"] . ";port=" . $data["port"] . ";dbname=" . $data["db"],
        $data["user"],
        $data["pass"]
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>