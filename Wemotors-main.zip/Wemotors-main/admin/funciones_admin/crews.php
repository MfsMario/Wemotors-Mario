<?php
require_once("llamadabdd.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['accion']) && $_POST['accion'] === 'obtener_miembros') {
        $idCrew = $_POST['idCrew'] ?? null;
        header('Content-Type: application/json');
        
        try {
            $stmt = $pdo->prepare("
                SELECT u.idUsu, u.Nick 
                FROM usuarios u 
                WHERE u.idCrew = ?
            ");
            $stmt->execute([$idCrew]);
            $miembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'miembros' => $miembros]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => 'Error en la base de datos']);
        }
        exit;
    }
    
    if (isset($_POST['accion']) && $_POST['accion'] === 'actualizar') {
        header('Content-Type: application/json');
        $response = ['success' => false];
        
        $id = $_POST['id'] ?? null;
        $nombre = $_POST['nombre'] ?? null;
        $admin = $_POST['admin'] ?? null;
        
        if (!$id || !$nombre || !$admin) {
            $response['error'] = 'Datos incompletos';
            echo json_encode($response);
            exit;
        }

        try {
            // Actualizar datos básicos
            $stmt = $pdo->prepare("UPDATE crews SET Nombre = ?, idAdmin = ? WHERE idCrew = ?");
            $stmt->execute([$nombre, $admin, $id]);
            
            // Actualizar imagen si se proporcionó
            if (!empty($_FILES['foto']['tmp_name'])) {
                $foto = file_get_contents($_FILES['foto']['tmp_name']);
                $stmt = $pdo->prepare("UPDATE crews SET Foto = ? WHERE idCrew = ?");
                $stmt->execute([$foto, $id]);
            }
            
            $response['success'] = true;
        } catch (PDOException $e) {
            $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
        }
        
        echo json_encode($response);
        exit;
    }

    if (isset($_POST['accion']) && $_POST['accion'] === 'eliminar') {
        header('Content-Type: application/json');
        $response = ['success' => false];
        
        $idCrew = $_POST['id'] ?? null;
        
        if (!$idCrew) {
            $response['error'] = 'ID de crew no proporcionado';
            echo json_encode($response);
            exit;
        }

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("DELETE FROM reportes WHERE crewReportada = ?");
            $stmt->execute([$idCrew]);
            
            $stmt = $pdo->prepare("DELETE FROM producto WHERE idCrew = ?");
            $stmt->execute([$idCrew]);
            
            $stmt = $pdo->prepare("DELETE FROM chat_crew WHERE idCrew = ?");
            $stmt->execute([$idCrew]);
            
            // 1. Actualizar usuarios para quitarles el crew
            $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idCrew = ?");
            $stmt->execute([$idCrew]);
            
            // 2. Actualizar publicaciones para quitarles el crew
            $stmt = $pdo->prepare("UPDATE publicaciones SET idCrew = NULL WHERE idCrew = ?");
            $stmt->execute([$idCrew]);
            
            // 3. Eliminar el crew
            $stmt = $pdo->prepare("DELETE FROM crews WHERE idCrew = ?");
            $stmt->execute([$idCrew]);
            
            $pdo->commit();
            
            $response['success'] = true;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $response['error'] = 'Error al eliminar el crew: ' . $e->getMessage();
        }
        
        echo json_encode($response);
        exit;
    }

    // CORRECCIÓN PRINCIPAL: obtener_miembros_detalle
    if (isset($_POST['accion']) && $_POST['accion'] === 'obtener_miembros_detalle') {
        header('Content-Type: application/json');
        $idCrew = $_POST['idCrew'] ?? null;
        $busqueda = $_POST['busqueda'] ?? '';
        if (!$idCrew) {
            echo json_encode(['success' => false, 'error' => 'ID de crew no proporcionado']);
            exit;
        }
        
        try {
            // Primero verificar que el crew existe
            $stmtCrew = $pdo->prepare("SELECT idAdmin FROM crews WHERE idCrew = ?");
            $stmtCrew->execute([$idCrew]);
            $crew = $stmtCrew->fetch(PDO::FETCH_ASSOC);
            

            if (!$crew) {
                echo json_encode(['success' => false, 'error' => 'Crew no encontrado']);
                exit;
            }
            
           $sql = "SELECT 
                    u.idUsu, 
                    u.Nick, 
                    TO_BASE64(u.FotoPerfil) as FotoPerfil, 
                    c.idAdmin 
                FROM usuarios u 
                JOIN crews c ON u.idCrew = c.idCrew
                WHERE u.idCrew = ?";
        
                $params = [$idCrew];
            if (!empty($busqueda)) {
                $sql .= " AND u.Nick LIKE ?";
                $params[] = "%$busqueda%";
            }
            
            // Ordenar: primero el admin, luego alfabético
            $sql .= " ORDER BY (u.idUsu = ?) DESC, u.Nick ASC LIMIT 10";
            $params[] = $crew['idAdmin'];
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $miembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Debug: agregar información adicional
            $debug_info = [
                'idCrew' => $idCrew,
                'idAdmin' => $crew['idAdmin'],
                'total_encontrados' => count($miembros),
                'sql_ejecutado' => $sql
            ];
            
            echo json_encode([
                'success' => true, 
                'miembros' => $miembros,
                'debug' => $debug_info // Quitar esto en producción
            ]);
            
        } catch (PDOException $e) {
            echo json_encode([
                'success' => false, 
                'error' => 'Error en la base de datos: ' . $e->getMessage()
            ]);
        }
        exit;
    }

  if (isset($_POST['accion']) && $_POST['accion'] === 'expulsar_miembro') {
    header('Content-Type: application/json');
    $idUsuario = $_POST['idUsuario'] ?? null;
    
    if (!$idUsuario) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no proporcionado']);
        exit;
    }
    
    try {
        // Iniciar transacción para asegurar la consistencia
        $pdo->beginTransaction();
        
        // 1. Obtener el idCrew del usuario antes de expulsarlo
        $stmt = $pdo->prepare("SELECT idCrew FROM usuarios WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario || !$usuario['idCrew']) {
            throw new Exception('Usuario no encontrado o no pertenece a ninguna crew');
        }
        
        $idCrew = $usuario['idCrew'];
        
        // 2. Expulsar al usuario (establecer idCrew a NULL)
        $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 3. Disminuir el contador NUsuarios en la crew
        $stmt = $pdo->prepare("UPDATE crews SET NUsuarios = NUsuarios - 1 WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
        $pdo->commit();
        
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Error al expulsar miembro: ' . $e->getMessage()]);
    }
    exit;
}
}

if (isset($_POST['accion']) && $_POST['accion'] === 'validar_nombre') {
    header('Content-Type: application/json');
    $nombre = $_POST['nombre'] ?? '';
    $id = $_POST['id'] ?? null;
    
    try {
        // Verificar si existe otro crew con el mismo nombre (excluyendo el actual)
        $sql = "SELECT COUNT(*) as existe FROM crews WHERE Nombre = ?";
        $params = [$nombre];
        
        if ($id) {
            $sql .= " AND idCrew != ?";
            $params[] = $id;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'disponible' => $resultado['existe'] == 0,
            'nombre' => $nombre
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            'disponible' => false,
            'error' => 'Error en la base de datos'
        ]);
    }
    exit;
}

function mostrarCrews($pdo) {
    $stmt = $pdo->query("
        SELECT c.*, COUNT(u.idUsu) as miembros, ua.Nick as admin_nombre
        FROM crews c 
        LEFT JOIN usuarios u ON c.idCrew = u.idCrew
        LEFT JOIN usuarios ua ON c.idAdmin = ua.idUsu
        GROUP BY c.idCrew
    ");
    
    $output = '<div class="mobile-table-container">
                <div class="mobile-table-hint d-block d-md-none">← Desliza para ver más →</div>
                <table class="table table-hover" id="tabla-crews">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Admin/Creador</th>
                            <th>Miembros</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-crews" >';
    
    while ($crew = $stmt->fetch()) {
        $imagenCrew = !empty($crew['Foto']) ? 
            'data:image/jpeg;base64,'.base64_encode($crew['Foto']) : 
            'assets/img/default-crew.jpg';
        
        $output .= '<tr>';
        $output .= '<td>'.$crew['idCrew'].'</td>';
        $output .= '<td class="text-nowrap">'.$crew['Nombre'].'</td>';
        $output .= '<td class="text-nowrap">'.($crew['admin_nombre'] ?? 'Sin admin').'</td>';
        $output .= '<td>
                        <button class="btn btn-sm btn-outline-primary ver-miembros" 
                                data-id="'.$crew['idCrew'].'"
                                data-nombre="'.$crew['Nombre'].'">
                            <i class="bi bi-people"></i> '.$crew['miembros'].' miembros
                        </button>
                    </td>';
        $output .= '<td class="text-nowrap">
                    <button class="btn btn-sm btn-outline-primary action-btn editar-crew" 
                            data-id="'.$crew['idCrew'].'"
                            data-nombre="'.$crew['Nombre'].'"
                            data-admin="'.$crew['idAdmin'].'"
                            data-imagen="'.$imagenCrew.'">
                        <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
                    </button>
                    <button class="btn btn-sm btn-outline-danger action-btn eliminar-crew ms-1" data-id="'.$crew['idCrew'].'">
                        <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
                    </button>
                  </td>';
        $output .= '</tr>';
    }
    
    $output .= '</tbody></table></div>';
    return $output;
}
?>