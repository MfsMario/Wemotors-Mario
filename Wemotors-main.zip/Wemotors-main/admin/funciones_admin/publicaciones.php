<?php

require_once("llamadabdd.php");

function obtenerComentariosPublicacion($idPublicacion) {
    
    try {
         $stmt = $pdo->prepare("
            SELECT c.*, u.Nick, u.FotoPerfil 
            FROM comentario c
            JOIN usuarios u ON c.idUsu = u.idUsu
            WHERE c.idPub = ?
            ORDER BY c.fecCom DESC
        ");
        $stmt->execute([$idPublicacion]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (PDOException $e) {
        error_log("Error al obtener comentarios: " . $e->getMessage());
        return [];
    }
}

// Procesar eliminación de publicación
if (isset($_POST['accion'])) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['accion'] === 'eliminar_publicacion') {
            $idPublicacion = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            
            if ($idPublicacion <= 0) {
                throw new Exception('ID de publicación no válido');
            }
            
            // Iniciar transacción para asegurar la integridad de los datos
            $pdo->beginTransaction();
            
            // 1. Eliminar los comentarios asociados a la publicación
            $stmtComentarios = $pdo->prepare("DELETE FROM comentario WHERE idPub = ?");
            $stmtComentarios->execute([$idPublicacion]);
            
            // 2. Eliminar los likes asociados a la publicación
            $stmtLikes = $pdo->prepare("DELETE FROM likes WHERE idPubli = ?");
            $stmtLikes->execute([$idPublicacion]);
            
            // 3. Finalmente eliminar la publicación
            $stmtPublicacion = $pdo->prepare("DELETE FROM publicaciones WHERE idPubli = ?");
            $stmtPublicacion->execute([$idPublicacion]);
            
            $pdo->commit();
            
            echo json_encode([
                'success' => true,
                'message' => 'Publicación eliminada correctamente'
            ]);
            exit;
        }
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Error al eliminar publicación: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
// Agregar al switch de métodos POST, antes del cierre del try-catch
if (isset($_POST['accion']) && $_POST['accion'] === 'eliminar_comentario') {
    $idComentario = isset($_POST['idComentario']) ? (int)$_POST['idComentario'] : 0;
    
    if ($idComentario <= 0) {
        throw new Exception('ID de comentario no válido');
    }
    
    $stmt = $pdo->prepare("DELETE FROM comentario WHERE idComentario = ?");
    $success = $stmt->execute([$idComentario]);
    
    if (!$success) {
        throw new Exception('Error al eliminar el comentario');
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Comentario eliminado correctamente'
    ]);
    exit;
}
try {
    // Verificar si es una solicitud POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obtener datos del formulario
        $idPublicacion = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';
        $marcaId = isset($_POST['marcaId']) ? (int)$_POST['marcaId'] : null;
        
        if ($idPublicacion <= 0) {
            throw new Exception('ID de publicación no válido');
        }

        // Preparar la consulta base
        $sql = "UPDATE publicaciones SET DescripcionPubli = ?, idMarca = ?";
        $params = [$descripcion, $marcaId];

        // Manejar la imagen si se subió una nueva
        if (!empty($_FILES['foto']['tmp_name'])) {
            $foto = file_get_contents($_FILES['foto']['tmp_name']);
            $sql .= ", Foto = ?";
            $params[] = $foto;
        }

        $sql .= " WHERE idPubli = ?";
        $params[] = $idPublicacion;

        // Ejecutar la consulta
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute($params);

        if (!$success) {
            throw new Exception('Error al actualizar la publicación en la base de datos');
        }

        echo json_encode([
            'success' => true,
            'message' => 'Publicación actualizada correctamente'
        ]);
        exit;
    }
} catch (Exception $e) {
    error_log("Error en publicaciones.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit;
}

// Si no hay ID de usuario, devolver contenido vacío
if (!isset($_GET['idUsuario']) || !is_numeric($_GET['idUsuario'])) {
    exit;
}

$idUsuario = (int)$_GET['idUsuario'];

try {
    // Obtener publicaciones del usuario
    $stmtPublicaciones = $pdo->prepare("
        SELECT p.*, m.Nombre as marca_nombre 
        FROM publicaciones p
        LEFT JOIN marca m ON p.idMarca = m.idMarca
        WHERE p.idUsu = ?
        ORDER BY p.fecPublicacion DESC
    ");
    $stmtPublicaciones->execute([$idUsuario]);

    $output = '';

    while ($publicacion = $stmtPublicaciones->fetch()) {
        $foto = !empty($publicacion['Foto']) ? 
            'data:image/jpeg;base64,' . base64_encode($publicacion['Foto']) : 
            'assets/img/default-post.jpg';
        
      $output .= '
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="'.$foto.'" class="card-img-top" alt="Publicación" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">'.$publicacion['marca_nombre'].'</h5>
                        <p class="card-text">'.$publicacion['DescripcionPubli'].'</p>
                        <p class="text-muted small">'.date('d/m/Y H:i', strtotime($publicacion['fecPublicacion'])).'</p>
                    </div>
                    <div class="card-footer bg-white d-flex justify-content-between">
                        <button class="btn btn-sm btn-outline-primary editar-publicacion" 
                                data-id="'.$publicacion['idPubli'].'"
                                data-descripcion="'.htmlspecialchars($publicacion['DescripcionPubli'], ENT_QUOTES).'"
                                data-foto="'.$foto.'"
                                data-marca-id="'.$publicacion['idMarca'].'">
                            <i class="bi bi-pencil"></i> Editar
                        </button>
                        <button class="btn btn-sm btn-outline-danger eliminar-publicacion" data-id="'.$publicacion['idPubli'].'">
                            <i class="bi bi-trash"></i> Eliminar
                        </button>
                    </div>
                </div>
            </div>';
    }

    echo $output ?: '<div class="col-12 text-center py-5"><h5>Este usuario no tiene publicaciones</h5></div>';

} catch (PDOException $e) {
    error_log("Error en publicaciones.php: " . $e->getMessage());
    echo '<div class="col-12 text-center py-5"><h5>Error al cargar publicaciones</h5></div>';
}
?>
