<?php
require_once("llamadabdd.php"); // Asegúrate de incluir la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'actualizar') {
    header('Content-Type: application/json');
    $response = ['success' => false];
    
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombre'] ?? null;
    $lugar = $_POST['lugar'] ?? null;
    $fecha = $_POST['fecha'] ?? null;
    $admin = $_POST['admin'] ?? null;
    
    if (!$id || !$nombre || !$lugar || !$fecha || !$admin) {
        $response['error'] = 'Datos incompletos';
        echo json_encode($response);
        exit;
    }

    try {
        // Actualizar datos básicos y admin
        $stmt = $pdo->prepare("UPDATE eventos SET Nombre = ?, Lugar = ?, fecEvento = ?, idUsuAdmin = ? WHERE idEvento = ?");
        $stmt->execute([$nombre, $lugar, $fecha, $admin, $id]);
        
        // Actualizar imagen si se proporcionó
        if (!empty($_FILES['imagen']['tmp_name'])) {
            $imagen = file_get_contents($_FILES['imagen']['tmp_name']);
            $stmt = $pdo->prepare("UPDATE eventos SET PerfilEvento = ? WHERE idEvento = ?");
            $stmt->execute([$imagen, $id]);
        }
        
        $response['success'] = true;
    } catch (PDOException $e) {
        $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    header('Content-Type: application/json');
    $response = ['success' => false];
    
    try {
        if ($_POST['accion'] === 'eliminar') {
            $idEvento = $_POST['id'] ?? null;
            
            if (!$idEvento) {
                throw new Exception('ID de evento no válido');
            }
            
            // Iniciar transacción
            $pdo->beginTransaction();

               $stmt = $pdo->prepare("DELETE FROM reportes WHERE EventoReportado = ?");
                $stmt->execute([$idEvento]);
            
            // 1. Actualizar publicaciones vinculadas (poner idEvento en NULL)
            $stmtPublicaciones = $pdo->prepare("UPDATE publicaciones SET idEvento = NULL WHERE idEvento = ?");
            $stmtPublicaciones->execute([$idEvento]);
            
            // 2. Eliminar participantes del evento
            $stmtParticipantes = $pdo->prepare("DELETE FROM evento_usu WHERE idEvento = ?");
            $stmtParticipantes->execute([$idEvento]);
            
            // 3. Finalmente eliminar el evento
            $stmtEvento = $pdo->prepare("DELETE FROM eventos WHERE idEvento = ?");
            $stmtEvento->execute([$idEvento]);
            
            $pdo->commit();
            
            $response['success'] = true;
            $response['message'] = 'Evento eliminado correctamente';
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['error'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}

function mostrarEventos($pdo) {
    $stmt = $pdo->query("
        SELECT e.*, u.Nick as creador_nombre 
        FROM eventos e 
        LEFT JOIN usuarios u ON e.idUsuAdmin = u.idUsu
        ORDER BY e.fecEvento DESC
    ");
    
    $output = '<div class="mobile-table-container">
                <div class="mobile-table-hint d-block d-md-none">← Desliza para ver más →</div>
                <table class="table table-hover" id="tabla-eventos">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Lugar</th>
                            <th>Fecha</th>
                            <th>Creador</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-eventos">';
    
    while ($evento = $stmt->fetch()) {
        $imagenEvento = !empty($evento['PerfilEvento']) ? 
            'data:image/jpeg;base64,'.base64_encode($evento['PerfilEvento']) : 
            'assets/img/default-event.jpg';
        
        $output .= '<tr>';
        $output .= '<td>'.$evento['idEvento'].'</td>';
        $output .= '<td class="text-nowrap">'.$evento['Nombre'].'</td>';
        $output .= '<td class="text-nowrap">'.$evento['Lugar'].'</td>';
        $output .= '<td class="text-nowrap">'.date('d/m/Y H:i', strtotime($evento['fecEvento'])).'</td>';
        $output .= '<td class="text-nowrap">'.$evento['creador_nombre'].'</td>';
        $output .= '<td class="text-nowrap">';
        $output .= '<button class="btn btn-sm btn-outline-primary action-btn editar-evento" 
                    data-id="'.$evento['idEvento'].'"
                    data-nombre="'.$evento['Nombre'].'"
                    data-lugar="'.$evento['Lugar'].'"
                    data-fecha="'.date('Y-m-d\TH:i', strtotime($evento['fecEvento'])).'"
                    data-imagen="'.$imagenEvento.'">
                <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
            </button>';
        $output .= '<button class="btn btn-sm btn-outline-danger action-btn eliminar-evento ms-1" data-id="'.$evento['idEvento'].'">
            <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
        </button>';
        $output .= '</td>';
        $output .= '</tr>';
    }
    
    $output .= '</tbody></table></div>';
    return $output;
}
?>