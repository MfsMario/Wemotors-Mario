
<?php
require_once("llamadabdd.php");

header('Content-Type: ' . (isset($_GET['tipo']) && $_GET['tipo'] === 'usuarios_publicaciones' ? 'application/json' : 'text/html'));

$termino = isset($_GET['q']) ? '%' . $_GET['q'] . '%' : '%%';
$tipo = $_GET['tipo'] ?? '';

switch ($tipo) {
    case 'usuarios':
    $stmt = $pdo->prepare("
        SELECT 
            u.*, 
            c.Nombre as crew_nombre,
            c.idCrew as crew_id,
            GROUP_CONCAT(DISTINCT e.Nombre SEPARATOR '|') as eventos_nombres,
            GROUP_CONCAT(DISTINCT e.idEvento SEPARATOR '|') as eventos_ids
        FROM usuarios u 
        LEFT JOIN crews c ON u.idCrew = c.idCrew
        LEFT JOIN evento_usu eu ON u.idUsu = eu.idUsu
        LEFT JOIN eventos e ON eu.idEvento = e.idEvento
        WHERE u.Nick LIKE :termino OR u.email LIKE :termino
        GROUP BY u.idUsu
        ORDER BY u.Nombre
    ");
    $stmt->bindParam(':termino', $termino);
    $stmt->execute();
      $output ="";
    while ($usuario = $stmt->fetch()) {
        $output .= '<tr>';
        $output .= '<td>'.$usuario['idUsu'].'</td>';
        $output .= '<td class="text-nowrap">'.$usuario['Nick'].'</td>';
        $output .= '<td class="text-nowrap">'.$usuario['email'].'</td>';
        
        // Columna Crew con botón para salir
        $output .= '<td class="text-nowrap">';
        if ($usuario['crew_nombre']) {
            $output .= '<div class="d-flex align-items-center">';
            $output .= '<span class="me-2">'.$usuario['crew_nombre'].'</span>';
            $output .= '<button class="btn btn-sm btn-outline-danger btn-salir-crew" 
                          data-id="'.$usuario['idUsu'].'"
                          data-crew="'.$usuario['crew_nombre'].'">
                          <i class="bi bi-x-lg"></i>
                       </button>';
            $output .= '</div>';
        } else {
            $output .= 'Sin crew';
        }
        $output .= '</td>';
        
        // Columna Eventos con botones para salir
        $output .= '<td>';
        if ($usuario['eventos_nombres']) {
            $eventosNombres = explode('|', $usuario['eventos_nombres']);
            $eventosIds = explode('|', $usuario['eventos_ids']);
            
            foreach ($eventosNombres as $index => $nombreEvento) {
                $idEvento = $eventosIds[$index] ?? '';
                if ($nombreEvento && $idEvento) {
                    $output .= '<div class="d-flex align-items-center mb-1">';
                    $output .= '<span class="me-2">'.$nombreEvento.'</span>';
                    $output .= '<button class="btn btn-sm btn-outline-danger btn-salir-evento" 
                                  data-id-usuario="'.$usuario['idUsu'].'"
                                  data-id-evento="'.$idEvento.'"
                                  data-evento="'.$nombreEvento.'">
                                  <i class="bi bi-x-lg"></i>
                               </button>';
                    $output .= '</div>';
                }
            }
        } else {
            $output .= 'Sin eventos';
        }
        $output .= '</td>';
        
        // Columna Admin
        $output .= '<td class="text-nowrap">';
        if ($usuario['Admin'] == 1) {
            $output .= '<span class="badge bg-success badge-admin me-1">Admin</span>';
            $output .= '<button class="btn btn-sm btn-outline-danger quitar-admin" data-id="'.$usuario['idUsu'].'">Quitar</button>';
        } else {
            $output .= '<button class="btn btn-sm btn-outline-success hacer-admin" data-id="'.$usuario['idUsu'].'">Admin</button>';
        }
        $output .= '</td>';
        
        // Columna Acciones
        $output .= '<td class="text-nowrap">
                <button class="btn btn-sm btn-outline-primary action-btn editar-usuario" 
                        data-id="'.$usuario['idUsu'].'"
                        data-nick="'.$usuario['Nick'].'"
                        data-foto="'.(!empty($usuario['FotoPerfil']) ? 'data:image/jpeg;base64,'.base64_encode($usuario['FotoPerfil']) : '').'">
                    <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
                </button>
                <button class="btn btn-sm btn-outline-danger action-btn eliminar-usuario ms-1" data-id="'.$usuario['idUsu'].'">
                    <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
                </button>
              </td>';
        $output .= '</tr>';
    }
    
    $output .= '</tbody></table></div>';
    echo $output ?: '<tr><td colspan="7" class="text-center">No se encontraron usuarios</td></tr>';
    break;

    case 'crews':
        $stmt = $pdo->prepare("
            SELECT c.*, COUNT(u.idUsu) as miembros, ua.Nombre as admin_nombre
            FROM crews c
            LEFT JOIN usuarios u ON c.idCrew = u.idCrew
            LEFT JOIN usuarios ua ON c.idAdmin = ua.idUsu
            WHERE c.Nombre LIKE :termino
            GROUP BY c.idCrew
            ORDER BY c.Nombre
        ");
        $stmt->bindParam(':termino', $termino);
        $stmt->execute();
        
        $output = '';
         $output = '<div class="mobile-table-container">
                <div class="mobile-table-hint d-block d-md-none">← Desliza para ver más →</div>
                <table class="table table-hover" id="tabla-crews">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Admin</th>
                            <th>Miembros</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-crews" >';
        while ($crew = $stmt->fetch()) {
            $imagenCrew = !empty($crew['Foto']) ? 
            'data:image/jpeg;base64,'.base64_encode($crew['Foto']) : 
            'assets/img/default-crew.jpg';
        
            $output .= '<tr>';
            $output .= '<td>'.$crew['idCrew'].'</td>';
            $output .= '<td class="text-nowrap">'.$crew['Nombre'].'</td>';
            $output .= '<td class="text-nowrap">'.($crew['admin_nombre'] ?? 'Sin admin').'</td>';
              $output .= '<td>
                        <button class="btn btn-sm btn-outline-primary ver-miembros" 
                                data-id="'.$crew['idCrew'].'"
                                data-nombre="'.$crew['Nombre'].'">
                            <i class="bi bi-people"></i> '.$crew['miembros'].' miembros
                        </button>
                    </td>';
            $output .= '<td class="text-nowrap">
                    <button class="btn btn-sm btn-outline-primary action-btn editar-crew" 
                            data-id="'.$crew['idCrew'].'"
                            data-nombre="'.$crew['Nombre'].'"
                            data-admin="'.$crew['idAdmin'].'"
                            data-imagen="'.$imagenCrew.'">
                        <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
                    </button>
                    <button class="btn btn-sm btn-outline-danger action-btn eliminar-crew ms-1" data-id="'.$crew['idCrew'].'">
                        <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
                    </button>
                </td>';
            $output .= '</tr>';
        }
        echo $output ?: '<tr><td colspan="5" class="text-center">No se encontraron crews</td></tr>';
        break;

    case 'eventos':
        $stmt = $pdo->prepare("
            SELECT e.*, u.Nombre as creador_nombre
            FROM eventos e
            LEFT JOIN usuarios u ON e.idUsuAdmin = u.idUsu
            WHERE e.Nombre LIKE :termino OR e.Lugar LIKE :termino
            ORDER BY e.fecEvento DESC
        ");
        $stmt->bindParam(':termino', $termino);
        $stmt->execute();
        
        $output = '';
         
    $output = '<div class="mobile-table-container">
                <div class="mobile-table-hint d-block d-md-none">← Desliza para ver más →</div>
                <table class="table table-hover" id="tabla-eventos">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Lugar</th>
                            <th>Fecha</th>
                            <th>Creador</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody  id="tabla-eventos">';
        while ($evento = $stmt->fetch()) {
               $output .= '<tr>';
            $output .= '<td>'.$evento['idEvento'].'</td>';
            $output .= '<td>'.$evento['Nombre'].'</td>';
            $output .= '<td>'.$evento['Lugar'].'</td>';
            $output .= '<td>'.date('d/m/Y H:i', strtotime($evento['fecEvento'])).'</td>';
            $output .= '<td>'.$evento['creador_nombre'].'</td>';
            $output .= '<td class="d-flex">';
            $output .= '<button class="btn btn-sm btn-outline-primary action-btn editar-evento" 
                data-id="'.$evento['idEvento'].'"
                data-nombre="'.$evento['Nombre'].'"
                data-lugar="'.$evento['Lugar'].'"
                data-fecha="'.date('Y-m-d\TH:i', strtotime($evento['fecEvento'])).'"
                data-imagen="'.(!empty($evento['imagenEvento']) ? 'data:image/jpeg;base64,'.base64_encode($evento['imagenEvento']) : '').'">
                    <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
                    </button>';

                $output.='<button class="btn btn-sm btn-outline-danger action-btn eliminar-evento ms-1" data-id="'.$evento['idEvento'].'">
                            <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
                         </button>
                     </td>';
            $output .= '</tr>';
        }
        echo $output ?: '<tr><td colspan="6" class="text-center">No se encontraron eventos</td></tr>';
        break;

    case 'usuarios_publicaciones':
        $stmt = $pdo->prepare("
            SELECT idUsu, Nombre, Email, FotoPerfil 
            FROM usuarios 
            WHERE Nombre LIKE :termino OR Email LIKE :termino
            ORDER BY Nombre
            LIMIT 10
        ");
        $stmt->bindParam(':termino', $termino);
        $stmt->execute();
        
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($usuarios as &$usuario) {
            if (!empty($usuario['FotoPerfil'])) {
                $usuario['FotoPerfil'] = 'data:image/jpeg;base64,' . base64_encode($usuario['FotoPerfil']);
            } else {
                $usuario['FotoPerfil'] = 'assets/img/default-profile.png';
            }
        }
        
        echo json_encode($usuarios);
        break;
    case 'marcas':
        $stmt = $pdo->prepare("SELECT idMarca, Nombre FROM marca ORDER BY Nombre");
        $stmt->execute();
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        break;

    case 'comentarios':
       $idPublicacion = isset($_GET['idPublicacion']) ? (int)$_GET['idPublicacion'] : 0;
    
        if ($idPublicacion <= 0) {
            echo json_encode(['error' => 'ID de publicación no válido']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("
                SELECT c.*, u.Nick, u.FotoPerfil 
                FROM comentario c
                JOIN usuarios u ON c.idUsu = u.idUsu
                WHERE c.idPub = ?
                ORDER BY c.fecCom DESC
            ");
            $stmt->execute([$idPublicacion]);
            $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Procesar fotos de perfil
            foreach ($comentarios as &$comentario) {
                if (!empty($comentario['FotoPerfil'])) {
                    $comentario['FotoPerfil'] = base64_encode($comentario['FotoPerfil']);
                }
            }
            
            echo json_encode([
                'success' => true,
                'data' => $comentarios ?: [], // Asegurar array incluso si está vacío
                'count' => count($comentarios)
            ]);
            
        } catch (PDOException $e) {
            echo json_encode([
                'success' => false,
                'error' => 'Error en la base de datos: ' . $e->getMessage()
            ]);
        }
    exit;
    break;

    case 'participantes_evento':
        $idEvento = isset($_GET['idEvento']) ? (int)$_GET['idEvento'] : 0;
        
        if ($idEvento <= 0) {
            echo json_encode([]);
            exit;
        }
        
        try {
            // Obtener el admin actual del evento
            $stmt = $pdo->prepare("SELECT idUsuAdmin FROM eventos WHERE idEvento = ?");
            $stmt->execute([$idEvento]);
            $adminActual = $stmt->fetchColumn();
            
            // Obtener todos los participantes del evento
            $stmt = $pdo->prepare("
                SELECT u.idUsu, u.Nombre, u.Apellidos, 
                    (u.idUsu = ?) as esAdmin
                FROM evento_usu eu
                JOIN usuarios u ON eu.idUsu = u.idUsu
                WHERE eu.idEvento = ?
                UNION
                SELECT u.idUsu, u.Nombre, u.Apellidos, 
                    (u.idUsu = ?) as esAdmin
                FROM eventos e
                JOIN usuarios u ON e.idUsuAdmin = u.idUsu
                WHERE e.idEvento = ?
            ");
            $stmt->execute([$adminActual, $idEvento, $adminActual, $idEvento]);
            $participantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Formatear nombres
            foreach ($participantes as &$participante) {
                $participante['Nombre'] = $participante['Nombre'] . ' ' . $participante['Apellidos'];
                $participante['esAdmin'] = (bool)$participante['esAdmin'];
            }
            
            header('Content-Type: application/json');
            echo json_encode($participantes);
            
        } catch (PDOException $e) {
            header('Content-Type: application/json');
            echo json_encode(['error' => $e->getMessage()]);
        }
    break;
}
?>