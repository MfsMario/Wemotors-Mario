<?php
ob_start();
require_once("llamadabdd.php");


// Manejar peticiones POST para actualizar usuario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $response = ['success' => false];
    // Actualizar datos de usuario
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {

           case 'actualizar':
                $id = $_POST['id'] ?? null;
                $nick = $_POST['nick'] ?? null;
                
                if (!$id || !$nick) {
                    $response['error'] = 'Datos incompletos';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // Verificar si el nick ya existe (excluyendo al usuario actual)
                    $stmt = $pdo->prepare("SELECT idUsu FROM usuarios WHERE Nick = ? AND idUsu != ?");
                    $stmt->execute([$nick, $id]);
                    
                    if ($stmt->fetch()) {
                        $response['error'] = 'El nick ya está en uso por otro usuario';
                        echo json_encode($response);
                        exit;
                    }

                    // Resto del código de actualización...
                    $stmt = $pdo->prepare("UPDATE usuarios SET Nick = ? WHERE idUsu = ?");
                    $stmt->execute([$nick, $id]);
                    
                    // Actualizar foto si se proporcionó
                    if (!empty($_FILES['foto']['tmp_name'])) {
                        $foto = file_get_contents($_FILES['foto']['tmp_name']);
                        $stmt = $pdo->prepare("UPDATE usuarios SET FotoPerfil = ? WHERE idUsu = ?");
                        $stmt->execute([$foto, $id]);
                    }
                    
                    $response['success'] = true;
                } catch (PDOException $e) {
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
            break;

            case 'hacer_admin':
                $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    $stmt = $pdo->prepare("UPDATE usuarios SET Admin = 1 WHERE idUsu = ?");
                    $stmt->execute([$id]);
                    
                    $response['success'] = true;
                } catch (PDOException $e) {
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

            case 'quitar_admin':
                $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    $stmt = $pdo->prepare("UPDATE usuarios SET Admin = 0 WHERE idUsu = ?");
                    $stmt->execute([$id]);
                    
                    $response['success'] = true;
                } catch (PDOException $e) {
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

           case 'salir_crew':
                $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // CORRECCIÓN: Iniciar transacción solo si no hay una activa
                    if (!$pdo->inTransaction()) {
                        $pdo->beginTransaction();
                    }
                    
                    // Verificar si el usuario es admin del crew
                    $stmt = $pdo->prepare("SELECT idCrew FROM crews WHERE idAdmin = ?");
                    $stmt->execute([$id]);
                    $crewAdmin = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($crewAdmin) {
                        $response['necesita_reemplazo_crew'] = true;
                        $response['idCrew'] = $crewAdmin['idCrew'];
                        
                        // Obtener miembros del crew para posibles reemplazos
                        $stmt = $pdo->prepare("SELECT idUsu, Nick FROM usuarios WHERE idCrew = ? AND idUsu != ?");
                        $stmt->execute([$crewAdmin['idCrew'], $id]);
                        $response['miembros'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        // Si está en transacción, hacer commit para enviar la respuesta
                        if ($pdo->inTransaction()) {
                            $pdo->commit();
                        }
                    } else {
                        // No es admin, simplemente sacar del crew
                        $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?");
                        $stmt->execute([$id]);

                        $stmt = $pdo->prepare("UPDATE crews SET NUsuarios = NUsuarios -1");
                        $stmt->execute();

                        $response['success'] = true;
                        
                        // Si está en transacción, hacer commit
                        if ($pdo->inTransaction()) {
                            $pdo->commit();
                        }
                    }
                } catch (PDOException $e) {
                    // Hacer rollback solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

           case 'reemplazar_admin_crew':
                $idUsuario = $_POST['idUsuario'] ?? null;
                $idCrew = $_POST['idCrew'] ?? null;
                $idNuevoAdmin = $_POST['idNuevoAdmin'] ?? null;
                
                if (!$idUsuario || !$idCrew) {
                    $response['error'] = 'Datos incompletos';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // CORRECCIÓN: Iniciar transacción solo si no hay una activa
                    if (!$pdo->inTransaction()) {
                        $pdo->beginTransaction();
                    }
                    
                    // Si se proporciona un nuevo admin, asignarlo
                    if ($idNuevoAdmin) {
                        // Verificar que el nuevo admin pertenece al crew
                        $stmt = $pdo->prepare("SELECT idUsu FROM usuarios WHERE idUsu = ? AND idCrew = ?");
                        $stmt->execute([$idNuevoAdmin, $idCrew]);
                        
                        if (!$stmt->fetch()) {
                            throw new Exception('El usuario seleccionado no pertenece a este crew');
                        }
                        
                        $stmt = $pdo->prepare("UPDATE crews SET idAdmin = ? WHERE idCrew = ?");
                        $stmt->execute([$idNuevoAdmin, $idCrew]);
                    } else {
                        // Si no hay nuevo admin, eliminar el crew
                        eliminarCrew($pdo, $idCrew);
                    }
                    
                    // Sacar al usuario del crew
                    $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?");
                    $stmt->execute([$idUsuario]);

                     $stmt = $pdo->prepare("UPDATE crews SET NUsuarios = NUsuarios -1");
                    $stmt->execute();
                    

                    
                    // Hacer commit solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->commit();
                    }

                    $response['success'] = true;
                } catch (Exception $e) {
                    // Hacer rollback solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $response['error'] = $e->getMessage();
                }
                break;

            case 'salir_evento':
                $idUsuario = $_POST['idUsuario'] ?? null;
                $idEvento = $_POST['idEvento'] ?? null;
                
                if (!$idUsuario || !$idEvento) {
                    $response['error'] = 'Datos incompletos';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // CORRECCIÓN: Iniciar transacción solo si no hay una activa
                    if (!$pdo->inTransaction()) {
                        $pdo->beginTransaction();
                    }
                    
                    // Verificar si el usuario es admin del evento
                    $stmt = $pdo->prepare("SELECT idUsuAdmin FROM eventos WHERE idEvento = ?");
                    $stmt->execute([$idEvento]);
                    $adminEvento = $stmt->fetchColumn();
                    
                    if ($adminEvento == $idUsuario) {
                        $response['necesita_reemplazo_evento'] = true;
                        $response['idEvento'] = $idEvento; // CORRECCIÓN: Agregar idEvento a la respuesta
                        
                        // Obtener participantes del evento para posibles reemplazos
                        $stmt = $pdo->prepare("
                            SELECT u.idUsu, u.Nick 
                            FROM evento_usu eu
                            JOIN usuarios u ON eu.idUsu = u.idUsu
                            WHERE eu.idEvento = ? AND eu.idUsu != ?
                        ");
                        $stmt->execute([$idEvento, $idUsuario]);
                        $response['participantes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        // Si está en transacción, hacer commit para enviar la respuesta
                        if ($pdo->inTransaction()) {
                            $pdo->commit();
                        }
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM evento_usu WHERE idUsu = ? AND idEvento = ?");
                        $stmt->execute([$idUsuario, $idEvento]);
                        $response['success'] = true;
                        
                        // Si está en transacción, hacer commit
                        if ($pdo->inTransaction()) {
                            $pdo->commit();
                        }
                    }
                } catch (PDOException $e) {
                    // Hacer rollback solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

            case 'reemplazar_admin_evento':
                $idUsuario = $_POST['idUsuario'] ?? null;
                $idEvento = $_POST['idEvento'] ?? null;
                $idNuevoAdmin = $_POST['idNuevoAdmin'] ?? null;
                
                if (!$idUsuario || !$idEvento) {
                    $response['error'] = 'Datos incompletos';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // CORRECCIÓN: Iniciar transacción solo si no hay una activa
                    if (!$pdo->inTransaction()) {
                        $pdo->beginTransaction();
                    }
                    
                    // Si se proporciona un nuevo admin, asignarlo
                    if ($idNuevoAdmin) {
                        // Verificar que el nuevo admin participa en el evento
                        $stmt = $pdo->prepare("SELECT idUsu FROM evento_usu WHERE idUsu = ? AND idEvento = ?");
                        $stmt->execute([$idNuevoAdmin, $idEvento]);
                        
                        if (!$stmt->fetch()) {
                            throw new Exception('El usuario seleccionado no participa en este evento');
                        }
                        
                        $stmt = $pdo->prepare("UPDATE eventos SET idUsuAdmin = ? WHERE idEvento = ?");
                        $stmt->execute([$idNuevoAdmin, $idEvento]);
                    } else {
                        // Si no hay nuevo admin, eliminar el evento
                        eliminarEvento($pdo, $idEvento);
                    }
                    
                    // Sacar al usuario del evento
                    $stmt = $pdo->prepare("DELETE FROM evento_usu WHERE idUsu = ? AND idEvento = ?");
                    $stmt->execute([$idUsuario, $idEvento]);
                    
                    // Hacer commit solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->commit();
                    }
                    $response['success'] = true;
                } catch (Exception $e) {
                    // Hacer rollback solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $response['error'] = $e->getMessage();
                }
                break;

            case 'eliminar':
                $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // CORRECCIÓN: Iniciar transacción solo si no hay una activa
                    if (!$pdo->inTransaction()) {
                        $pdo->beginTransaction();
                    }

                    // CORRECCIÓN: Usar id en vez de idUsuario que no está definido
                    $stmt = $pdo->prepare("DELETE FROM reportes WHERE UsuNotificador = ? OR UsuReportado = ?");
                    $stmt->execute([$id, $id]);
                    
                    // Verificar si es admin de algún crew
                    $stmt = $pdo->prepare("SELECT idCrew, Nombre FROM crews WHERE idAdmin = ?");
                    $stmt->execute([$id]);
                    $crewsAdmin = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Verificar si es admin de algún evento
                    $stmt = $pdo->prepare("SELECT idEvento, Nombre FROM eventos WHERE idUsuAdmin = ?");
                    $stmt->execute([$id]);
                    $eventosAdmin = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($crewsAdmin)) {
                        $response['necesita_reemplazo'] = true;
                        $response['es_admin_crew'] = true;
                        $response['crews'] = $crewsAdmin;
                        
                        // Obtener miembros de cada crew para posibles reemplazos
                        foreach ($response['crews'] as &$crew) {
                            $stmt = $pdo->prepare("SELECT idUsu, Nick FROM usuarios WHERE idCrew = ? AND idUsu != ?");
                            $stmt->execute([$crew['idCrew'], $id]);
                            $crew['miembros'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        }
                    }
                    
                    if (!empty($eventosAdmin)) {
                        $response['necesita_reemplazo'] = true;
                        $response['es_admin_evento'] = true;
                        $response['eventos'] = $eventosAdmin;
                        
                        // Obtener participantes de cada evento para posibles reemplazos
                        foreach ($response['eventos'] as &$evento) {
                            $stmt = $pdo->prepare("
                                SELECT u.idUsu, u.Nick 
                                FROM evento_usu eu
                                JOIN usuarios u ON eu.idUsu = u.idUsu
                                WHERE eu.idEvento = ? AND eu.idUsu != ?
                            ");
                            $stmt->execute([$evento['idEvento'], $id]);
                            $evento['participantes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        }
                    }
                    
                    if (empty($crewsAdmin)) {
                        $response['es_admin_crew'] = false;
                    }
                    
                    if (empty($eventosAdmin)) {
                        $response['es_admin_evento'] = false;
                    }
                    
                    if (empty($crewsAdmin) && empty($eventosAdmin)) {
                        // No es admin, proceder con eliminación directa
                        eliminarUsuario($pdo, $id);
                        $response['success'] = true;
                    }
                    
                    // Hacer commit solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->commit();
                    }
                } catch (PDOException $e) {
                    // Hacer rollback solo si hay una transacción activa
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

            case 'eliminar_con_reemplazo':
                                $id = $_POST['id'] ?? null;
                    $reemplazos = $_POST['reemplazos'] ?? [];
                    
                    if (!$id) {
                        $response['error'] = 'ID de usuario no proporcionado';
                        echo json_encode($response);
                        exit;
                    }

                    try {
                        // Iniciar transacción
                        $pdo->beginTransaction();
                        
                        // Decodificar reemplazos si viene como JSON
                        $reemplazos = is_array($reemplazos) ? $reemplazos : json_decode($reemplazos, true);
                        
                        // Procesar reemplazos para crews
                        if (isset($reemplazos['crew'])) {
                            foreach ($reemplazos['crew'] as $idCrew => $idNuevoAdmin) {
                                if ($idNuevoAdmin) {
                                    // Asignar nuevo admin
                                    $stmt = $pdo->prepare("UPDATE crews SET idAdmin = ? WHERE idCrew = ?");
                                    $stmt->execute([$idNuevoAdmin, $idCrew]);
                                } else {
                                    // Eliminar crew si no hay reemplazo
                                    eliminarCrew($pdo, $idCrew);
                                }
                            }
                        }
                        
                        // Procesar reemplazos para eventos
                        if (isset($reemplazos['evento'])) {
                            foreach ($reemplazos['evento'] as $idEvento => $idNuevoAdmin) {
                                if ($idNuevoAdmin) {
                                    // Asignar nuevo admin
                                    $stmt = $pdo->prepare("UPDATE eventos SET idUsuAdmin = ? WHERE idEvento = ?");
                                    $stmt->execute([$idNuevoAdmin, $idEvento]);
                                } else {
                                    // Eliminar evento si no hay reemplazo
                                    eliminarEvento($pdo, $idEvento);
                                }
                            }
                        }
                        
                        // Sacar al usuario de cualquier crew o evento restante
                        $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?");
                        $stmt->execute([$id]);
                        
                        $stmt = $pdo->prepare("DELETE FROM evento_usu WHERE idUsu = ?");
                        $stmt->execute([$id]);
                        
                        // Finalmente eliminar el usuario
                        eliminarUsuario($pdo, $id);
                        
                        $pdo->commit();
                        $response['success'] = true;
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                    }
                    break;

            case 'verificar_eliminar':
                $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // Verificar si es admin de algún crew
                    $stmt = $pdo->prepare("SELECT idCrew, Nombre FROM crews WHERE idAdmin = ?");
                    $stmt->execute([$id]);
                    $crewsAdmin = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Verificar si es admin de algún evento
                    $stmt = $pdo->prepare("SELECT idEvento, Nombre FROM eventos WHERE idUsuAdmin = ?");
                    $stmt->execute([$id]);
                    $eventosAdmin = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($crewsAdmin)) {
                        $response['necesita_reemplazo'] = true;
                        $response['es_admin_crew'] = true;
                        $response['crews'] = $crewsAdmin;
                        
                        // Obtener miembros de cada crew para posibles reemplazos
                        foreach ($response['crews'] as &$crew) {
                            $stmt = $pdo->prepare("SELECT idUsu, Nick FROM usuarios WHERE idCrew = ? AND idUsu != ?");
                            $stmt->execute([$crew['idCrew'], $id]);
                            $crew['miembros'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        }
                    }
                    
                    if (!empty($eventosAdmin)) {
                        $response['necesita_reemplazo'] = true;
                        $response['es_admin_evento'] = true;
                        $response['eventos'] = $eventosAdmin;
                        
                        // Obtener participantes de cada evento para posibles reemplazos
                        foreach ($response['eventos'] as &$evento) {
                            $stmt = $pdo->prepare("
                                SELECT u.idUsu, u.Nick 
                                FROM evento_usu eu
                                JOIN usuarios u ON eu.idUsu = u.idUsu
                                WHERE eu.idEvento = ? AND eu.idUsu != ?
                            ");
                            $stmt->execute([$evento['idEvento'], $id]);
                            $evento['participantes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        }
                    }
                    
                    if (empty($crewsAdmin) && empty($eventosAdmin)) {
                        $response['necesita_reemplazo'] = false;
                        break;
                    }
                    $response['success'] = true;
                } catch (PDOException $e) {
                    $response['error'] = 'Error en la base de datos: ' . $e->getMessage();
                }
                break;

       case 'preparar_eliminar':
            $id = $_POST['id'] ?? null;
                
                if (!$id) {
                    $response['error'] = 'ID de usuario no proporcionado';
                    echo json_encode($response);
                    exit;
                }

                try {
                    // Iniciar transacción
                    $pdo->beginTransaction();
                    
                    // 1. Sacar al usuario de su crew (si está en uno)
                    $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?");
                    $stmt->execute([$id]);
                    
                    // Actualizar contador de usuarios en crews
                    $stmt = $pdo->prepare("UPDATE crews SET NUsuarios = NUsuarios - 1 WHERE idCrew IN (SELECT idCrew FROM usuarios WHERE idUsu = ? AND idCrew IS NOT NULL)");
                    $stmt->execute([$id]);
                    
                    // 2. Sacar al usuario de todos los eventos
                    $stmt = $pdo->prepare("DELETE FROM evento_usu WHERE idUsu = ?");
                    $stmt->execute([$id]);
                    
                    $pdo->commit();
                    $response['success'] = true;
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $response['error'] = 'Error al preparar la eliminación: ' . $e->getMessage();
                }
                break;
        }
    }
    ob_end_clean();
    echo json_encode($response);
    exit;
}


// Función para mostrar usuarios
function mostrarUsuarios($pdo) {
    // Consulta para obtener usuarios con su crew y eventos
    $stmt = $pdo->query("
        SELECT 
            u.*, 
            c.Nombre as crew_nombre,
            c.idCrew as crew_id,
            GROUP_CONCAT(DISTINCT e.Nombre SEPARATOR '|') as eventos_nombres,
            GROUP_CONCAT(DISTINCT e.idEvento SEPARATOR '|') as eventos_ids
        FROM usuarios u 
        LEFT JOIN crews c ON u.idCrew = c.idCrew
        LEFT JOIN evento_usu eu ON u.idUsu = eu.idUsu
        LEFT JOIN eventos e ON eu.idEvento = e.idEvento
        GROUP BY u.idUsu
    ");
    
    $output = '<div class="mobile-table-container">
                <div class="mobile-table-hint d-block d-md-none">← Desliza para ver más →</div>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nick</th>
                            <th>Email</th>
                            <th>Crew</th>
                            <th>Eventos</th>
                            <th>Admin</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tabla-usuarios">';
    
    while ($usuario = $stmt->fetch()) {
        $output .= '<tr>';
        $output .= '<td>'.$usuario['idUsu'].'</td>';
        $output .= '<td class="text-nowrap">'.$usuario['Nick'].'</td>';
        $output .= '<td class="text-nowrap">'.$usuario['email'].'</td>';
        
        // Columna Crew con botón para salir
        $output .= '<td class="text-nowrap">';
        if ($usuario['crew_nombre']) {
            $output .= '<div class="d-flex align-items-center">';
            $output .= '<span class="me-2">'.$usuario['crew_nombre'].'</span>';
            $output .= '<button class="btn btn-sm btn-outline-danger btn-salir-crew" 
                          data-id="'.$usuario['idUsu'].'"
                          data-crew="'.$usuario['crew_nombre'].'">
                          <i class="bi bi-x-lg"></i>
                       </button>';
            $output .= '</div>';
        } else {
            $output .= 'Sin crew';
        }
        $output .= '</td>';
        
        // Columna Eventos con botones para salir
        $output .= '<td>';
        if ($usuario['eventos_nombres']) {
            $eventosNombres = explode('|', $usuario['eventos_nombres']);
            $eventosIds = explode('|', $usuario['eventos_ids']);
            
            foreach ($eventosNombres as $index => $nombreEvento) {
                $idEvento = $eventosIds[$index] ?? '';
                if ($nombreEvento && $idEvento) {
                    $output .= '<div class="d-flex align-items-center mb-1">';
                    $output .= '<span class="me-2">'.$nombreEvento.'</span>';
                    $output .= '<button class="btn btn-sm btn-outline-danger btn-salir-evento" 
                                  data-id-usuario="'.$usuario['idUsu'].'"
                                  data-id-evento="'.$idEvento.'"
                                  data-evento="'.$nombreEvento.'">
                                  <i class="bi bi-x-lg"></i>
                               </button>';
                    $output .= '</div>';
                }
            }
        } else {
            $output .= 'Sin eventos';
        }
        $output .= '</td>';
        
        // Columna Admin
        $output .= '<td class="text-nowrap">';
        if ($usuario['Admin'] == 1) {
            $output .= '<span class="badge bg-success badge-admin me-1">Admin</span>';
            $output .= '<button class="btn btn-sm btn-outline-danger quitar-admin" data-id="'.$usuario['idUsu'].'">Quitar</button>';
        } else {
            $output .= '<button class="btn btn-sm btn-outline-success hacer-admin" data-id="'.$usuario['idUsu'].'">Admin</button>';
        }
        $output .= '</td>';
        
        // Columna Acciones
        $output .= '<td class="text-nowrap">
                <button class="btn btn-sm btn-outline-primary action-btn editar-usuario" 
                        data-id="'.$usuario['idUsu'].'"
                        data-nick="'.$usuario['Nick'].'"
                        data-foto="'.(!empty($usuario['FotoPerfil']) ? 'data:image/jpeg;base64,'.base64_encode($usuario['FotoPerfil']) : '').'">
                    <i class="bi bi-pencil"></i> <span class="d-none d-md-inline">Editar</span>
                </button>
                <button class="btn btn-sm btn-outline-danger action-btn eliminar-usuario ms-1" data-id="'.$usuario['idUsu'].'">
                    <i class="bi bi-trash"></i> <span class="d-none d-md-inline">Eliminar</span>
                </button>
              </td>';
        $output .= '</tr>';
    }
    
    $output .= '</tbody></table></div>';
    return $output;
}

function eliminarUsuario($pdo, $idUsuario) {
    $transactionStarted = false;
    try {
        // Verificar si ya hay una transacción activa
        if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
            $transactionStarted = true;
        }

        // 1. Eliminar reportes relacionados
        $stmt = $pdo->prepare("DELETE FROM reportes WHERE UsuNotificador = ? OR UsuReportado = ?");
        $stmt->execute([$idUsuario, $idUsuario]);
        
        // 2. Eliminar likes del usuario
        $stmt = $pdo->prepare("DELETE FROM likes WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 3. Eliminar comentarios del usuario
        $stmt = $pdo->prepare("DELETE FROM comentario WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 4. Eliminar seguidores/seguidos
        $stmt = $pdo->prepare("DELETE FROM seguidores WHERE idSeguidor = ? OR idSeguido = ?");
        $stmt->execute([$idUsuario, $idUsuario]);
        
        // 5. Eliminar publicaciones (y sus likes/comentarios se eliminan en cascada)
        $stmt = $pdo->prepare("DELETE FROM publicaciones WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 6. Eliminar vehículos
        $stmt = $pdo->prepare("DELETE FROM vehiculos WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 7. Eliminar mensajes en chat_crew
        $stmt = $pdo->prepare("DELETE FROM chat_crew WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // 9. Finalmente eliminar el usuario
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE idUsu = ?");
        $stmt->execute([$idUsuario]);
        
        // Hacer commit solo si iniciamos la transacción
        if ($transactionStarted) {
            $pdo->commit();
        }
        return true;
    } catch (PDOException $e) {
        // Hacer rollback solo si iniciamos la transacción
        if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error al eliminar usuario $idUsuario: " . $e->getMessage());
        return false;
    }
}
function eliminarCrew($pdo, $idCrew) {
    try {
            if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
        }

        $stmt = $pdo->prepare("DELETE FROM reportes WHERE crewReportada = ?");
        $stmt->execute([$idCrew]);
        // 1. Eliminar productos del crew
        $stmt = $pdo->prepare("DELETE FROM producto WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
        // 2. Eliminar mensajes del chat del crew
        $stmt = $pdo->prepare("DELETE FROM chat_crew WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
        // 3. Actualizar publicaciones para quitar referencia al crew
        $stmt = $pdo->prepare("UPDATE publicaciones SET idCrew = NULL WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
        // 4. Actualizar usuarios para quitar referencia al crew
        $stmt = $pdo->prepare("UPDATE usuarios SET idCrew = NULL WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
        // 5. Finalmente eliminar el crew
        $stmt = $pdo->prepare("DELETE FROM crews WHERE idCrew = ?");
        $stmt->execute([$idCrew]);
        
         if ($transactionStarted) {
            $pdo->commit();
        }
        return true;
    } catch (PDOException $e) {
         if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error al eliminar crew $idCrew: " . $e->getMessage());
        return false;
    }
}

function eliminarEvento($pdo, $idEvento) {
    try {
         if (!$pdo->inTransaction()) {
            $pdo->beginTransaction();
        }
        
          $stmt = $pdo->prepare("DELETE FROM reportes WHERE EventoReportado = ?");
                $stmt->execute([$idEvento]);
        // 1. Eliminar publicaciones vinculadas al evento
        $stmt = $pdo->prepare("UPDATE publicaciones SET idEvento = NULL WHERE idEvento = ?");
        $stmt->execute([$idEvento]);
        
        // 2. Eliminar participación en el evento
        $stmt = $pdo->prepare("DELETE FROM evento_usu WHERE idEvento = ?");
        $stmt->execute([$idEvento]);
        
        // 3. Finalmente eliminar el evento
        $stmt = $pdo->prepare("DELETE FROM eventos WHERE idEvento = ?");
        $stmt->execute([$idEvento]);
        
       if ($transactionStarted) {
            $pdo->commit();
        }
        return true;
    } catch (PDOException $e) {
         if ($transactionStarted && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error al eliminar evento $idEvento: " . $e->getMessage());
        return false;
    }
}
?>