<?php
session_start();
$data=parse_ini_file("config.ini");

try {
    $pdo = new PDO(
        "mysql:host=" . $data["host"] . ";port=" . $data["port"] . ";dbname=" . $data["db"],
        $data["user"],
        $data["pass"]
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
require_once "usuarios.php";
require_once "crews.php";
require_once "eventos.php";
require_once "publicaciones.php";

// Procesar acciones
if (isset($_GET['accion'])) {
    header('Content-Type: application/json');
    $response = ['success' => false];
    
    try {
        switch ($_GET['accion']) {
            case 'obtener_usuarios':
                $response['data'] = obtenerTodosUsuarios($pdo);
                $response['success'] = true;
                break;
                
            case 'cambiar_nombre_usuario':
                $response['success'] = cambiarNombreUsuario(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['nombre'], 
                    $_POST['apellidos']
                );
                break;
                
            case 'cambiar_admin_usuario':
                $response['success'] = cambiarEstadoAdmin(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['es_admin']
                );
                break;
                
            case 'sacar_de_crew':
                $response['success'] = sacarUsuarioDeCrew($pdo, $_POST['id']);
                break;
                
            case 'eliminar_usuario':
                $response['success'] = eliminarUsuario($pdo, $_POST['id']);
                break;
                
            // ========== CREWS ==========    
            case 'obtener_crews':
                $response['data'] = obtenerTodasCrews($pdo);
                $response['success'] = true;
                break;
                
            case 'cambiar_nombre_crew':
                $response['success'] = cambiarNombreCrew(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['nombre']
                );
                break;
                
            case 'cambiar_admin_crew':
                $response['success'] = cambiarAdminCrew(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['id_admin']
                );
                break;
                
            case 'eliminar_crew':
                $response['success'] = eliminarCrew($pdo, $_POST['id']);
                break;
                
            // ========== EVENTOS ==========
            case 'obtener_eventos':
                $response['data'] = obtenerTodosEventos($pdo);
                $response['success'] = true;
                break;
                
            case 'cambiar_nombre_evento':
                $response['success'] = cambiarNombreEvento(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['nombre']
                );
                break;
                
            case 'cambiar_lugar_evento':
                $response['success'] = cambiarLugarEvento(
                    $pdo, 
                    $_POST['id'], 
                    $_POST['lugar']
                );
                break;
                
            case 'eliminar_evento':
                $response['success'] = eliminarEvento($pdo, $_POST['id']);
                break;
                
            // ========== PUBLICACIONES ==========
            case 'obtener_publicaciones':
                $response['data'] = obtenerTodasPublicaciones($pdo);
                $response['success'] = true;
                break;
                
            case 'eliminar_publicacion':
                $response['success'] = eliminarPublicacion($pdo, $_POST['id']);
                break;
                
            default:
                $response['error'] = 'Acción no válida';
        }
    } catch (PDOException $e) {
        $response['error'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit();
}
?>