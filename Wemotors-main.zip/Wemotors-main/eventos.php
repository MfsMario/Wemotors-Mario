<?php
    require_once("php/funciones.php");

    $usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

     if(!isset($_SESSION['usuario_id'])){
      header("Location: pagina_entrada.php"); 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="solicitudes.css">
    <script src="javaScript\buscar_usuarios.js"></script>
    <script src="javaScript\buscar_evento.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100" >
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="inicio.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="crews.php">Crew</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="eventos.php">Eventos</a>
                    </li>
                    <li class="nav-item position-relative">
                      <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                      <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                    </li>
                </ul>
                <div class="dropdown">
                    <button  
                    class="btn btn-outline-light dropdown-toggle" 
                    type="button" 
                    id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false">
                    <?php echo $usuario; ?>
                     <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                          style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                          <span class="visually-hidden">Solicitudes pendientes</span>
                      </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                     <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                            <ul class="dropdown-menu" id="listaSolicitudes">
                                <?php echo generarHtmlSolicitudes($pdo); ?>
                            </ul>
                      </li>
                    <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
                </div>
            </div>
        </div>
    </nav>
<main class="container mt-4">
  <div class="row justify-content-center mb-3">
    <div class="col-12 col-md-8 col-lg-6">
    <div class="d-flex flex-column flex-md-row justify-content-center align-items-center gap-3">
        <div class="position-relative flex-grow-1 w-100">
          <form id="searchEventForm" class="d-flex">
            <input class="form-control me-2" type="search" id="eventSearch" placeholder="Buscar eventos" autocomplete="off">
            <button class="btn btn-outline-dark" type="submit">Buscar</button>
          </form>
          <div id="eventResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
        </div>
        <a href="crear_evento.php" class="btn btn-outline-dark w-100 w-md-auto">Crear evento</a>
    </div>
    </div>
  </div>
  <div class="row justify-content-center mb-4">
    <div class="col-12 text-center">
      <h1 class="page-title m-0">Eventos</h1>
    </div>
  </div>
  <div  id="eventosContainer" class="row justify-content-center">
    <?php
       echo ListarEventos($pdo, null, $_SESSION['usuario_id']);
    ?>
  </div>
</main>
<?php require_once("footer.html");?>
<?php include("reportar_modal.php"); ?>
<script src="navegDesplegable.js"></script>
<script src="javaScript/solicitud.js"></script>
</body>
</html>
