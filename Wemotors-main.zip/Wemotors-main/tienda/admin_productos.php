<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar permisos
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../inicio_sesion.php');
    exit;
}

// Verificar que el usuario es admin de esta crew
$stmt = $pdo->prepare("SELECT idCrew FROM crews WHERE idAdmin = ? AND idCrew = ?");
$stmt->execute([$_SESSION['usuario_id'], $idCrew]);
$isAdmin = $stmt->fetch();

if (!$isAdmin) {
    die("No tienes permisos para administrar esta crew");
}

// Procesar eliminación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar_producto'])) {
    $productoId = $_POST['producto_id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM producto WHERE idProducto = ? AND idCrew = ?");
        $stmt->execute([$productoId, $idCrew]);
        
        $_SESSION['success'] = "Producto eliminado correctamente";
        header("Location: admin_productos.php?idCrew=$idCrew");
        exit;
    } catch (PDOException $e) {
        $error = "Error al eliminar el producto: " . $e->getMessage();
    }
}

// Obtener productos de esta crew
$productos = $pdo->prepare("SELECT * FROM producto WHERE idCrew = ?");
$productos->execute([$idCrew]);
$productos = $productos->fetchAll(PDO::FETCH_ASSOC);

// Obtener pedidos relacionados con productos de esta crew (versión mejorada)
$pedidos = $pdo->prepare("
    SELECT ped.idPedido, ped.idPago, ped.emailComprador, ped.precioPago, ped.fechaPedido,ped.Descripcion,
           GROUP_CONCAT(CONCAT(prod.Nombre, ' x', item.cantidad) SEPARATOR ', ') AS productos,
           COUNT(item.id_item) AS total_productos
    FROM pedidos ped
    LEFT JOIN carritos cart ON ped.idPago = cart.id_carrito
    LEFT JOIN carrito_items item ON cart.id_carrito = item.id_carrito
    LEFT JOIN producto prod ON item.id_producto = prod.idProducto
    WHERE ped.idCrew = ?
    GROUP BY ped.idPedido
    ORDER BY ped.fechaPedido DESC
");
$pedidos->execute([$idCrew]);
$pedidos = $pedidos->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar Productos y Pedidos - Wemotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../inicio.css">
    <link rel="stylesheet" href="../solicitudes.css">
    <link rel="stylesheet" href="../css_inicio.css">
    <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">

    <style>
        .section-title {
            margin-top: 2rem;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #dee2e6;
        }
        .pedido-row:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body  class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" href="../inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../eventos.php">Eventos</a>
                </li>
                <li class="nav-item position-relative">
                    <input type="text" class="form-control" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                    <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                </li>
            </ul>
            <div class="d-flex">
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light me-2">Volver a la tienda</a>
            </div>
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $usuario; ?>
                    
                    <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                           style="display: <?php echo (isset($_SESSION['usuario_id']) && tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'])) ? 'block' : 'none'; ?>;">
                        <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo isset($_SESSION['usuario_id']) ? generarHtmlSolicitudes($pdo) : ''; ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
    <div class="container my-5">
        <h2 class="mb-4">Administrar Productos y Pedidos</h2>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="section-title">Productos</h3>
        </div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($productos as $producto): ?>
                    <tr>
                        <td>
                            <?php if (!empty($producto['fotoProducto'])): ?>
                                <img src="data:image/jpeg;base64,<?= base64_encode($producto['fotoProducto']) ?>" 
                                    style="max-width:80px; max-height:80px; min-width:80px; min-height:80px;" class="img-thumbnail">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/80?text=Producto" width="80" height="80" class="img-thumbnail">
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($producto['Nombre']) ?></td>
                        <td><?= htmlspecialchars($producto['Descripcion']) ?></td>
                        <td>$<?= number_format($producto['precio'], 2) ?></td>
                        <td><?= $producto['cantidad'] ?></td>
                        <td>
                            <a href="editar_producto.php?id=<?= $producto['idProducto'] ?>&idCrew=<?= $idCrew ?>" 
                               class="btn btn-sm btn-warning">
                                <i class="bi bi-pencil"></i> Editar
                            </a>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="producto_id" value="<?= $producto['idProducto'] ?>">
                                <button type="submit" name="eliminar_producto" class="btn btn-sm btn-danger" 
                                        onclick="return confirm('¿Estás seguro de eliminar este producto?')">
                                    <i class="bi bi-trash"></i> Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h3 class="section-title">Pedidos</h3>
        <?php if (empty($pedidos)): ?>
            <div class="alert alert-info">No hay pedidos registrados para esta crew</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID Pedido</th>
                            <th>ID Pago</th>
                            <th>Email</th>
                            <th>Productos</th>
                            <th>Total</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos as $pedido): ?>
                        <tr class="pedido-row">
                            <td><?= $pedido['idPedido'] ?></td>
                            <td><?= htmlspecialchars($pedido['idPago']) ?></td>
                            <td><?= htmlspecialchars($pedido['emailComprador']) ?></td>
                            <td><?= htmlspecialchars($pedido['Descripcion']) ?></td>
                            <td>$<?= number_format($pedido['precioPago'], 2) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($pedido['fechaPedido'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <script src="../javaScript/solicitud.js"></script>
  <?php require_once("../footer.html");?>
</body>
</html>