<?php
require_once '../../php/funciones.php';
require_once '../config.php';
require_once '../functions.php';

// Verificar si hay datos de carrito para pagar
if (!isset($_SESSION['cart_checkout'])) {
    header("Location: /crews.php");
    exit;
}

$idCrew = $_SESSION['cart_checkout']['idCrew'];

// Obtener el carrito actualizado directamente de la base de datos
$id_carrito = getOrCreateCart($_SESSION['usuario_id'], $idCrew);
$cartItems = getCartItems($id_carrito); // Siempre obtener datos frescos
$total = getCartTotal($id_carrito);

// Actualizar sesión con datos frescos
$_SESSION['cart_checkout'] = [
    'idCrew' => (int)$idCrew,
    'items' => $cartItems,
    'total' => (float)$total,
    'timestamp' => time()
];

$usuarioNom = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

$sql = "SELECT * FROM usuarios WHERE idUsu = ?";
$sentencia = $pdo->prepare($sql);
$sentencia->execute([$_SESSION['usuario_id']]);
$usuario = $sentencia->fetch(PDO::FETCH_ASSOC);

$cartData = $_SESSION['cart_checkout'];

// Validar que los datos del carrito sean válidos
if (!isset($cartData['idCrew']) || !isset($cartData['items']) || !isset($cartData['total'])) {
    // Debug: mostrar qué contiene cartData
    error_log("CartData inválido: " . print_r($cartData, true));
    header("Location: ../crews.php");
    exit;
}

// Validar que items no esté vacío
if (empty($cartData['items']) || !is_array($cartData['items'])) {
    error_log("Items del carrito vacío o inválido");
    header("Location: cart.php?idCrew=" . $cartData['idCrew']);
    exit;
}

$idCrew = $cartData['idCrew'];
$crew = getCrewById($idCrew);

// Validar que la crew existe
if (!$crew) {
    error_log("Crew no encontrada: " . $idCrew);
    header("Location: /crews.php");
    exit;
}

// Preparar datos seguros para JavaScript - limpiar y validar cada item
$safeCartItems = [];
foreach ($cartData['items'] as $item) {
    $safeItem = [
        'id_item' => (int)($item['id_item'] ?? 0),
        'id_producto' => (int)($item['id_producto'] ?? 0), 
        'producto_nombre' => isset($item['producto_nombre']) ? (string)$item['producto_nombre'] : '',
        'cantidad' => (int)($item['cantidad'] ?? 0),
        'precio_unitario' => (float)($item['precio_unitario'] ?? 0)
    ];
    
    // Solo agregar si el item tiene datos válidos
    if ($safeItem['id_item'] > 0 && !empty($safeItem['producto_nombre']) && $safeItem['cantidad'] > 0) {
        $safeCartItems[] = $safeItem;
    }
}

// Verificar que tenemos items válidos después de la limpieza
if (empty($safeCartItems)) {
    error_log("No hay items válidos después de la limpieza");
    header("Location: cart.php?idCrew=" . $idCrew);
    exit;
}

// Debug temporal - remover después de solucionar
error_log("CartData limpio: " . print_r($safeCartItems, true));
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pasarela de Pago - <?= htmlspecialchars($crew['Nombre']) ?> - Wemotors</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../inicio.css">
    <link rel="icon" href="../../imagenes/logo wemotors.png" type="image/png">
    <link rel="stylesheet" href="../../styles.css"/>
    <link rel="stylesheet" href="../../css_inicio.css"/>
    <!-- Stripe.js -->
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        .payment-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .payment-form-container {
            flex: 1;
            min-width: 300px;
        }
        .summary-section {
            flex: 0 0 350px;
        }
        .payment-card {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .summary-item {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
        }
        #card-element {
            border: 1px solid #ced4da;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 10px;
            background-color: white;
            min-height: 40px;
        }
        #card-element.StripeElement--focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        #card-element.StripeElement--invalid {
            border-color: #dc3545;
        }
        .card-errors {
            color: #dc3545;
            margin-top: 5px;
            font-size: 14px;
        }
        @media (max-width: 992px) {
            .payment-container {
                flex-direction: column;
            }
            .summary-section {
                flex: 1;
                width: 100%;
            }
        }
    </style>
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="../../inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="../../inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../eventos.php">Eventos</a>
                </li>
            </ul>
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $usuarioNom?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li><a class="dropdown-item" href="../../perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../../cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<div class="container my-5">
    <div class="payment-container">
        <div class="payment-form-container">
            <div class="card payment-card">
                <div class="card-header bg-dark text-white">
                    <h4 class="mb-0">Información de Pago</h4>
                </div>
                <div class="card-body">
                    <form id="payment-form">
                        <div class="mb-3">
                            <label for="email" class="form-label">Correo Electrónico</label>
                            <input type="email" class="form-control" id="email" 
                                   value="<?= htmlspecialchars($usuario['email']) ?>" required disabled>
                        </div>
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Nombre en la Tarjeta</label>
                            <input type="text" class="form-control" id="name" 
                                   value="<?= htmlspecialchars($usuario['Nombre'] . ' ' . $usuario['Apellidos']) ?>" required disabeld>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Detalles de la Tarjeta</label>
                            <div id="card-element"></div>
                            <div id="card-errors" class="card-errors" role="alert"></div>
                        </div>
                        
                        <button id="submit-button" class="btn btn-dark w-100 py-2" type="submit">
                            <span id="button-text">Pagar <?= number_format($cartData['total'], 2) ?> €</span>
                            <span id="button-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="summary-section">
            <div class="card payment-card sticky-top" style="top: 20px;">
                <div class="card-header bg-dark text-white">
                    <h4 class="mb-0">Resumen del Pedido</h4>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($crew['Nombre']) ?></h5>
                    
                    <div class="summary-items mb-3">
                        <?php foreach($safeCartItems as $item): ?>
                        <div class="summary-item">
                            <div class="d-flex justify-content-between">
                                <span><?= htmlspecialchars($item['producto_nombre']) ?> x <?= $item['cantidad'] ?></span>
                                <span><?= number_format($item['precio_unitario'] * $item['cantidad'], 2) ?> €</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="summary-totals">
                        <div class="d-flex justify-content-between fw-bold mt-2 border-top pt-2">
                            <span>Total:</span>
                            <span><?= number_format($cartData['total'], 2) ?> €</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    
    // Datos seguros del carrito para JavaScript
    const cartItems = <?= json_encode($safeCartItems, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?>;
    
    // Verificar que tenemos items válidos
    if (!cartItems || cartItems.length === 0) {
        console.error('Error: No hay items válidos en el carrito');
        document.getElementById('card-errors').textContent = 'Error: No hay productos válidos en el carrito';
    }
    
    // Verificar que Stripe se haya cargado correctamente
    if (typeof Stripe === 'undefined') {
        document.getElementById('card-errors').textContent = 'Error: No se pudo cargar Stripe. Verifica tu conexión a internet.';
    } else {
        
        // Configurar Stripe con tu clave pública
        const stripe = Stripe('pk_test_51R67F1IHDcpNQ4P1iFSZMfRwGhmF0BqnrEVCKNQ1v25hcpPBk5YFpZq7HzK93460ftrEXOsCeSUVCWDK6pEdXSYE00G2XKG8eS');
        
        // Verificar que stripe se inicializó correctamente
        if (!stripe) {
            document.getElementById('card-errors').textContent = 'Error al inicializar el sistema de pagos';
        } else {
            
            // Crear elementos de Stripe
            const elements = stripe.elements({
                appearance: {
                    theme: 'stripe',
                    variables: {
                        colorPrimary: '#0570de',
                        colorBackground: '#ffffff',
                        colorText: '#30313d',
                        colorDanger: '#df1b41',
                        fontFamily: 'Ideal Sans, system-ui, sans-serif',
                        spacingUnit: '2px',
                        borderRadius: '4px',
                    }
                }
            });

            // Crear el elemento de tarjeta con opciones mejoradas
            const cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#424770',
                        '::placeholder': {
                            color: '#aab7c4',
                        },
                    },
                    invalid: {
                        color: '#9e2146',
                    },
                },
                hidePostalCode: false
            });
            
            // Montar el elemento de tarjeta
            cardElement.mount('#card-element');
            
            // Manejar errores de la tarjeta en tiempo real
            cardElement.on('change', function(event) {
                const displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                    console.error('Error en tarjeta:', event.error);
                } else {
                    displayError.textContent = '';
                }
                
              ;
            });
            

            // Manejar el envío del formulario
            const form = document.getElementById('payment-form');
            const submitButton = document.getElementById('submit-button');
            const buttonText = document.getElementById('button-text');
            const buttonSpinner = document.getElementById('button-spinner');
            
            form.addEventListener('submit', async function(event) {
                event.preventDefault();
                console.log('Formulario enviado');
                
                // Validar que tenemos items antes de procesar
                if (!cartItems || cartItems.length === 0) {
                    console.error('No hay items en el carrito para procesar');
                    document.getElementById('card-errors').textContent = 'Error: No hay productos en el carrito';
                    return;
                }
                
                // Limpiar errores previos
                document.getElementById('card-errors').textContent = '';
                
                // Deshabilitar botón y mostrar spinner
                submitButton.disabled = true;
                buttonText.textContent = 'Procesando...';
                buttonSpinner.classList.remove('d-none');
                
                try {
                    // Crear PaymentMethod
                    const { paymentMethod, error } = await stripe.createPaymentMethod({
                        type: 'card',
                        card: cardElement,
                        billing_details: {
                            name: document.getElementById('name').value,
                            email: document.getElementById('email').value
                        }
                    });
                    
                    if (error) {
                        console.error('Error al crear PaymentMethod:', error);
                        // Mostrar error al usuario
                        const errorElement = document.getElementById('card-errors');
                        errorElement.textContent = error.message;
                        
                        // Habilitar botón de nuevo
                        resetSubmitButton();
                    } else {
                        
                        // Preparar datos para enviar
                        const paymentData = {
                            payment_method_id: paymentMethod.id,
                            amount: <?= (int)($cartData['total'] * 100) ?>,
                            idCrew: <?= (int)$idCrew ?>,
                            items: cartItems,
                            email: document.getElementById('email').value,
                            user_id: <?= $_SESSION['usuario_id'] ?? 0 ?>
                        };
                        
                        
                        // Enviar a procesar_pago.php
                const response = await fetch('procesar_pago.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(paymentData)
                    });

                    // Clone the response so we can read it multiple times if needed
                    const responseClone = response.clone();

                    let data;
                    try {
                        // First try to parse as JSON
                        data = await response.json();
                        
                        if (!response.ok) {
                            throw new Error(data.error || 'Error del servidor');
                        }
                        
                        if (data.success) {
                            window.location.href = 'exito_pago.php';
                        } else {
                            throw new Error(data.error || 'Error al procesar el pago');
                        }
                    } catch (e) {
                        // If JSON parsing fails, read as text from the clone
                        try {
                            const errorText = await responseClone.text();
                            console.error('Error:', e, 'Response:', errorText);
                            
                            const errorElement = document.getElementById('card-errors');
                            errorElement.textContent = errorText.includes('{') ? 
                                'Error en el servidor' : 
                                errorText;
                        } catch (textError) {
                            console.error('Error reading response as text:', textError);
                            const errorElement = document.getElementById('card-errors');
                            errorElement.textContent = 'Error al procesar la respuesta del servidor';
                        }
                        
                        resetSubmitButton();
                    }
                    }
                } catch (error) {
                     console.error('Error durante el proceso de pago:', error);
                        const errorElement = document.getElementById('card-errors');
                        errorElement.textContent = 'Error al procesar el pago: ' + error.message;
                        resetSubmitButton();
                }
            });
            
            function resetSubmitButton() {
                submitButton.disabled = false;
                buttonText.textContent = 'Pagar <?= number_format($cartData['total'], 2) ?> €';
                buttonSpinner.classList.add('d-none');
            }
        }
    }
</script>

<?php require_once("../../footer.html"); ?>
</body>
</html>