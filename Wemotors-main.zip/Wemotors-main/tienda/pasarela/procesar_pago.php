<?php
require_once 'vendor/autoload.php';
require_once  'vendorMailer/autoload.php';
require_once '../config.php';
require_once '../../php/funciones.php';
require_once 'mail_functions.php';
require_once '../functions.php';

header('Content-Type: application/json; charset=utf-8');

// Configurar manejo de errores para producción
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Iniciar buffering de salida y limpiar cualquier output previo
ob_start();
if (ob_get_length()) {
    ob_clean();
}

// Función para enviar respuesta JSON y terminar
function sendJsonResponse($data, $httpCode = 200) {
    // Limpiar cualquier output previo
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Verificar que no se hayan enviado headers todavía
    if (headers_sent()) {
        error_log("Headers ya enviados, no se puede enviar respuesta JSON");
        exit;
    }
    
    // Configurar headers
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
    
    // Enviar respuesta y terminar
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Función simple para enviar correos
function enviarCorreosFlujoPago($pedidoId, $paymentIntentId, $debug = false) {
   
    global $pdo;
    
    if ($debug) {
        error_log("=== INICIO envío correos con debug activado ===");
    }
    
    try {
        // Obtener información del pedido con más detalles
        $stmt = $pdo->prepare("
            SELECT p.*, u.email as admin_email, u.Nombre as admin_nombre, 
                   u.Apellidos as admin_apellidos, c.Nombre as crew_nombre,
                   uc.email as comprador_email_verificado, uc.Nombre as comprador_nombre_verificado
            FROM pedidos p
            JOIN crews c ON p.idCrew = c.idCrew
            LEFT JOIN usuarios u ON c.idAdmin = u.idUsu
            LEFT JOIN usuarios uc ON uc.email = p.emailComprador
            WHERE p.idPedido = ?
        ");
        $stmt->execute([$pedidoId]);
        $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$pedido) {
            error_log("ERROR: No se encontró el pedido con ID: $pedidoId");
            return false;
        }
        
        if ($debug) {
            error_log("Pedido encontrado: " . json_encode($pedido, JSON_PRETTY_PRINT));
        }
        $resultados = [];
        
        // Correo al comprador
        if (!empty($pedido['emailComprador'])) {
            $asuntoComprador = "✅ Confirmación de compra - Wemotors";
            $cuerpoComprador = "
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <title>Confirmación de compra</title>
                </head>
                <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                    <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                        <h1 style='color: #343a40; margin: 0;'>🎉 ¡Compra confirmada!</h1>
                    </div>
                    
                    <div style='background: white; padding: 20px; border: 1px solid #dee2e6; border-radius: 8px;'>
                        <p>Hola <strong>{$pedido['NombreComprador']}</strong>,</p>
                        
                        <p style='color: #28a745; font-size: 18px;'><strong>✅ Tu pago ha sido procesado exitosamente</strong></p>
                        
                        <div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                            <h3 style='margin-top: 0; color: #495057;'>📄 Detalles del pedido:</h3>
                            <p><strong>ID de pago:</strong> {$paymentIntentId}</p>
                            <p><strong>Total pagado:</strong> <span style='color: #28a745; font-size: 18px;'>€{$pedido['precioPago']}</span></p>
                            <p><strong>Crew:</strong> {$pedido['crew_nombre']}</p>
                            <p><strong>Productos:</strong> {$pedido['Descripcion']}</p>
                            <p><strong>Fecha:</strong> " . date('d/m/Y H:i:s') . "</p>
                        </div>
                        
                        <p>🚗 <strong>Próximos pasos:</strong></p>
                        <ul>
                            <li>El administrador de la crew se pondrá en contacto contigo pronto</li>
                            <li>Guarda este correo como comprobante de tu compra</li>
                            <li>Si tienes dudas, puedes contactarnos</li>
                        </ul>
                        
                        <div style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; color: #6c757d; font-size: 14px;'>
                            <p>Gracias por elegir Wemotors 🏁</p>
                            <p><em>Este es un correo automático, por favor no respondas a esta dirección.</em></p>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            if ($debug) {
                error_log("Enviando correo al comprador: " . $pedido['emailComprador']);
            }
            $resultadoComprador = enviarCorreoConfirmacion(
                $pedido['emailComprador'], 
                $pedido['NombreComprador'], 
                $asuntoComprador, 
                $cuerpoComprador
            );
            
            $resultados['comprador'] = $resultadoComprador;
            
            if ($resultadoComprador) {
                error_log("SUCCESS: Correo enviado al comprador");
            } else {
                error_log("ERROR: Fallo envío al comprador");
            }
        } else {
            error_log("WARNING: No hay email de comprador");
            $resultados['comprador'] = false;
        }
        
        // Correo al admin/vendedor
        if (!empty($pedido['admin_email'])) {
            $nombreAdmin = trim(($pedido['admin_nombre'] ?? '') . ' ' . ($pedido['admin_apellidos'] ?? ''));
            if (empty($nombreAdmin)) {
                $nombreAdmin = 'Administrador';
            }
            
            $asuntoVendedor = "💰 Nueva compra en tu crew - Wemotors";
            $cuerpoVendedor = "
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='utf-8'>
                    <title>Nueva compra recibida</title>
                </head>
                <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                    <div style='background: #e3f2fd; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                        <h1 style='color: #1565c0; margin: 0;'>💰 ¡Nueva compra recibida!</h1>
                    </div>
                    
                    <div style='background: white; padding: 20px; border: 1px solid #dee2e6; border-radius: 8px;'>
                        <p>Hola <strong>$nombreAdmin</strong>,</p>
                        
                        <p style='color: #1976d2; font-size: 18px;'><strong>📦 Se realizó una nueva compra en tu crew: {$pedido['crew_nombre']}</strong></p>
                        
                        <div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                            <h3 style='margin-top: 0; color: #495057;'>👤 Información del comprador:</h3>
                            <p><strong>Nombre:</strong> {$pedido['NombreComprador']}</p>
                            <p><strong>Email:</strong> <a href='mailto:{$pedido['emailComprador']}'>{$pedido['emailComprador']}</a></p>
                        </div>
                        
                        <div style='background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                            <h3 style='margin-top: 0; color: #2e7d32;'>💳 Detalles del pago:</h3>
                            <p><strong>ID de pago:</strong> {$paymentIntentId}</p>
                            <p><strong>Total:</strong> <span style='color: #2e7d32; font-size: 18px;'>€{$pedido['precioPago']}</span></p>
                            <p><strong>Productos:</strong> {$pedido['Descripcion']}</p>
                            <p><strong>Fecha:</strong> " . date('d/m/Y H:i:s') . "</p>
                        </div>
                        
                        <p>🚀 <strong>Próximos pasos:</strong></p>
                        <ul>
                            <li>Contacta al comprador para coordinar la entrega</li>
                            <li>Verifica que tienes el stock disponible</li>
                            <li>Proporciona la información de entrega necesaria</li>
                        </ul>
                        
                        <div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ffc107;'>
                            <p style='margin: 0;'><strong>💡 Tip:</strong> Responde rápidamente al comprador para ofrecer la mejor experiencia de servicio.</p>
                        </div>
                        
                        <div style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; color: #6c757d; font-size: 14px;'>
                            <p>¡Felicidades por tu venta! 🎉</p>
                            <p><em>Equipo Wemotors</em></p>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            if ($debug) {
                error_log("Enviando correo al vendedor: " . $pedido['admin_email']);
            }
            
            $resultadoVendedor = enviarCorreoConfirmacion(
                $pedido['admin_email'], 
                $nombreAdmin, 
                $asuntoVendedor, 
                $cuerpoVendedor
            );
            
            $resultados['vendedor'] = $resultadoVendedor;
            
            if ($resultadoVendedor) {
                error_log("SUCCESS: Correo enviado al vendedor");
            } else {
                error_log("ERROR: Fallo envío al vendedor");
            }
        } else {
            if ($debug) {
                error_log("INFO: No hay email de admin para notificar");
            }
            $resultados['vendedor'] = true; // No es error si no hay admin
        }
        
        $todosExitosos = $resultados['comprador'] && $resultados['vendedor'];
        
        if ($debug) {
            error_log("=== FIN envío correos - Resultados: " . json_encode($resultados) . " ===");
        }
        
        return $todosExitosos;
        
    } catch (Exception $e) {
        error_log("ERROR en envío de correos: " . $e->getMessage());
        if ($debug) {
            error_log("Stack trace: " . $e->getTraceAsString());
        }
        return false;
    }
}
// Configurar Stripe
\Stripe\Stripe::setApiKey('sk_test_51R67F1IHDcpNQ4P1dL2ADbVZbCupC60XeRS847Iq91oghnVynGXDfVLTXlkb7qKQ7ism4LERbd3WC8BBIC9ZbMJF00Qdtfl7vs');

error_log("Procesando pago - Inicio");

try {
    // Verificar método de petición
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendJsonResponse(['success' => false, 'error' => 'Método no permitido'], 405);
    }

    // Obtener y validar datos de entrada
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendJsonResponse(['success' => false, 'error' => 'Error al decodificar JSON: ' . json_last_error_msg()], 400);
    }

    // Validar datos obligatorios
    if (empty($input['payment_method_id'])) {
        sendJsonResponse(['success' => false, 'error' => 'Payment method ID requerido'], 400);
    }
    
    if (empty($input['amount']) || !is_numeric($input['amount'])) {
        sendJsonResponse(['success' => false, 'error' => 'Monto inválido'], 400);
    }
    
    if (empty($input['email']) || !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        sendJsonResponse(['success' => false, 'error' => 'Email inválido'], 400);
    }
    
    if (empty($input['user_id']) || !is_numeric($input['user_id'])) {
        sendJsonResponse(['success' => false, 'error' => 'ID de usuario inválido'], 400);
    }
    
    if (empty($input['idCrew']) || !is_numeric($input['idCrew'])) {
        sendJsonResponse(['success' => false, 'error' => 'ID de crew inválido'], 400);
    }
    
    if (empty($input['items']) || !is_array($input['items'])) {
        sendJsonResponse(['success' => false, 'error' => 'Items del carrito inválidos'], 400);
    }

    // Verificar que el monto sea positivo
    $amount = (int)$input['amount'];
    if ($amount <= 0) {
        sendJsonResponse(['success' => false, 'error' => 'El monto debe ser mayor a cero'], 400);
    }

    foreach ($input['items'] as $item) {
    $stmt = $pdo->prepare("SELECT cantidad FROM producto WHERE idProducto = ?");
    $stmt->execute([$item['id_producto']]);
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$producto) {
        sendJsonResponse(['success' => false, 'error' => 'Producto no encontrado: ID ' . $item['id_item']], 400);
    }
    
    if ($producto['cantidad'] < $item['cantidad']) {
        sendJsonResponse(['success' => false, 'error' => 'No hay suficiente stock para: ' . $item['producto_nombre']], 400);
    }
}

    error_log("Validaciones pasadas, creando PaymentIntent");

    // Crear PaymentIntent con Stripe
    $intent = \Stripe\PaymentIntent::create([
        'amount' => $amount,
        'currency' => 'eur',
        'payment_method' => $input['payment_method_id'],
        'receipt_email' => $input['email'],
        'confirm' => true,
        'automatic_payment_methods' => [
            'enabled' => true,
            'allow_redirects' => 'never'
        ],
        'metadata' => [
            'user_id' => (string)$input['user_id'],
            'crew_id' => (string)$input['idCrew'],
            'items_count' => (string)count($input['items'])
        ],
        'description' => 'Compra en Wemotors - Crew ID: ' . $input['idCrew']
    ]);

    error_log("PaymentIntent creado con ID: " . $intent->id . " y status: " . $intent->status);

    // Verificar el estado del pago
    if ($intent->status === 'succeeded') {
        error_log("Pago exitoso, guardando en base de datos");
        
        // Iniciar transacción de base de datos
        $pdo->beginTransaction();
        
        try {
            // Obtener información del usuario
            $stmt = $pdo->prepare("SELECT Nombre, Apellidos, email FROM usuarios WHERE idUsu = ?");
            $stmt->execute([$input['user_id']]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$usuario) {
                throw new Exception("Usuario no encontrado");
            }
            
            $nombreComprador = trim($usuario['Nombre'] . ' ' . $usuario['Apellidos']);
            $emailComprador = $usuario['email'];
            
            // Crear descripción detallada del pedido
            $descripcion = '';
            $totalCalculado = 0;
            
            foreach ($input['items'] as $item) {
                if (!isset($item['cantidad']) || !isset($item['producto_nombre']) || !isset($item['precio_unitario'])) {
                    throw new Exception("Item inválido en el carrito");
                }
                
                $cantidad = (int)$item['cantidad'];
                $precio = (float)$item['precio_unitario'];
                $subtotal = $cantidad * $precio;
                $totalCalculado += $subtotal;
                
                $descripcion .= $cantidad . ' x ' . $item['producto_nombre'] . ' (€' . number_format($precio, 2) . '), ';
            }
            
            $descripcion = rtrim($descripcion, ', ');
            
            // Verificar que el total calculado coincida con el monto del pago
            $totalEsperado = round($totalCalculado * 100);
            if (abs($totalEsperado - $amount) > 1) {
                error_log("Diferencia en montos - Calculado: $totalEsperado, Recibido: $amount");
                throw new Exception("El monto no coincide con los items del carrito");
            }
            
            // Verificar que la crew existe
            $stmt = $pdo->prepare("SELECT idCrew FROM crews WHERE idCrew = ?");
            $stmt->execute([$input['idCrew']]);
            if (!$stmt->fetch()) {
                throw new Exception("Crew no encontrada");
            }
            
            // Insertar pedido en la base de datos
          $stmt = $pdo->prepare("
    INSERT INTO pedidos (idPago, NombreComprador, emailComprador, idCrew, Descripcion, precioPago, fechaPedido) 
    VALUES (?, ?, ?, ?, ?, ?, NOW())
");

        $precioFinal = $amount / 100;

        $resultado = $stmt->execute([
            $intent->id,
            $nombreComprador,
            $emailComprador,
            $input['idCrew'],
            $descripcion,
            $precioFinal
        ]);

        if (!$resultado) {
            throw new Exception("Error al insertar el pedido en la base de datos");
        }

        $pedidoId = $pdo->lastInsertId();
        error_log("Pedido insertado con ID: " . $pedidoId);

       foreach ($input['items'] as $item) {
        $stmt = $pdo->prepare("UPDATE producto SET cantidad = cantidad - ? WHERE idProducto = ?");
        $stmt->execute([$item['cantidad'], $item['id_producto']]); 
                
            // Verificar que la actualización fue exitosa
            if ($stmt->rowCount() === 0) {
                throw new Exception("Error al actualizar el stock del producto ID: " . $item['id_item']);
            }
            
            error_log("Stock actualizado - Producto ID: " . $item['id_item'] . " - Cantidad restada: " . $item['cantidad']);
        }

        // Confirmar transacción
        $pdo->commit();
            
            // Limpiar carrito
            $id_carrito = getOrCreateCart($input['user_id'], $input['idCrew']);
            emptyCart($id_carrito);

            // Limpiar datos de sesión
            if (isset($_SESSION['cart_checkout'])) {
                unset($_SESSION['cart_checkout']);
            }
            
            $_SESSION['last_payment'] = [
                'payment_intent_id' => $intent->id,
                'amount' => $precioFinal,
                'date' => date('Y-m-d H:i:s'),
                'crew_id' => $input['idCrew']
            ];

            error_log("Respondiendo al cliente antes de enviar correos");
            
            // PRIMERO responder al cliente
            $response = [
                'success' => true,
                'payment_intent_id' => $intent->id,
                'pedido_id' => $pedidoId,
                'message' => 'Pago procesado exitosamente'
            ];
            
            // Enviar respuesta JSON
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            
       
            http_response_code(200);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            
            // Forzar el envío de la respuesta al cliente
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            } else {
                ignore_user_abort(true);
                flush();
            }
            
            // DESPUÉS enviar los correos (en background)
            error_log("Cliente ya recibió respuesta, enviando correos ahora");
          $correosEnviados = enviarCorreosFlujoPago($pedidoId, $intent->id);
            
            if ($correosEnviados) {
                error_log("SUCCESS: Correos enviados correctamente");
            } else {
                error_log("WARNING: Hubo problemas enviando algunos correos");
            }
            
            // Terminar el script
            exit;
            
        } catch (Exception $dbError) {
            // Revertir transacción en caso de error
            $pdo->rollBack();
            error_log("Error en base de datos: " . $dbError->getMessage());
            sendJsonResponse(['success' => false, 'error' => 'Error al guardar el pedido: ' . $dbError->getMessage()], 500);
        }
        
    } elseif ($intent->status === 'requires_action') {
        
        $response = [
            'success' => false,
            'requires_action' => true,
            'payment_intent' => [
                'id' => $intent->id,
                'client_secret' => $intent->client_secret
            ],
            'error' => 'El pago requiere autenticación adicional'
        ];
        
        error_log("Pago requiere autenticación - PaymentIntent: " . $intent->id);
        sendJsonResponse($response, 200);
        
    } else {
        // Pago falló
        $errorMessage = 'Pago no completado. Estado: ' . $intent->status;
        
        if (isset($intent->last_payment_error)) {
            $errorMessage .= ' - ' . $intent->last_payment_error->message;
        }
        
        $response = [
            'success' => false,
            'error' => $errorMessage
        ];
        
        error_log("Pago falló - Status: " . $intent->status . " - PaymentIntent: " . $intent->id);
        sendJsonResponse($response, 400);
    }

} catch (\Stripe\Exception\CardException $e) {
    error_log("Error de tarjeta Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error en la tarjeta: ' . $e->getError()->message
    ], 400);
    
} catch (\Stripe\Exception\RateLimitException $e) {
    error_log("Rate limit Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Demasiadas peticiones. Intenta de nuevo en un momento.'
    ], 429);
    
} catch (\Stripe\Exception\InvalidRequestException $e) {
    error_log("Petición inválida Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error en la petición de pago'
    ], 400);
    
} catch (\Stripe\Exception\AuthenticationException $e) {
    error_log("Error de autenticación Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error de configuración del sistema de pagos'
    ], 500);
    
} catch (\Stripe\Exception\ApiConnectionException $e) {
    error_log("Error de conexión Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error de conexión con el sistema de pagos'
    ], 500);
    
} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log("Error general Stripe: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error en el sistema de pagos'
    ], 500);
    
} catch (PDOException $e) {
    error_log("Error de base de datos: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => 'Error interno del servidor'
    ], 500);
    
} catch (Exception $e) {
    error_log("Error general: " . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error' => $e->getMessage()
    ], 500);
}

sendJsonResponse(['success' => false, 'error' => 'Error inesperado'], 500);
?>