<?php
require_once '../../php/funciones.php';
require_once '../config.php';
require_once '../functions.php';


// Verificar si hay un pago reciente
if (!isset($_SESSION['last_payment'])) {
    header("Location: /crews.php");
    exit;
}

$pago = $_SESSION['last_payment'];
$usuarioNom = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

// Obtener datos del usuario
$sql = "SELECT * FROM usuarios WHERE idUsu = ?";
$sentencia = $pdo->prepare($sql);
$sentencia->execute([$_SESSION['usuario_id']]);
$usuario = $sentencia->fetch(PDO::FETCH_ASSOC);

// Obtener datos del pedido
$sqlPedido = "SELECT * FROM pedidos WHERE idPago = ?";
$sentenciaPedido = $pdo->prepare($sqlPedido);
$sentenciaPedido->execute([$pago['payment_intent_id']]);
$pedido = $sentenciaPedido->fetch(PDO::FETCH_ASSOC);

// Obtener datos de la crew
if ($pedido) {
    $crew = getCrewById($pedido['idCrew']);
} else {
    $crew = null;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Exitoso - Wemotors</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../inicio.css">
    <link rel="icon" href="../../imagenes/logo wemotors.png" type="image/png">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .ticket-container {
            max-width: 600px;
            margin: 40px auto;
        }
        .ticket-card {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            border: none;
        }
        .ticket-header {
            background-color: #28a745;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .ticket-body {
            padding: 30px;
            background-color: white;
        }
        .ticket-title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #28a745;
        }
        .ticket-detail {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #eee;
        }
        .ticket-detail-label {
            font-weight: 600;
            color: #6c757d;
        }
        .ticket-detail-value {
            color: #212529;
        }
        .ticket-items {
            margin-top: 25px;
        }
        .ticket-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .ticket-total {
            font-size: 20px;
            font-weight: 600;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 2px solid #eee;
        }
        .ticket-footer {
            text-align: center;
            padding: 20px;
            background-color: #f8f9fa;
            border-top: 1px solid #eee;
            font-size: 14px;
            color: #6c757d;
        }
        .ticket-icon {
            font-size: 48px;
            margin-bottom: 15px;
            color: white;
        }
        .btn-continue {
            background-color: #28a745;
            color: white;
            padding: 10px 25px;
            font-weight: 600;
            margin-top: 30px;
        }
        .btn-continue:hover {
            background-color: #218838;
            color: white;
        }
    </style>
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">

<div class="container my-5">
    <div class="ticket-container">
        <div class="card ticket-card">
            <div class="ticket-header">
                <i class="bi bi-check-circle-fill ticket-icon"></i>
                <h2>¡Pago Completado con Éxito!</h2>
                <p class="mb-0">Gracias por tu compra</p>
            </div>
            
            <div class="ticket-body">
                <div class="ticket-title">Resumen de tu pedido</div>
                
                <div class="ticket-detail">
                    <div class="ticket-detail-label">Número de pedido</div>
                    <div class="ticket-detail-value"><?= htmlspecialchars($pago['payment_intent_id']) ?></div>
                </div>
                
                <div class="ticket-detail">
                    <div class="ticket-detail-label">Fecha</div>
                    <div class="ticket-detail-value"><?= date('d/m/Y H:i') ?></div>
                </div>
                
                <div class="ticket-detail">
                    <div class="ticket-detail-label">Email</div>
                    <div class="ticket-detail-value"><?= htmlspecialchars($pedido['emailComprador'] ?? $usuario['email']) ?></div>
                </div>
                
                <?php if ($crew): ?>
                <div class="ticket-detail">
                    <div class="ticket-detail-label">Crew</div>
                    <div class="ticket-detail-value"><?= htmlspecialchars($crew['Nombre']) ?></div>
                </div>
                <?php endif; ?>
                
                <div class="ticket-items">
                    <div class="ticket-detail-label mb-3">Productos:</div>
                    
                    <?php 
                    if ($pedido && !empty($pedido['Descripcion'])) {
                        $items = explode(',', $pedido['Descripcion']);
                        foreach ($items as $item): 
                            $item = trim($item);
                            if (!empty($item)):
                    ?>
                        <div class="ticket-item">
                            <span><?= htmlspecialchars($item) ?></span>
                        </div>
                    <?php 
                            endif;
                        endforeach;
                    } else {
                        echo '<div class="text-muted">No se encontraron detalles de productos</div>';
                    }
                    ?>
                    
                    <div class="ticket-total">
                        <div class="d-flex justify-content-between">
                            <span>Total:</span>
                            <span><?= number_format($pedido['precioPago'] ?? 0, 2) ?> €</span>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="../../inicio.php" class="btn btn-continue">
                        <i class="bi bi-arrow-left"></i> Volver al inicio
                    </a>
                </div>
            </div>
            
            <div class="ticket-footer">
                <p class="mb-1">Gracias por confiar en Wemotors</p>
                <p class="mb-0">Recibirás un correo con los detalles de tu compra</p>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>