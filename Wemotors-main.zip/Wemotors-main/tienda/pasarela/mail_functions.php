<?php
require_once __DIR__ . '/vendorMailer/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function enviarCorreoConfirmacion($destinatario, $nombreDestinatario, $asunto, $cuerpo) {
    $mail = new PHPMailer(true);
    
    try {
        error_log("=== INICIANDO ENVÍO DE CORREO ===");
        error_log("Destinatario: " . $destinatario);
        error_log("Asunto: " . $asunto);
        
        // Habilitar debug SMTP para ver qué está pasando
        $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Cambiar a DEBUG_OFF en producción
        $mail->Debugoutput = function($str, $level) {
            error_log("SMTP Debug ($level): " . trim($str));
        };
        
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'wemotorscrew@gmail.com';
        $mail->Password = 'ttdwcpbkhmzlpgsu'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Configuraciones adicionales para Gmail
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        
        // Aumentar timeout
        $mail->Timeout = 60;
        $mail->SMTPKeepAlive = true;
        
        // Configuración del remitente
        $mail->setFrom('wemotorscrew@gmail.com', 'Wemotors');
        $mail->addAddress($destinatario, $nombreDestinatario);
        
        // Configuración de respuesta
        $mail->addReplyTo('wemotorscrew@gmail.com', 'Wemotors');
        
        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body = $cuerpo;
        $mail->AltBody = strip_tags($cuerpo);
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        
        // Headers adicionales para evitar spam
        $mail->addCustomHeader('X-Mailer', 'Wemotors System');
        $mail->addCustomHeader('X-Priority', '3');
        
        error_log("Intentando enviar correo...");
        $resultado = $mail->send();
        
        if ($resultado) {
            error_log("SUCCESS: Correo enviado exitosamente a: " . $destinatario);
            return true;
        } else {
            error_log("ERROR: No se pudo enviar el correo");
            return false;
        }
        
    } catch (Exception $e) {
        error_log("EXCEPCIÓN al enviar correo: " . $e->getMessage());
        error_log("ErrorInfo: " . $mail->ErrorInfo);
        error_log("Stack trace: " . $e->getTraceAsString());
        return false;
    }
}

// Función para verificar la configuración de Gmail
function verificarConfiguracionGmail() {
    error_log("=== VERIFICANDO CONFIGURACIÓN GMAIL ===");
    
    $mail = new PHPMailer(true);
    
    try {
        $mail->SMTPDebug = SMTP::DEBUG_CONNECTION;
        $mail->Debugoutput = function($str, $level) {
            error_log("Gmail Test ($level): " . trim($str));
        };
        
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'wemotorscrew@gmail.com';
        $mail->Password = 'ttdwcpbkhmzlpgsu';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Solo intentar conectar, no enviar
        if ($mail->smtpConnect()) {
            error_log("SUCCESS: Conexión SMTP exitosa");
            $mail->smtpClose();
            return true;
        } else {
            error_log("ERROR: No se pudo conectar al servidor SMTP");
            return false;
        }
        
    } catch (Exception $e) {
        error_log("ERROR en verificación Gmail: " . $e->getMessage());
        return false;
    }
}

// Función de prueba simple
function enviarCorreoPrueba($email = 'tu-email-de-prueba@gmail.com') {
    $asunto = "Test de correo - " . date('Y-m-d H:i:s');
    $cuerpo = "
        <h1>Correo de prueba</h1>
        <p>Este es un correo de prueba enviado el: " . date('d/m/Y H:i:s') . "</p>
        <p>Si recibes este correo, la configuración está funcionando correctamente.</p>
    ";
    
    return enviarCorreoConfirmacion($email, 'Usuario Prueba', $asunto, $cuerpo);
}
?>