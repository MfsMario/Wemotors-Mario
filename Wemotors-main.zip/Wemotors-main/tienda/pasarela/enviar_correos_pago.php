<?php
require_once '../config.php';
require_once 'mail_functions.php';

// Este archivo se ejecutará de forma separada para enviar correos
// sin afectar la respuesta del pago

// Configurar manejo de errores
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

function enviarCorreosPago($pedidoId, $paymentIntentId) {
    global $pdo;
    
    try {
        // Obtener información del pedido
        $stmt = $pdo->prepare("
            SELECT p.*, u.email as admin_email, u.Nombre as admin_nombre, c.Nombre as crew_nombre
            FROM pedidos p
            JOIN crews c ON p.idCrew = c.idCrew
            LEFT JOIN usuarios u ON c.idAdmin = u.idUsu
            WHERE p.id = ?
        ");
        $stmt->execute([$pedidoId]);
        $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$pedido) {
            error_log("No se encontró el pedido con ID: $pedidoId");
            return false;
        }
        
        $nombreComprador = $pedido['NombreComprador'];
        $emailComprador = $pedido['emailComprador'];
        $descripcion = $pedido['Descripcion'];
        $precioFinal = $pedido['precioPago'];
        $fechaPedido = date('d/m/Y H:i', strtotime($pedido['fechaPedido']));
        
        // Correo para el comprador
        $asuntoComprador = "✅ Confirmación de tu compra en Wemotors";
        $cuerpoComprador = "
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset='UTF-8'>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background-color: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; }
                    .content { padding: 20px 0; }
                    .details { background-color: #f1f3f4; padding: 15px; border-radius: 5px; margin: 15px 0; }
                    .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
                    .highlight { color: #28a745; font-weight: bold; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h1 style='color: #28a745; margin: 0;'>¡Gracias por tu compra!</h1>
                    </div>
                    
                    <div class='content'>
                        <p>Hola <strong>{$nombreComprador}</strong>,</p>
                        <p>Tu pago de <span class='highlight'>€{$precioFinal}</span> ha sido procesado correctamente.</p>
                        
                        <div class='details'>
                            <h3>📋 Detalles del pedido:</h3>
                            <p><strong>ID de pago:</strong> {$paymentIntentId}</p>
                            <p><strong>Crew:</strong> {$pedido['crew_nombre']}</p>
                            <p><strong>Fecha:</strong> {$fechaPedido}</p>
                            <p><strong>Productos:</strong> {$descripcion}</p>
                            <p><strong>Total pagado:</strong> <span class='highlight'>€{$precioFinal}</span></p>
                        </div>
                        
                        <p>🚚 <strong>¿Qué sigue?</strong></p>
                        <p>El equipo de la crew se pondrá en contacto contigo para coordinar la entrega de tus productos.</p>
                        
                        <p>Si tienes alguna pregunta sobre tu pedido, no dudes en contactarnos.</p>
                    </div>
                    
                    <div class='footer'>
                        <p>Gracias por confiar en Wemotors 🏎️<br>
                        El equipo de Wemotors</p>
                    </div>
                </div>
            </body>
            </html>
        ";

        // Enviar correo al comprador
        $correoCompradorEnviado = false;
        if (function_exists('enviarCorreoConfirmacion')) {
            $correoCompradorEnviado = enviarCorreoConfirmacion($emailComprador, $nombreComprador, $asuntoComprador, $cuerpoComprador);
            if ($correoCompradorEnviado) {
                error_log("Correo de confirmación enviado exitosamente al comprador: " . $emailComprador);
            } else {
                error_log("Error al enviar correo de confirmación al comprador: " . $emailComprador);
            }
        }

        // Si hay admin de crew, enviar notificación
        $correoAdminEnviado = false;
        if (!empty($pedido['admin_email']) && !empty($pedido['admin_nombre'])) {
            $asuntoAdmin = "🛒 Nueva compra en tu crew: {$pedido['crew_nombre']}";
            $cuerpoAdmin = "
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='UTF-8'>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                        .header { background-color: #007bff; color: white; padding: 20px; border-radius: 8px; text-align: center; }
                        .content { padding: 20px 0; }
                        .details { background-color: #e3f2fd; padding: 15px; border-radius: 5px; margin: 15px 0; }
                        .footer { text-align: center; color: #666; font-size: 12px; margin-top: 30px; }
                        .highlight { color: #007bff; font-weight: bold; }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1 style='margin: 0;'>Nueva compra recibida</h1>
                        </div>
                        
                        <div class='content'>
                            <p>Hola <strong>{$pedido['admin_nombre']}</strong>,</p>
                            <p>Se ha realizado una nueva compra en tu crew <strong>{$pedido['crew_nombre']}</strong>.</p>
                            
                            <div class='details'>
                                <h3>📊 Detalles del pedido:</h3>
                                <p><strong>Comprador:</strong> {$nombreComprador}</p>
                                <p><strong>Email del comprador:</strong> {$emailComprador}</p>
                                <p><strong>ID de pago:</strong> {$paymentIntentId}</p>
                                <p><strong>Total:</strong> <span class='highlight'>€{$precioFinal}</span></p>
                                <p><strong>Fecha:</strong> {$fechaPedido}</p>
                                <p><strong>Productos:</strong> {$descripcion}</p>
                            </div>
                            
                            <p>📞 <strong>Acción requerida:</strong></p>
                            <p>Por favor, ponte en contacto con el comprador para coordinar la entrega de los productos.</p>
                            
                            <p>Puedes acceder a tu panel de administración para ver más detalles del pedido.</p>
                        </div>
                        
                        <div class='footer'>
                            <p>Panel de administración - Wemotors 🏎️</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            if (function_exists('enviarCorreoConfirmacion')) {
                $correoAdminEnviado = enviarCorreoConfirmacion($pedido['admin_email'], $pedido['admin_nombre'], $asuntoAdmin, $cuerpoAdmin);
                if ($correoAdminEnviado) {
                    error_log("Correo de notificación enviado exitosamente al admin: " . $pedido['admin_email']);
                } else {
                    error_log("Error al enviar correo de notificación al admin: " . $pedido['admin_email']);
                }
            }
        } else {
            error_log("No se encontró información del admin para la crew ID: " . $pedido['idCrew']);
        }
        
        return $correoCompradorEnviado || $correoAdminEnviado;
        
    } catch (Exception $e) {
        error_log("Error al enviar correos de confirmación: " . $e->getMessage());
        return false;
    }
}

// Si se llama directamente con parámetros GET
if (isset($_GET['pedido_id']) && isset($_GET['payment_intent_id'])) {
    $pedidoId = (int)$_GET['pedido_id'];
    $paymentIntentId = $_GET['payment_intent_id'];
    
    if ($pedidoId > 0 && !empty($paymentIntentId)) {
        enviarCorreosPago($pedidoId, $paymentIntentId);
    }
}
?>