<?php
// test_email.php
require 'mail_functions.php'; // Asegúrate de que la ruta sea correcta

// Verificar si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Configuración del correo de prueba
    $destinatario = 'mfsmario2005@gmail.com'; // Cambia esto por tu email de prueba
    $nombreDestinatario = 'Usuario de Prueba';
    $asunto = 'Prueba de correo desde WeMotors';
    $cuerpo = '
        <h1>¡Correo de prueba enviado correctamente!</h1>
        <p>Este es un correo de prueba enviado desde el sistema de WeMotors.</p>
        <p>Fecha y hora: '.date('Y-m-d H:i:s').'</p>
    ';
    
    // Intentar enviar el correo
    $resultado = enviarCorreoConfirmacion($destinatario, $nombreDestinatario, $asunto, $cuerpo);
    
    // Mostrar mensaje según el resultado
    if ($resultado) {
        $mensaje = '<div class="alert alert-success">¡Correo enviado correctamente!</div>';
    } else {
        $mensaje = '<div class="alert alert-danger">Error al enviar el correo. Revisa los logs para más información.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba de Envío de Correos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h2 class="text-center">Prueba de Envío de Correos</h2>
                    </div>
                    <div class="card-body">
                        <?php if (isset($mensaje)) echo $mensaje; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Destinatario:</label>
                                <input type="text" class="form-control" value="mfsmario2005@gmail.com" readonly>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Enviar Correo de Prueba</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-muted">
                        Sistema de correos - WeMotors
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>