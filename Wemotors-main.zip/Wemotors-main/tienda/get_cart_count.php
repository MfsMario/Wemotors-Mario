<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

if (!isset($_SESSION['usuario_id']) || !isset($_GET['id_crew'])) {
    echo '0';
    exit;
}

$id_carrito = getCartIdForUser($_SESSION['usuario_id'], $_GET['id_crew']);
$count = $id_carrito ? getCartCount($id_carrito) : 0;

echo $count;