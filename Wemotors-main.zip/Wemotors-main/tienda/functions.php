<?php
require_once 'db.php';

// Función para obtener o crear carrito (sin cambios)
function getOrCreateCart($id_usuario, $id_crew) {
    global $pdo;
    
    // Buscar carrito existente
    $stmt = $pdo->prepare("SELECT id_carrito FROM carritos WHERE id_usuario = ? AND id_crew = ?");
    $stmt->execute([$id_usuario, $id_crew]);
    $carrito = $stmt->fetch();
    
    if (!$carrito) {
        // Crear nuevo carrito
        $stmt = $pdo->prepare("INSERT INTO carritos (id_usuario, id_crew) VALUES (?, ?)");
        $stmt->execute([$id_usuario, $id_crew]);
        return $pdo->lastInsertId();
    }
    
    return $carrito['id_carrito'];
}

// Función para obtener items del carrito (sin cambios)
function getCartItems($id_carrito) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT ci.*, p.Nombre as producto_nombre, p.Descripcion, p.fotoProducto, 
               p.cantidad as stock, c.Nombre as crew_nombre
        FROM carrito_items ci
        JOIN producto p ON ci.id_producto = p.idProducto
        JOIN crews c ON p.idCrew = c.idCrew
        WHERE ci.id_carrito = ?
    ");
    $stmt->execute([$id_carrito]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Función corregida para agregar al carrito
function addToCartDB($id_carrito, $id_producto, $precio) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Verificar stock disponible del producto
        $stmt = $pdo->prepare("SELECT cantidad FROM producto WHERE idProducto = ?");
        $stmt->execute([$id_producto]);
        $producto = $stmt->fetch();
        
        if (!$producto || $producto['cantidad'] <= 0) {
            $pdo->rollBack();
            return false; // No hay stock disponible
        }
        
        // Verificar si el producto ya está en el carrito
        $stmt = $pdo->prepare("SELECT id_item, cantidad FROM carrito_items WHERE id_carrito = ? AND id_producto = ?");
        $stmt->execute([$id_carrito, $id_producto]);
        $item = $stmt->fetch();
        
        if ($item) {
            // Verificar que no exceda el stock disponible
            if ($item['cantidad'] >= $producto['cantidad']) {
                $pdo->rollBack();
                return false; // No se puede agregar más, excede el stock
            }
            
            // Actualizar cantidad en el carrito
            $nueva_cantidad = $item['cantidad'] + 1;
            $stmt = $pdo->prepare("UPDATE carrito_items SET cantidad = ? WHERE id_item = ?");
            $stmt->execute([$nueva_cantidad, $item['id_item']]);
        } else {
            // Agregar nuevo item al carrito
            $stmt = $pdo->prepare("INSERT INTO carrito_items (id_carrito, id_producto, cantidad, precio_unitario) VALUES (?, ?, 1, ?)");
            $stmt->execute([$id_carrito, $id_producto, $precio]);
        }
        
        $pdo->commit();
        return true;
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error al agregar al carrito: " . $e->getMessage());
        return false;
    }
}

// Función corregida para actualizar cantidad de items en el carrito
function updateCartItemQuantity($id_item, $nueva_cantidad) {
    global $pdo;
    
    if ($nueva_cantidad <= 0) {
        return removeCartItem($id_item);
    }
    
    try {
        $pdo->beginTransaction();
        
        // Verificar stock disponible del producto
        $stmt = $pdo->prepare("
            SELECT ci.id_producto, ci.cantidad as cantidad_actual, p.cantidad as stock 
            FROM carrito_items ci
            JOIN producto p ON ci.id_producto = p.idProducto
            WHERE ci.id_item = ?
        ");
        $stmt->execute([$id_item]);
        $item = $stmt->fetch();
        
        if (!$item) {
            $pdo->rollBack();
            return false;
        }
        
        // Verificar que la nueva cantidad no exceda el stock disponible
        if ($nueva_cantidad > $item['stock']) {
            $pdo->rollBack();
            return false; // Cantidad solicitada excede el stock disponible
        }
        
        // Actualizar cantidad en carrito (sin tocar el stock del producto)
        $stmt = $pdo->prepare("UPDATE carrito_items SET cantidad = ? WHERE id_item = ?");
        $stmt->execute([$nueva_cantidad, $id_item]);
        
        $pdo->commit();
        return true;
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error al actualizar cantidad en carrito: " . $e->getMessage());
        return false;
    }
}

// Función corregida para remover item del carrito
function removeCartItem($id_item) {
    global $pdo;
    
    try {
        // Simplemente eliminar el item del carrito sin afectar el stock
        $stmt = $pdo->prepare("DELETE FROM carrito_items WHERE id_item = ?");
        $result = $stmt->execute([$id_item]);
        
        return $result;
    } catch (PDOException $e) {
        error_log("Error al eliminar item del carrito: " . $e->getMessage());
        return false;
    }
}

// Función corregida para vaciar carrito
function emptyCart($id_carrito) {
    global $pdo;
    
    try {
        // Simplemente eliminar todos los items del carrito sin afectar el stock
        $stmt = $pdo->prepare("DELETE FROM carrito_items WHERE id_carrito = ?");
        $result = $stmt->execute([$id_carrito]);
        
        return $result;
    } catch (PDOException $e) {
        error_log("Error al vaciar carrito: " . $e->getMessage());
        return false;
    }
}

// Función para obtener total del carrito (sin cambios)
function getCartTotal($id_carrito) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_items WHERE id_carrito = ?");
    $stmt->execute([$id_carrito]);
    $result = $stmt->fetch();
    
    return $result['total'] ?? 0;
}

// Función para obtener cantidad total de items en el carrito (sin cambios)
function getCartCount($id_carrito) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT SUM(cantidad) as total_items FROM carrito_items WHERE id_carrito = ?");
    $stmt->execute([$id_carrito]);
    $result = $stmt->fetch();
    
    return $result['total_items'] ?? 0;
}

// Nueva función para validar stock antes del checkout
function validateCartStock($id_carrito) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT ci.cantidad as cantidad_carrito, p.cantidad as stock_disponible, p.Nombre
        FROM carrito_items ci
        JOIN producto p ON ci.id_producto = p.idProducto
        WHERE ci.id_carrito = ?
    ");
    $stmt->execute([$id_carrito]);
    $items = $stmt->fetchAll();
    
    $stockErrors = [];
    foreach ($items as $item) {
        if ($item['cantidad_carrito'] > $item['stock_disponible']) {
            $stockErrors[] = [
                'producto' => $item['Nombre'],
                'solicitado' => $item['cantidad_carrito'],
                'disponible' => $item['stock_disponible']
            ];
        }
    }
    
    return $stockErrors;
}

// Función para procesar el pago y actualizar stock
function processPaymentAndUpdateStock($id_carrito) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Validar stock nuevamente antes del pago
        $stockErrors = validateCartStock($id_carrito);
        if (!empty($stockErrors)) {
            $pdo->rollBack();
            return ['success' => false, 'errors' => $stockErrors];
        }
        
        // Obtener items del carrito
        $stmt = $pdo->prepare("
            SELECT ci.id_producto, ci.cantidad
            FROM carrito_items ci
            WHERE ci.id_carrito = ?
        ");
        $stmt->execute([$id_carrito]);
        $items = $stmt->fetchAll();
        
        // Actualizar stock de cada producto
        foreach ($items as $item) {
            $stmt = $pdo->prepare("UPDATE producto SET cantidad = cantidad - ? WHERE idProducto = ?");
            $stmt->execute([$item['cantidad'], $item['id_producto']]);
        }
        
        // Vaciar el carrito después de procesar el pago
        $stmt = $pdo->prepare("DELETE FROM carrito_items WHERE id_carrito = ?");
        $stmt->execute([$id_carrito]);
        
        $pdo->commit();
        return ['success' => true];
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Error al procesar pago: " . $e->getMessage());
        return ['success' => false, 'error' => 'Error en la base de datos'];
    }
}

// Mantener las demás funciones existentes sin cambios...
function getProductos($filtros = []) {
    global $pdo;
    
    $sql = "SELECT p.*, c.Nombre as crewNombre, t.Nombre as tipoNombre 
            FROM producto p
            JOIN crews c ON p.idCrew = c.idCrew
            JOIN tipoprod t ON p.idTipo = t.idTipo
            WHERE 1=1";
    
    $params = [];
    
    // Filtro por crew
    if (!empty($filtros['idCrew'])) {
        $sql .= " AND p.idCrew = ?";
        $params[] = $filtros['idCrew'];
    }
    
    // Filtros de precio
    if (!empty($filtros['precio_min'])) {
        $sql .= " AND p.precio >= ?";
        $params[] = $filtros['precio_min'];
    }
    
    if (!empty($filtros['precio_max'])) {
        $sql .= " AND p.precio <= ?";
        $params[] = $filtros['precio_max'];
    }
    
    // Filtro por categoría
    if (!empty($filtros['categoria'])) {
        $sql .= " AND p.idTipo = ?";
        $params[] = $filtros['categoria'];
    }
    
    // Filtro por búsqueda
    if (!empty($filtros['busqueda'])) {
        $sql .= " AND (p.Nombre LIKE ? OR p.Descripcion LIKE ?)";
        $params[] = '%'.$filtros['busqueda'].'%';
        $params[] = '%'.$filtros['busqueda'].'%';
    }
    
    // Ordenación
    if (!empty($filtros['orden'])) {
        switch ($filtros['orden']) {
            case 'precio_asc':
                $sql .= " ORDER BY p.precio ASC";
                break;
            case 'precio_desc':
                $sql .= " ORDER BY p.precio DESC";
                break;
            case 'novedades':
                $sql .= " ORDER BY p.fecSubida DESC";
                break;
            case 'populares':
                $sql .= " ORDER BY (SELECT COUNT(*) FROM pedidos WHERE idProducto = p.idProducto) DESC";
                break;
        }
    } else {
        $sql .= " ORDER BY p.fecSubida DESC";
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCategorias() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM tipoprod");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCrewById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM crews WHERE idCrew = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getProductById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT p.*, c.Nombre as crewNombre 
                          FROM producto p
                          JOIN crews c ON p.idCrew = c.idCrew
                          WHERE p.idProducto = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getCartIdForUser($id_usuario, $id_crew) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT id_carrito FROM carritos WHERE id_usuario = ? AND id_crew = ?");
    $stmt->execute([$id_usuario, $id_crew]);
    $result = $stmt->fetch();
    
    return $result ? $result['id_carrito'] : null;
}


?>