<?php
require_once 'config.php';
require_once 'functions.php';
require_once '../php/funciones.php';
session_start();

if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['login_redirect'] = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'tienda.php';
    header('Location: ../inicio_sesion.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];
    $idCrew = $_POST['id_crew'] ?? null;
    $quantity = $_POST['quantity'] ?? 1;
    $operation = $_POST['operation'] ?? null; // 'add' o 'subtract' para incremento/decremento
    
    if (!$idCrew) {
        $_SESSION['cart_error'] = "No se pudo identificar la tienda";
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'tienda.php'));
        exit;
    }
    
    // Obtener información del producto
    $producto = getProductById($productId);
    if (!$producto) {
        $_SESSION['cart_error'] = "Producto no encontrado";
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'tienda.php'));
        exit;
    }
    
    // Agregar al carrito
    $id_carrito = getOrCreateCart($_SESSION['usuario_id'], $idCrew);
    
    try {
        // Verificar si el producto ya está en el carrito
        $stmt = $pdo->prepare("SELECT id_item, cantidad FROM carrito_items WHERE id_carrito = ? AND id_producto = ? FOR UPDATE");
        $stmt->execute([$id_carrito, $productId]);
        $item = $stmt->fetch();
        
        if ($item) {
            // Calcular nueva cantidad
            $nueva_cantidad = $item['cantidad'];
            
            if ($operation === 'add') {
                $nueva_cantidad += $quantity;
            } elseif ($operation === 'subtract') {
                $nueva_cantidad -= $quantity;
                if ($nueva_cantidad < 1) $nueva_cantidad = 1;
            } else {
                $nueva_cantidad = $quantity;
            }
            
            // Verificar stock
            if ($producto['cantidad'] < $nueva_cantidad) {
                $_SESSION['cart_error'] = "No hay suficiente stock disponible";
                header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'tienda.php'));
                exit;
            }
            
            // Actualizar cantidad
            $stmt = $pdo->prepare("UPDATE carrito_items SET cantidad = ? WHERE id_item = ?");
            $stmt->execute([$nueva_cantidad, $item['id_item']]);
            
            $_SESSION['cart_success'] = "Cantidad actualizada";
        } else {
            // Verificar stock
            if ($producto['cantidad'] < $quantity) {
                $_SESSION['cart_error'] = "No hay suficiente stock disponible";
                header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'tienda.php'));
                exit;
            }
            
            // Agregar nuevo item
            $stmt = $pdo->prepare("INSERT INTO carrito_items (id_carrito, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
            $stmt->execute([$id_carrito, $productId, $quantity, $producto['precio']]);
            
            $_SESSION['cart_success'] = "Producto agregado al carrito";
        }
    } catch (PDOException $e) {
        $_SESSION['cart_error'] = "Error al actualizar el carrito";
        error_log("Error en add_to_cart.php: " . $e->getMessage());
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'tienda.php'));
exit;