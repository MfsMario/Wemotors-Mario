<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
  header('Location: ../crews.php');
  exit;
}

$idProducto = $_GET['id'] ?? null;
if (!$idProducto) {
    header('Location: tienda.php');
    exit;
}

// Obtener información del producto
$producto = $pdo->prepare("
    SELECT p.*, c.Nombre as crew_nombre, t.Nombre as categoria_nombre 
    FROM producto p
    JOIN crews c ON p.idCrew = c.idCrew
    JOIN tipoprod t ON p.idTipo = t.idTipo
    WHERE p.idProducto = ?
");
$producto->execute([$idProducto]);
$producto = $producto->fetch();

if (!$producto) {
    header('Location: tienda.php');
    exit;
}

// Obtener productos relacionados (misma categoría)
$relacionados = $pdo->prepare("
    SELECT p.* FROM producto p
    WHERE p.idTipo = ? AND p.idProducto != ? AND p.idCrew = ?
    ORDER BY RAND() LIMIT 4
");
$relacionados->execute([$producto['idTipo'], $idProducto, $producto['idCrew']]);
$relacionados = $relacionados->fetchAll();

// Verificar si el usuario es admin de la crew
$isAdmin = false;
if (isset($_SESSION['usuario_id'])) {
    $stmt = $pdo->prepare("SELECT idCrew FROM crews WHERE idAdmin = ? AND idCrew = ?");
    $stmt->execute([$_SESSION['usuario_id'], $producto['idCrew']]);
    $isAdmin = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($producto['Nombre']) ?> - Wemotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/producto.css">
     <link rel="stylesheet" href="../inicio.css">
    <link rel="stylesheet" href="../solicitudes.css">
    <link rel="stylesheet" href="../css_inicio.css">
    <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">
    <style>
        .product-gallery img {
            cursor: pointer;
            transition: transform 0.3s;
        }
        .product-gallery img:hover {
            transform: scale(1.05);
        }
        .main-image {
            max-height: 500px;
            object-fit: contain;
        }
        .related-product {
            transition: all 0.3s;
        }
        .related-product:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="../inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  active" href="../crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../eventos.php">Eventos</a>
                </li>
            </ul>
            <a href="cart.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light cart-btn-nav me-2">
                <i class="bi bi-cart"></i>
                <span class="badge bg-danger ms-1" id="cartCount">0</span>
            </a>
             <div class="d-flex">
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light me-2">Volver a la tienda</a>
            </div>
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $usuario; ?>
                    
                    <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                           style="display: <?php echo (isset($_SESSION['usuario_id']) && tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'])) ? 'block' : 'none'; ?>;">
                        <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo isset($_SESSION['usuario_id']) ? generarHtmlSolicitudes($pdo) : ''; ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
    <div class="container my-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="tienda.php?idCrew=<?= $producto['idCrew'] ?>">Tienda</a></li>
                <li class="breadcrumb-item"><a href="tienda.php?idCrew=<?= $producto['idCrew'] ?>&categoria=<?= $producto['idTipo'] ?>"><?= htmlspecialchars($producto['categoria_nombre']) ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($producto['Nombre']) ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Galería de imágenes -->
            <div class="col-md-6">
                <div class="mb-4">
                    <?php if (!empty($producto['fotoProducto'])): ?>
                        <img src="data:image/jpeg;base64,<?= base64_encode($producto['fotoProducto']) ?>" 
                             class="img-fluid main-image rounded shadow" alt="<?= htmlspecialchars($producto['Nombre']) ?>">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/600x600?text=Producto" 
                             class="img-fluid main-image rounded shadow" alt="Producto">
                    <?php endif; ?>
                </div>
                
                <!-- Miniaturas (puedes expandir esto para múltiples imágenes) -->
                <div class="row product-gallery">
                    <!--<div class="col-3">
                        <?php //if (!empty($producto['fotoProducto'])): ?>
                            <img src="data:image/jpeg;base64,<?= base64_encode($producto['fotoProducto']) ?>" 
                                 class="img-fluid rounded shadow" alt="Miniatura 1">
                        <?php //else: ?>
                            <img src="https://via.placeholder.com/150x150?text=Thumb" 
                                 class="img-fluid rounded shadow" alt="Miniatura">
                        <?php //endif; ?>
                    </div>-->
                    <!-- Puedes agregar más miniaturas aquí -->
                </div>
            </div>

            <!-- Información del producto -->
            <div class="col-md-6">
                <h1 class="mb-3"><?= htmlspecialchars($producto['Nombre']) ?></h1>
                
                <div class="d-flex align-items-center mb-3">
                    <span class="badge bg-primary me-2"><?= htmlspecialchars($producto['categoria_nombre']) ?></span>
                    <span class="text-muted">Vendido por: <?= htmlspecialchars($producto['crew_nombre']) ?></span>
                </div>
                
                <div class="mb-4">
                    <h3 class="text-success">$<?= number_format($producto['precio'], 2) ?></h3>
                    <p class="<?= $producto['cantidad'] > 0 ? 'text-success' : 'text-danger' ?>">
                        <?= $producto['cantidad'] > 0 ? 'Disponible' : 'Agotado' ?>
                        <?php if ($producto['cantidad'] > 0): ?>
                            (<?= $producto['cantidad'] ?> en stock)
                        <?php endif; ?>
                    </p>
                </div>
                
                <div class="mb-4">
                    <h4>Descripción</h4>
                    <p><?= nl2br(htmlspecialchars($producto['Descripcion'])) ?></p>
                </div>
                
                <?php if ($producto['cantidad'] > 0): ?>
                    <form method="POST" action="add_to_cart.php" class="mb-4">
                        <input type="hidden" name="product_id" value="<?= $producto['idProducto'] ?>">
                        <input type="hidden" name="id_crew" value="<?= $producto['idCrew'] ?>">
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="quantity" class="form-label">Cantidad</label>
                                <select class="form-select" id="quantity" name="quantity">
                                    <?php for ($i = 1; $i <= min($producto['cantidad'], 10); $i++): ?>
                                        <option value="<?= $i ?>"><?= $i ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-cart me-2"></i>Añadir al carrito
                        </button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-secondary btn-lg" disabled>
                        Producto agotado
                    </button>
                <?php endif; ?>
                
                <?php if ($isAdmin): ?>
                    <div class="mt-4 pt-3 border-top">
                        <a href="editar_producto.php?id=<?= $producto['idProducto'] ?>&idCrew=<?= $producto['idCrew'] ?>" 
                           class="btn btn-warning me-2">
                            <i class="bi bi-pencil"></i> Editar producto
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Productos relacionados -->
        <?php if (!empty($relacionados)): ?>
            <div class="mt-5 pt-4 border-top">
                <h3 class="mb-4">Productos relacionados</h3>
                <div class="row">
                    <?php foreach ($relacionados as $rel): ?>
                        <div class="col-md-3 mb-4">
                            <div class="card h-100 related-product">
                                <a href="producto.php?idCrew=<?=$idCrew?>&id=<?= $rel['idProducto'] ?>">
                                    <?php if (!empty($rel['fotoProducto'])): ?>
                                        <img src="data:image/jpeg;base64,<?= base64_encode($rel['fotoProducto']) ?>" 
                                             class="card-img-top" alt="<?= htmlspecialchars($rel['Nombre']) ?>">
                                    <?php else: ?>
                                        <img src="https://via.placeholder.com/300x200?text=Producto" 
                                             class="card-img-top" alt="Producto">
                                    <?php endif; ?>
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="producto.php?id=<?= $rel['idProducto'] ?>&idCrew=<?=$idCrew?>" class="text-decoration-none">
                                            <?= htmlspecialchars($rel['Nombre']) ?>
                                        </a>
                                    </h5>
                                    <p class="card-text text-success">$<?= number_format($rel['precio'], 2) ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer (usar el mismo de tu sitio) -->
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Cambiar imagen principal al hacer clic en miniatura
        document.querySelectorAll('.product-gallery img').forEach(img => {
            img.addEventListener('click', function() {
                const mainImg = document.querySelector('.main-image');
                mainImg.src = this.src;
            });
        });
    document.addEventListener('DOMContentLoaded', function () {
      // Manejar añadir al carrito
      document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function () {
          const productId = this.getAttribute('data-product-id');
          document.getElementById('add_to_cart_product_id').value = productId;
          document.getElementById('addToCartForm').submit();
        });
      });

      // Actualizar contador del carrito
      updateCartCount();

      async function updateCartCount() {
        const idCrew = new URLSearchParams(window.location.search).get('idCrew');
        if (!idCrew) return;

        try {
          const response = await fetch(`get_cart_count.php?id_crew=${idCrew}`);
          if (response.ok) {
            const count = await response.text();
            document.getElementById('cartCount').textContent = count || '0';
          }
        } catch (error) {
          console.error('Error al actualizar contador:', error);
        }
      }
    });
  </script>
    <script src="../javaScript/solicitud.js"></script>
  <?php require_once("../footer.html");?>
</body>
</html>