<?php
// Archivo: ajax_update_cart.php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Usuario no autenticado']);
    exit;
}

// Verificar que sea una petición POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtener datos del POST
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$itemId = (int)($input['itemId'] ?? 0);
$quantity = (int)($input['quantity'] ?? 1);

try {
    switch ($action) {
        case 'update_quantity':
            if ($itemId <= 0 || $quantity < 0) {
                echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
                exit;
            }
            
            if ($quantity === 0) {
                // Eliminar item si cantidad es 0
                $result = removeCartItem($itemId);
                if ($result) {
                    echo json_encode(['success' => true, 'message' => 'Producto eliminado del carrito']);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Error al eliminar el producto']);
                }
            } else {
                // Actualizar cantidad
                $result = updateCartItemQuantity($itemId, $quantity);
                if ($result) {
                    echo json_encode(['success' => true, 'message' => 'Cantidad actualizada']);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Error al actualizar cantidad. Verifica el stock disponible.']);
                }
            }
            break;
            
        case 'remove_item':
            if ($itemId <= 0) {
                echo json_encode(['success' => false, 'error' => 'ID de item inválido']);
                exit;
            }
            
            $result = removeCartItem($itemId);
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Producto eliminado del carrito']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error al eliminar el producto']);
            }
            break;
            
        case 'get_cart_totals':
            $idCrew = (int)($input['idCrew'] ?? 0);
            if ($idCrew) {
                $id_carrito = getCartIdForUser($_SESSION['usuario_id'], $idCrew);
                $cartItems = getCartItems($id_carrito);
                $total = getCartTotal($id_carrito);
                $itemCount = array_sum(array_column($cartItems, 'cantidad'));
                
                $response = [
                    'success' => true,
                    'total' => number_format($total, 2, '.', ''), // Sin comas para parseFloat
                    'itemCount' => $itemCount,
                    'items' => $cartItems
                ];
                
                echo json_encode($response); // Esta línea faltaba
            } else {
                echo json_encode(['success' => false, 'error' => 'ID de crew inválido']);
            }
            break;
        case 'empty_cart':
            $idCrew = (int)($input['idCrew'] ?? 0);
            if ($idCrew <= 0) {
                echo json_encode(['success' => false, 'error' => 'ID de crew inválido']);
                exit;
            }
            
            $id_carrito = getOrCreateCart($_SESSION['usuario_id'], $idCrew);
            $result = emptyCart($id_carrito);
            
            if ($result) {
                echo json_encode(['success' => true, 'message' => 'Carrito vaciado correctamente']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error al vaciar el carrito']);
            }
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Acción no válida']);
            break;
    }
} catch (Exception $e) {
    error_log("Error en AJAX cart update: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Error interno del servidor']);
}
?>