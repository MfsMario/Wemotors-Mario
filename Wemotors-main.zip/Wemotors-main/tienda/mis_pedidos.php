<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
  header('Location: ../crews.php');
  exit;
}


if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../inicio_sesion.php');
    exit;
}

$pedidos = getUserOrders($_SESSION['usuario_id']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - Wemotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

</head>
<body>
  
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" href="../inicio.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../crews.php">Crew</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../eventos.php">Eventos</a>
          </li>
          <li class="nav-item position-relative">
            <input type="text" class="form-control" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
            <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none"
              style="z-index: 1000;"></div>
          </li>
        </ul>
        <a href="cart.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light cart-btn-nav">
            <i class="bi bi-cart"></i>
        </a>
        <div class="d-flex">
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light me-2">Volver a la tienda</a>
        </div>
        <div class="dropdown">
          <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton"
            data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo $usuario; ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
            <?php echo $inicio; ?>
            <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>


    <div class="container my-5">
        <h2 class="mb-4">Mis Pedidos</h2>
        
        <?php if (empty($pedidos)): ?>
            <div class="alert alert-info">
                No has realizado ningún pedido todavía.
                <a href="tienda.php" class="alert-link">Ir a la tienda</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>N° Pedido</th>
                            <th>ID Pago</th>
                            <th>Descripción</th>
                            <th>Total</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos as $pedido): ?>
                            <tr>
                                <td><?= $pedido['idPedido'] ?></td>
                                <td><?= htmlspecialchars($pedido['idPago']) ?></td>
                                <td><?= htmlspecialchars($pedido['Descripcion']) ?></td>
                                <td>$<?= number_format($pedido['precioPago'], 2) ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($pedido['fecha'] ?? 'now')) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    
</body>
</html>