<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar si el usuario es admin de esta crew
$isAdmin = false;
if (isset($_SESSION['usuario_id'])) {
  $stmt = $pdo->prepare("SELECT idCrew FROM crews WHERE idAdmin = ? AND idCrew = ?");
  $stmt->execute([$_SESSION['usuario_id'], $idCrew]);
  $isAdmin = $stmt->fetch();
}

// Procesar filtros
$filtros = ['idCrew' => $idCrew];
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $filtros = array_merge($filtros, [
    'precio_min' => $_GET['precio_min'] ?? null,
    'precio_max' => $_GET['precio_max'] ?? null,
    'categoria' => $_GET['categoria'] ?? null,
    'busqueda' => $_GET['busqueda'] ?? null,
    'orden' => $_GET['orden'] ?? null
  ]);
}

// Obtener productos y categorías
$productos = getProductos($filtros);
$categorias = getCategorias();

// Contar productos por categoría
$productosPorCategoria = [];
foreach ($categorias as $categoria) {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM producto WHERE idTipo = ? AND idCrew = ?");
  $stmt->execute([$categoria['idTipo'], $idCrew]);
  $productosPorCategoria[$categoria['idTipo']] = $stmt->fetchColumn();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
  if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['login_redirect'] = "tienda.php?idCrew=$idCrew";
    header('Location: ../inicio_sesion.php');
    exit;
  }

  $productId = $_POST['product_id'];
  $product = getProductById($productId);

  if ($product && $product['cantidad'] > 0) {
    $id_carrito = getOrCreateCart($_SESSION['usuario_id'], $idCrew);
    $success = addToCartDB($id_carrito, $productId, $product['precio']);

    if ($success) {
      $_SESSION['cart_message'] = "Producto agregado al carrito";
    } else {
      $_SESSION['cart_error'] = "Error al agregar al carrito";
    }
  }

  header("Location: tienda.php?idCrew=$idCrew");
  exit;
}




?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tienda de <?= htmlspecialchars($crew['Nombre']) ?> - Wemotors</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="assets/css/tienda.css">
  <link rel="stylesheet" href="../inicio.css">
  <link rel="stylesheet" href="../solicitudes.css">
  <link rel="stylesheet" href="../css_inicio.css">
  <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">
</head>

<body>
  <form id="addToCartForm" method="POST" action="tienda.php?idCrew=<?= $idCrew ?>">
    <input type="hidden" name="add_to_cart" value="1">
    <input type="hidden" name="product_id" id="add_to_cart_product_id">
  </form>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link " href="../inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="../crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../eventos.php">Eventos</a>
                </li>
            </ul>
            <a href="cart.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light cart-btn-nav me-2">
                <i class="bi bi-cart"></i>
                <span class="badge bg-danger ms-1" id="cartCount">0</span>
            </a>
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $usuario; ?>
                    
                    <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                           style="display: <?php echo (isset($_SESSION['usuario_id']) && tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'])) ? 'block' : 'none'; ?>;">
                        <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo isset($_SESSION['usuario_id']) ? generarHtmlSolicitudes($pdo) : ''; ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

  <div class="main-content">
    <div class="container my-5">
      <div class="row">
        <div class="col-lg-3">
          <form id="filterForm" method="GET" action="tienda.php">
            <input type="hidden" name="idCrew" value="<?= $idCrew ?>">
            <div class="search-box">
              <h5 class="mb-3">Buscar productos</h5>
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Buscar..." name="busqueda"
                  value="<?= htmlspecialchars($filtros['busqueda'] ?? '') ?>">
                <button class="btn btn-dark" type="submit"><i class="fas fa-search"></i></button>
              </div>
            </div>

            <div class="price-filter">
              <h5 class="mb-3">Filtrar por precio</h5>
              <input type="range" class="form-range price-range" min="0" max="2000" step="10" id="priceRange"
                name="price_range" value="<?= $filtros['precio_max'] ?? 1000 ?>">
              <div class="price-values">
                <span id="minPrice">$0</span>
                <span id="maxPrice">$<?= $filtros['precio_max'] ?? 1000 ?></span>
              </div>
              <input type="hidden" name="precio_min" id="precioMinInput" value="<?= $filtros['precio_min'] ?? 0 ?>">
              <input type="hidden" name="precio_max" id="precioMaxInput" value="<?= $filtros['precio_max'] ?? 1000 ?>">
              <button class="btn btn-dark w-100 mt-3" type="submit" id="applyFilter">Aplicar filtro</button>
              <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-secondary w-100 mt-2">Eliminar filtros</a>

            </div>

            <div class="mb-4">
              <h5 class="mb-3">Categorías</h5>
              <ul class="list-group">
                <?php foreach ($categorias as $categoria): ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="categoria" id="cat<?= $categoria['idTipo'] ?>"
                        value="<?= $categoria['idTipo'] ?>" <?= ($filtros['categoria'] ?? '') == $categoria['idTipo'] ? 'checked' : '' ?>>
                      <label class="form-check-label" for="cat<?= $categoria['idTipo'] ?>">
                        <?= htmlspecialchars($categoria['Nombre']) ?>
                      </label>
                    </div>
                    <span
                      class="badge bg-dark rounded-pill"><?= $productosPorCategoria[$categoria['idTipo']] ?? 0 ?></span>
                  </li>
                <?php endforeach; ?>
              </ul>
            </div>
          </form>
        </div>

        <div class="col-lg-9">
          <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Productos de <?= htmlspecialchars($crew['Nombre']) ?></h2>
            <div>
              <?php if ($isAdmin): ?>
                <a href="subir_producto.php?idCrew=<?= $idCrew ?>" class="btn btn-primary me-2">
                  <i class="fas fa-plus"></i> Subir Producto
                </a>
                <a href="admin_productos.php?idCrew=<?= $idCrew ?>" class="btn btn-warning">
                  <i class="fas fa-cog"></i> Administrar
                </a>
              <?php endif; ?>
              <div class="dropdown d-inline-block ms-2">
                <button class="btn btn-outline-dark dropdown-toggle" type="button" id="sortDropdown"
                  data-bs-toggle="dropdown">
                  Ordenar por
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item"
                      href="?<?= http_build_query(array_merge($filtros, ['orden' => 'precio_asc'])) ?>">Menor precio</a>
                  </li>
                  <li><a class="dropdown-item"
                      href="?<?= http_build_query(array_merge($filtros, ['orden' => 'precio_desc'])) ?>">Mayor
                      precio</a></li>
                  <li><a class="dropdown-item"
                      href="?<?= http_build_query(array_merge($filtros, ['orden' => 'populares'])) ?>">Más populares</a>
                  </li>
                  <li><a class="dropdown-item"
                      href="?<?= http_build_query(array_merge($filtros, ['orden' => 'novedades'])) ?>">Novedades</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div class="row" id="productList">
            <?php if (empty($productos)): ?>
              <div class="col-12 text-center py-5">
                <i class="fas fa-search fa-4x mb-3 text-muted"></i>
                <h4>No se encontraron productos</h4>
                <p class="text-muted">Intenta con otros filtros de búsqueda</p>
              </div>
            <?php else: ?>
              <?php foreach ($productos as $producto): ?>
                <div class="col-md-4 col-sm-6 product-card" data-price="<?= $producto['precio'] ?>">
                  <div class="card">
                    <?php if (!empty($producto['fotoProducto'])): ?>
                      <img src="data:image/jpeg;base64,<?= base64_encode($producto['fotoProducto']) ?>"
                        class="card-img-top product-img" alt="<?= htmlspecialchars($producto['Nombre']) ?>">
                    <?php else: ?>
                      <img src="https://via.placeholder.com/300x200?text=Producto" class="card-img-top product-img"
                        alt="Producto">
                    <?php endif; ?>
                    <div class="card-body">
                      <a href="producto.php?id=<?= $producto['idProducto'] ?>&idCrew=<?=$_GET['idCrew']?>" style="color: black; text-decoration: none;" >
                      <h5 class="card-title"><?= htmlspecialchars($producto['Nombre']) ?></h5>
                      <p class="card-text"><?= htmlspecialchars($producto['Descripcion']) ?></p>
                      
                      <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold">$<?= number_format($producto['precio'], 2) ?></span>
                        <?php if ($producto['cantidad'] > 0): ?>
                          <button class="btn btn-dark btn-sm add-to-cart" data-product-id="<?= $producto['idProducto'] ?>"
                            data-product-name="<?= htmlspecialchars($producto['Nombre']) ?>"
                            data-product-price="<?= $producto['precio'] ?>"
                            data-product-quantity="<?= $producto['cantidad'] ?>">
                            <i class="fas fa-shopping-cart"></i> Comprar
                          </button>
                        <?php else: ?>
                          <span class="badge bg-danger">Agotado</span>
                        <?php endif; ?>
                      </div>
                      </a>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>

          <!--<nav aria-label="Page navigation" class="mt-4">
            <ul class="pagination justify-content-center">
              <li class="page-item disabled">
                <a class="page-link bg-dark text-white" href="#" tabindex="-1">Anterior</a>
              </li>
              <li class="page-item active"><a class="page-link bg-dark text-white" href="#">1</a></li>
              <li class="page-item"><a class="page-link text-dark" href="#">2</a></li>
              <li class="page-item"><a class="page-link text-dark" href="#">3</a></li>
              <li class="page-item">
                <a class="page-link text-dark" href="#">Siguiente</a>
              </li>
            </ul>
          </nav>-->
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/tienda.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Manejar añadir al carrito
      document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function () {
          const productId = this.getAttribute('data-product-id');
          document.getElementById('add_to_cart_product_id').value = productId;
          document.getElementById('addToCartForm').submit();
        });
      });

      // Actualizar contador del carrito
      updateCartCount();

      async function updateCartCount() {
        const idCrew = new URLSearchParams(window.location.search).get('idCrew');
        if (!idCrew) return;

        try {
          const response = await fetch(`get_cart_count.php?id_crew=${idCrew}`);
          if (response.ok) {
            const count = await response.text();
            document.getElementById('cartCount').textContent = count || '0';
          }
        } catch (error) {
          console.error('Error al actualizar contador:', error);
        }
      }
    });
  </script>
  <script src="../javaScript/solicitud.js"></script>
  <?php require_once("../footer.html");?>
</body>

</html>