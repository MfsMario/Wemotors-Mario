<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../inicio_sesion.php');
    exit;
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
    header('Location: ../crews.php');
    exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
    header('Location: ../crews.php');
    exit;
}

// Obtener o crear carrito
$id_carrito = getOrCreateCart($_SESSION['usuario_id'], $idCrew);

// Procesar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_quantity'])) {
        if (isset($_POST['quantity']) && is_array($_POST['quantity'])) {
            $allUpdated = true;
            foreach ($_POST['quantity'] as $id_item => $cantidad) {
                $id_item = (int)$id_item;
                $cantidad = (int)$cantidad;
                if ($cantidad > 0) {
                    if (!updateCartItemQuantity($id_item, $cantidad)) {
                        $allUpdated = false;
                        $_SESSION['cart_error'] = "Error al actualizar algunos productos. Verifica el stock disponible.";
                    }
                } else {
                    removeCartItem($id_item);
                }
            }
            
            if ($allUpdated) {
                $_SESSION['cart_success'] = "Carrito actualizado correctamente";
            }
            
            // Actualizar la sesión de checkout si existe
            if (isset($_SESSION['cart_checkout'])) {
                $_SESSION['cart_checkout']['items'] = getCartItems($id_carrito);
                $_SESSION['cart_checkout']['total'] = getCartTotal($id_carrito);
                $_SESSION['cart_checkout']['timestamp'] = time();
            }
            
            header("Location: cart.php?idCrew=" . $idCrew);
            exit;
        }
    }
    elseif (isset($_POST['remove_item'])) {
        $id_item = (int)$_POST['item_id'];
        if (removeCartItem($id_item)) {
            $_SESSION['cart_success'] = "Producto eliminado del carrito";
        } else {
            $_SESSION['cart_error'] = "Error al eliminar el producto";
        }
        header("Location: cart.php?idCrew=" . $idCrew);
        exit;
    } 
    elseif (isset($_POST['empty_cart'])) {
        if (emptyCart($id_carrito)) {
            $_SESSION['cart_success'] = "Carrito vaciado correctamente";
        } else {
            $_SESSION['cart_error'] = "Error al vaciar el carrito";
        }
        header("Location: cart.php?idCrew=" . $idCrew);
        exit;
    }
    elseif (isset($_POST['proceed_payment'])) {
        // Obtener items frescos del carrito antes de proceder al pago
        $cartItems = getCartItems($id_carrito);
        $total = getCartTotal($id_carrito);
        
        if (empty($cartItems)) {
            $error = "El carrito está vacío. Agrega productos antes de proceder al pago.";
        } else {
            // Validar que todos los items tengan stock suficiente
            $stockValid = true;
            foreach ($cartItems as $item) {
                if ($item['cantidad'] > $item['stock']) {
                    $stockValid = false;
                    $error = "No hay suficiente stock para " . $item['producto_nombre'];
                    break;
                }
            }
            
            if ($stockValid) {
                // Guardar los datos del carrito en sesión para la pasarela de pago
                $_SESSION['cart_checkout'] = [
                    'idCrew' => (int)$idCrew,
                    'items' => $cartItems,
                    'total' => (float)$total,
                    'timestamp' => time()
                ];
                
                header("Location: pasarela/pasarela_pago.php");
                exit;
            }
        }
    }
}

// Obtener items del carrito (después de procesar cualquier actualización)
$cartItems = getCartItems($id_carrito);
$subtotal = getCartTotal($id_carrito);
$total = $subtotal;

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito - <?= htmlspecialchars($crew['Nombre']) ?> - Wemotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/cart.css">
    <link rel="stylesheet" href="../inicio.css">
      <link rel="stylesheet" href="../solicitudes.css">
    <link rel="stylesheet" href="../css_inicio.css">
    <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">
    <style>
        .quantity-control { width: 50px; text-align: center; }
        .cart-item-img { max-width: 80px; max-height: 80px; object-fit: contain; }
        .stock-warning { color: #dc3545; font-size: 0.9rem; }
        .summary-card { 
            border-radius: 10px; 
            overflow: hidden;
            height: 100%;
        }
        .summary-container {
            position: sticky;
            top: 20px;
        }
        .table-borderless td { border: none; padding: 0.3rem 0; }
        .cart-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .cart-items-container {
            flex: 1;
            min-width: 300px;
        }
        .summary-section {
            flex: 0 0 350px;
        }
        @media (max-width: 992px) {
            .cart-container {
                flex-direction: column;
            }
            .summary-section {
                flex: 1;
                width: 100%;
            }
        }
        .quantity-btn.disabled {
            pointer-events: none;
            opacity: 0.5;
        }
    </style>
</head>
<body  class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link " href="../inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="../crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../eventos.php">Eventos</a>
                </li>
            </ul>
            <a href="cart.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light cart-btn-nav me-2">
                <i class="bi bi-cart"></i>
                <span class="badge bg-danger ms-1" id="cartCount">0</span>
            </a>
            <div class="d-flex">
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light me-2">Volver a la tienda</a>
            </div>
            <div class="dropdown">
                <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <?php echo $usuario; ?>
                    
                    <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                           style="display: <?php echo (isset($_SESSION['usuario_id']) && tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'])) ? 'block' : 'none'; ?>;">
                        <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo isset($_SESSION['usuario_id']) ? generarHtmlSolicitudes($pdo) : ''; ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

    <div class="container my-5">
        <?php if (isset($_SESSION['cart_success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['cart_success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['cart_success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['cart_error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= $_SESSION['cart_error'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['cart_error']); ?>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Carrito de <?= htmlspecialchars($crew['Nombre']) ?></h2>
            <small class="text-muted">
                <?= count($cartItems) ?> producto<?= count($cartItems) !== 1 ? 's' : '' ?> en el carrito
            </small>
        </div>
        
        <?php if (empty($cartItems)): ?>
            <div class="text-center py-5">
                <i class="fas fa-shopping-cart fa-4x mb-3 text-muted"></i>
                <h5>Tu carrito está vacío</h5>
                <p class="text-muted">Agrega productos para continuar</p>
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-dark">Ir a la tienda</a>
            </div>
        <?php else: ?>
            <div class="cart-container">
                <div class="cart-items-container">
                    <form method="POST" action="cart.php?idCrew=<?= $idCrew ?>" id="cartForm">
                        <div class="cart-items">
                            <?php foreach ($cartItems as $index => $item): ?>
                                <div class="row mb-4 border-bottom pb-3 align-items-center" id="item-<?= $item['id_item'] ?>">
                                    <div class="col-md-2">
                                        <?php if (!empty($item['fotoProducto'])): ?>
                                            <img src="data:image/jpeg;base64,<?= base64_encode($item['fotoProducto']) ?>" 
                                                 class="cart-item-img img-fluid rounded" alt="<?= htmlspecialchars($item['producto_nombre']) ?>">
                                        <?php else: ?>
                                            <img src="https://via.placeholder.com/80x80?text=Producto" 
                                                 class="cart-item-img img-fluid rounded" alt="Producto">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <h5 class="mb-1"><?= htmlspecialchars($item['producto_nombre']) ?></h5>
                                        <?php if (!empty($item['Descripcion'])): ?>
                                            <p class="text-muted mb-1 small"><?= htmlspecialchars($item['Descripcion']) ?></p>
                                        <?php endif; ?>
                                        <p class="mb-0 <?= $item['stock'] < $item['cantidad'] ? 'stock-warning' : 'text-success' ?>">
                                            <small>
                                                <i class="fas <?= $item['stock'] < $item['cantidad'] ? 'fa-exclamation-triangle' : 'fa-check-circle' ?>"></i>
                                                <?= $item['stock'] < $item['cantidad'] ? 'Stock insuficiente' : 'Disponible' ?>: <?= $item['stock'] ?>
                                            </small>
                                        </p>
                                        <p class="mb-0">
                                            <small class="text-muted">Precio unitario: €<?= number_format($item['precio_unitario'], 2) ?></small>
                                        </p>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group" style="max-width: 150px;">
                                           <button class="btn btn-outline-secondary quantity-btn minus <?= $item['cantidad'] <= 1 ? 'disabled' : '' ?>" type="button" 
                                                    data-index="<?= $index ?>" data-item-id="<?= $item['id_item'] ?>">-</button>
                                            <input type="number" class="form-control quantity-control text-center" 
                                                name="quantity[<?= $item['id_item'] ?>]" 
                                                id="quantity-<?= $index ?>"
                                                value="<?= $item['cantidad'] ?>" 
                                                min="1" 
                                                max="<?= $item['stock'] ?>"
                                                data-price="<?= $item['precio_unitario'] ?>"
                                                data-item-id="<?= $item['id_item'] ?>">
                                            <button class="btn btn-outline-secondary quantity-btn plus <?= $item['cantidad'] >= $item['stock'] ? 'disabled' : '' ?>" type="button" 
                                                    data-index="<?= $index ?>" data-item-id="<?= $item['id_item'] ?>">+</button>
                                        </div>
                                    </div>
                                    <div class="col-md-3 text-end">
                                        <h5 class="mb-2" id="item-total-<?= $item['id_item'] ?>">
                                            €<?= number_format($item['precio_unitario'] * $item['cantidad'], 2) ?>
                                        </h5>
                                        <form method="POST" action="cart.php?idCrew=<?= $idCrew ?>" class="d-inline">
                                            <input type="hidden" name="item_id" value="<?= $item['id_item'] ?>">
                                            <button class="btn btn-link text-danger p-0" name="remove_item" type="submit"
                                                    onclick="return confirm('¿Eliminar este producto del carrito?')">
                                                <i class="fas fa-trash"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="d-flex justify-content-between mt-4 flex-wrap gap-2">
                            <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-dark">
                                <i class="fas fa-arrow-left me-2"></i>Seguir comprando
                            </a>
                            <div class="d-flex gap-2">
                               <button class="btn btn-outline-danger" name="empty_cart" type="button" id="emptyCartBtn">
                                    <i class="fas fa-trash me-1"></i>Vaciar carrito
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="summary-section">
                    <div class="summary-container">
                        <div class="card summary-card shadow-sm">
                            <div class="card-header bg-dark text-white">
                                <h4 class="mb-0"><i class="fas fa-receipt me-2"></i>Resumen del Pedido</h4>
                            </div>
                            <div class="card-body">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td>
                                                Subtotal 
                                                <small class="text-muted">(<?= array_sum(array_column($cartItems, 'cantidad')) ?> productos)</small>
                                            </td>
                                            <td class="text-end" id="cart-subtotal">€<?= number_format($subtotal, 2) ?></td>
                                        </tr>
                                        <tr class="border-top">
                                            <td><strong>Total</strong></td>
                                            <td class="text-end" id="cart-total"><strong>€<?= number_format($total, 2) ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                                
                                <form method="POST" action="cart.php?idCrew=<?= $idCrew ?>">
                                    <button class="btn btn-dark w-100 py-2" name="proceed_payment" type="submit">
                                        <i class="fas fa-credit-card me-2"></i>Proceder al pago
                                    </button>
                                </form>
                                
                                <div class="mt-3">
                                    <small class="text-muted">
                                        <i class="fas fa-shield-alt me-1"></i>Pago seguro con Stripe
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
const idCrew = <?= $idCrew ?>;

// Función para mostrar mensajes de feedback
function showMessage(message, type = 'success') {
    // Remover mensajes existentes
    const existingAlerts = document.querySelectorAll('.alert-temp');
    existingAlerts.forEach(alert => alert.remove());
    
    // Crear nuevo mensaje
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-temp`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insertar al inicio del container
    const container = document.querySelector('.container.my-5');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-remover después de 3 segundos
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}

// Función para actualizar el contador del carrito en la navegación
async function updateCartCount() {
    try {
        const response = await fetch(`get_cart_count.php?id_crew=${idCrew}`);
        if (response.ok) {
            const count = await response.text();
            const cartBadge = document.getElementById('cartCount');
            if (cartBadge) {
                cartBadge.textContent = count || '0';
            }
        }
    } catch (error) {
        console.error('Error al actualizar contador:', error);
    }
}

// Función para calcular totales localmente (más rápido)
function calculateCartTotals() {
    let subtotal = 0;
    let totalItems = 0;
    
    // Recorrer todos los inputs de cantidad
    document.querySelectorAll('.quantity-control').forEach(input => {
        const quantity = parseInt(input.value) || 0;
        const price = parseFloat(input.dataset.price) || 0;
        
        subtotal += (quantity * price);
        totalItems += quantity;
    });
    
    return {
        subtotal: subtotal,
        total: subtotal, // Si hay impuestos o descuentos, calcularlos aquí
        itemCount: totalItems
    };
}

// Función para actualizar la interfaz con los totales calculados
function updateCartUI(totals) {
    // Actualizar subtotal y total en el resumen
    const subtotalElement = document.getElementById('cart-subtotal');
    const totalElement = document.getElementById('cart-total');
    
    if (subtotalElement) {
        subtotalElement.textContent = '€' + totals.subtotal.toFixed(2);
    }
    if (totalElement) {
        totalElement.innerHTML = '<strong>€' + totals.total.toFixed(2) + '</strong>';
    }
    
    // Actualizar contador en la navegación
    const cartBadge = document.getElementById('cartCount');
    if (cartBadge) {
        cartBadge.textContent = totals.itemCount.toString();
    }
    
    // Actualizar texto del resumen (número de productos)
    const summaryText = document.querySelector('.container .d-flex small');
    if (summaryText) {
        summaryText.textContent = `${totals.itemCount} producto${totals.itemCount !== 1 ? 's' : ''} en el carrito`;
    }
    
    // Actualizar el texto en el card del resumen
    const cardSubtotalText = document.querySelector('.card-body .table td small');
    if (cardSubtotalText) {
        cardSubtotalText.textContent = `(${totals.itemCount} productos)`;
    }
}

// Función para actualizar cantidad via AJAX
async function updateQuantityAjax(itemId, quantity) {
    try {
        const response = await fetch('ajax_update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update_quantity',
                itemId: itemId,
                quantity: quantity,
                idCrew: idCrew
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showMessage(result.message || 'Cantidad actualizada', 'success');
            return true;
        } else {
            showMessage(result.error || 'Error al actualizar cantidad', 'danger');
            return false;
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error de conexión al actualizar cantidad', 'danger');
        return false;
    }
}

// Función para obtener totales del servidor (como respaldo)
async function updateCartTotalsFromServer() {
    try {
        const response = await fetch('ajax_update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'get_cart_totals',
                idCrew: idCrew
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Usar los datos del servidor para sincronización
            const totals = {
                subtotal: parseFloat(result.total),
                total: parseFloat(result.total),
                itemCount: result.itemCount
            };
            
            updateCartUI(totals);
            
            // Actualizar los totales individuales de cada item si están disponibles
            if (result.items) {
                result.items.forEach(item => {
                    const itemTotalElement = document.getElementById(`item-total-${item.id_item}`);
                    if (itemTotalElement) {
                        itemTotalElement.textContent = '€' + (item.precio_unitario * item.cantidad).toFixed(2);
                    }
                    
                    // Actualizar también el input de cantidad si es diferente
                    const quantityInput = document.querySelector(`input[name="quantity[${item.id_item}]"]`);
                    if (quantityInput && parseInt(quantityInput.value) !== item.cantidad) {
                        quantityInput.value = item.cantidad;
                    }
                });
            }
        }
    } catch (error) {
        console.error('Error al obtener totales:', error);
    }
}

// Función para actualizar el total de un item específico
function updateItemTotal(itemId, quantity, price) {
    const totalElement = document.getElementById('item-total-' + itemId);
    if (totalElement) {
        const total = (quantity * price).toFixed(2);
        totalElement.textContent = '€' + total;
    }
    
    // Actualizar totales generales inmediatamente
    const totals = calculateCartTotals();
    updateCartUI(totals);
}

// Función para actualizar estado de los botones
function updateButtonStates(index, quantity, maxStock) {
    const minusBtn = document.querySelector(`.minus[data-index="${index}"]`);
    const plusBtn = document.querySelector(`.plus[data-index="${index}"]`);
    
    if (minusBtn) minusBtn.classList.toggle('disabled', quantity <= 1);
    if (plusBtn) plusBtn.classList.toggle('disabled', quantity >= maxStock);
}

// Función para eliminar item del DOM si la cantidad es 0
function removeItemFromDOM(itemId) {
    const itemRow = document.getElementById('item-' + itemId);
    if (itemRow) {
        itemRow.remove();
        
        // Actualizar totales después de eliminar
        const totals = calculateCartTotals();
        updateCartUI(totals);
        
        // Verificar si el carrito está vacío
        const remainingItems = document.querySelectorAll('[id^="item-"]');
        if (remainingItems.length === 0) {
            // Recargar la página para mostrar el mensaje de carrito vacío
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        }
    }
}

// Manejadores para los botones de cantidad
document.querySelectorAll('.quantity-btn').forEach(button => {
    button.addEventListener('click', async function() {
        if (this.classList.contains('disabled')) return;
        
        const index = this.getAttribute('data-index');
        const itemId = parseInt(this.getAttribute('data-item-id'));
        const input = document.getElementById('quantity-' + index);
        let value = parseInt(input.value) || 1;
        const max = parseInt(input.getAttribute('max'));
        const min = parseInt(input.getAttribute('min'));
        const price = parseFloat(input.dataset.price);
        
        let newValue = value;
        
        if (this.classList.contains('plus') && value < max) {
            newValue = value + 1;
        } else if (this.classList.contains('minus') && value > min) {
            newValue = value - 1;
        } else {
            return; // No hay cambio válido
        }
        
        // Actualizar la interfaz de usuario inmediatamente (optimista)
        input.value = newValue;
        updateItemTotal(itemId, newValue, price);
        updateButtonStates(index, newValue, max);
        
        // Deshabilitar botones temporalmente
        this.disabled = true;
        
        try {
            // Actualizar en el servidor
            const success = await updateQuantityAjax(itemId, newValue);
            
            if (!success) {
                // Revertir el cambio si falló
                input.value = value;
                updateItemTotal(itemId, value, price);
                updateButtonStates(index, value, max);
            }
        } finally {
            // Rehabilitar botón
            this.disabled = false;
            
            // Sincronizar con el servidor después de un tiempo
            setTimeout(updateCartTotalsFromServer, 1000);
        }
    });
});

// Manejar cambios directos en los inputs de cantidad
document.querySelectorAll('.quantity-control').forEach(input => {
    let originalValue = parseInt(input.value);
    
    input.addEventListener('focus', function() {
        originalValue = parseInt(this.value) || 1;
    });
    
    input.addEventListener('input', function() {
        // Actualización en tiempo real mientras el usuario escribe
        const itemId = parseInt(this.dataset.itemId);
        const price = parseFloat(this.dataset.price);
        const quantity = parseInt(this.value) || 0;
        const max = parseInt(this.getAttribute('max'));
        const index = this.id.split('-')[1];
        
        // Validar y actualizar solo la visualización local
        if (quantity > 0 && quantity <= max) {
            updateItemTotal(itemId, quantity, price);
            updateButtonStates(index, quantity, max);
        }
    });
    
    input.addEventListener('blur', async function() {
        const itemId = parseInt(this.dataset.itemId);
        const price = parseFloat(this.dataset.price);
        const quantity = parseInt(this.value) || 1;
        const max = parseInt(this.getAttribute('max'));
        const min = parseInt(this.getAttribute('min'));
        const index = this.id.split('-')[1];
        
        let finalQuantity = quantity;
        
        // Validar límites
        if (quantity > max) {
            finalQuantity = max;
            this.value = max;
            showMessage(`Cantidad máxima disponible: ${max}`, 'warning');
        } else if (quantity < min) {
            finalQuantity = min;
            this.value = min;
        }
        
        // Solo actualizar si el valor cambió
        if (finalQuantity !== originalValue) {
            this.disabled = true;
            
            // Actualizar la interfaz de usuario inmediatamente (optimista)
            updateItemTotal(itemId, finalQuantity, price);
            updateButtonStates(index, finalQuantity, max);
            
            try {
                const success = await updateQuantityAjax(itemId, finalQuantity);
                
                if (!success) {
                    // Revertir el cambio si falló
                    this.value = originalValue;
                    updateItemTotal(itemId, originalValue, price);
                    updateButtonStates(index, originalValue, max);
                }
            } finally {
                this.disabled = false;
                
                // Sincronizar con el servidor
                setTimeout(updateCartTotalsFromServer, 1000);
            }
        }
    });
    
    // Manejar Enter para aplicar cambios
    input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            this.blur();
        }
    });
});

// Función para eliminar item via AJAX
async function removeItemAjax(itemId) {
    try {
        const response = await fetch('ajax_update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'remove_item',
                itemId: itemId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            removeItemFromDOM(itemId);
            showMessage(result.message || 'Producto eliminado del carrito', 'success');
            
            // Sincronizar con el servidor después de eliminar
            setTimeout(updateCartTotalsFromServer, 500);
        } else {
            showMessage(result.error || 'Error al eliminar el producto', 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error de conexión al eliminar producto', 'danger');
    }
}

// Manejar clics en botones de eliminar
document.querySelectorAll('button[name="remove_item"]').forEach(button => {
    button.addEventListener('click', async function(e) {
        e.preventDefault();
        
        if (!confirm('¿Eliminar este producto del carrito?')) {
            return;
        }
        
        const itemId = parseInt(this.previousElementSibling.value);
        this.disabled = true;
        
        await removeItemAjax(itemId);
    });
});

// Función para vaciar carrito via AJAX
async function emptyCartAjax() {
    try {
        const response = await fetch('ajax_update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'empty_cart',
                idCrew: idCrew
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Mostrar mensaje y recargar la página para mostrar el carrito vacío
            showMessage(result.message || 'Carrito vaciado correctamente', 'success');
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            showMessage(result.error || 'Error al vaciar el carrito', 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showMessage('Error de conexión al vaciar el carrito', 'danger');
    }
}

// Manejar clic en botón de vaciar carrito
document.querySelector('#emptyCartBtn').addEventListener('click', async function(e) {
    e.preventDefault();
    
    if (!confirm('¿Estás seguro de vaciar el carrito?')) {
        return;
    }
    
    this.disabled = true;
    await emptyCartAjax();
});

// Inicializar al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    console.log('Carrito cargado con AJAX habilitado');
    
    // Inicializar estado de los botones
    document.querySelectorAll('.quantity-control').forEach(input => {
        const index = input.id.split('-')[1];
        const max = parseInt(input.getAttribute('max'));
        const value = parseInt(input.value);
        
        updateButtonStates(index, value, max);
    });
    
    // Calcular y mostrar totales iniciales
    const initialTotals = calculateCartTotals();
    updateCartUI(initialTotals);
    
    // Actualizar contador del carrito en la navegación
    updateCartCount();
    
    // Sincronizar con el servidor cada 30 segundos
    setInterval(updateCartTotalsFromServer, 30000);
});
</script>
     <script src="../javaScript/solicitud.js"></script>
  <?php require_once("../footer.html");?>
</body>
</html>