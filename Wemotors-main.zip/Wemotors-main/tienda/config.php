<?php
// includes/config.php
//session_start();

// Configuración de la aplicación
define('APP_NAME', 'Wemotors Shop');
define('APP_URL', 'http://localhost/wemotors');
define('COOKIE_CART', 'wemotors_cart');
?>
