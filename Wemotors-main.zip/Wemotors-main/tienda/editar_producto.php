<?php
require_once '../php/funciones.php';
require_once 'config.php';
require_once 'functions.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
$inicio = "";
if (!isset($_SESSION['usuario_nombre'])) {
  $inicio = ' <li><a class="dropdown-item" href="../inicio_sesion.php">Iniciar sesión</a></li>';
}

// Obtener idCrew de la URL
$idCrew = $_GET['idCrew'] ?? null;
if (!$idCrew) {
  header('Location: ../crews.php');
  exit;
}

// Verificar que la crew existe
$crew = getCrewById($idCrew);
if (!$crew) {
  header('Location: ../crews.php');
  exit;
}
$productoId = $_GET['id'] ?? null;

if (!$productoId || !$idCrew) {
    header('Location: ../crews.php');
    exit;
}

// Verificar que el usuario es admin de esta crew
$stmt = $pdo->prepare("SELECT c.idCrew FROM crews c WHERE c.idAdmin = ? AND c.idCrew = ?");
$stmt->execute([$_SESSION['usuario_id'], $idCrew]);
$isAdmin = $stmt->fetch();

if (!$isAdmin) {
    die("No tienes permisos para editar productos de esta crew");
}

// Obtener el producto
$producto = $pdo->prepare("SELECT * FROM producto WHERE idProducto = ? AND idCrew = ?");
$producto->execute([$productoId, $idCrew]);
$producto = $producto->fetch();

if (!$producto) {
    die("Producto no encontrado");
}

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_producto'])) {
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $precio = (float)$_POST['precio'];
    $cantidad = (int)$_POST['cantidad'];
    $idTipo = (int)$_POST['idTipo'];

    // Validaciones
    if (empty($nombre) || empty($descripcion) || $precio <= 0 || $cantidad < 0 || $idTipo <= 0) {
        $error = "Todos los campos son obligatorios y deben ser válidos";
    } else {
        try {
            // Actualizar sin imagen
            $sql = "UPDATE producto SET 
                    Nombre = ?, 
                    Descripcion = ?, 
                    precio = ?, 
                    cantidad = ?, 
                    idTipo = ? 
                    WHERE idProducto = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $nombre,
                $descripcion,
                $precio,
                $cantidad,
                $idTipo,
                $productoId
            ]);
            
            // Si se subió nueva imagen
            if (isset($_FILES['foto']['error']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
                $fotoData = file_get_contents($_FILES['foto']['tmp_name']);
                $stmt = $pdo->prepare("UPDATE producto SET fotoProducto = ? WHERE idProducto = ?");
                $stmt->execute([$fotoData, $productoId]);
            }
            
            $_SESSION['success'] = "Producto actualizado correctamente";
            header("Location: admin_productos.php?idCrew=$idCrew");
            exit;
        } catch (PDOException $e) {
            $error = "Error al actualizar el producto: " . $e->getMessage();
        }
    }
}

// Obtener categorías
$categorias = $pdo->query("SELECT * FROM tipoprod ORDER BY Nombre")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto - Wemotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="icon" href="../imagenes/logo wemotors.png" type="image/png">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .preview-img {
            max-height: 300px;
            object-fit: contain;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand navbar-brand-custom" href="../inicio.php">Wemotors</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" href="../inicio.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../crews.php">Crew</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../eventos.php">Eventos</a>
          </li>
          <li class="nav-item position-relative">
            <input type="text" class="form-control" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
            <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none"
              style="z-index: 1000;"></div>
          </li>
        </ul>
        <a href="cart.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light cart-btn-nav">
            <i class="bi bi-cart"></i> <!-- Cambiado de fas fa-shopping-cart a bi bi-cart -->
        </a>
        <div class="d-flex">
                <a href="tienda.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-light me-2">Volver a la tienda</a>
        </div>
        <div class="dropdown">
          <button class="btn btn-outline-light dropdown-toggle" type="button" id="dropdownMenuButton"
            data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo $usuario; ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
            <?php echo $inicio; ?>
            <li><a class="dropdown-item" href="../perfil_usuario.php">Perfil</a></li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item" href="../cerrar_sesion.php">Cerrar Sesión</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card form-container">
                    <div class="card-header bg-dark text-white">
                        <h4 class="mb-0"><i class="bi bi-pencil me-2"></i>Editar Producto</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre del Producto</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" 
                                       value="<?= htmlspecialchars($producto['Nombre']) ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3" required>
                                    <?= htmlspecialchars($producto['Descripcion']) ?>
                                </textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="precio" class="form-label">Precio ($)</label>
                                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" 
                                           value="<?= $producto['precio'] ?>" min="0.01" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="cantidad" class="form-label">Cantidad Disponible</label>
                                    <input type="number" class="form-control" id="cantidad" name="cantidad" 
                                           value="<?= $producto['cantidad'] ?>" min="0" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="idTipo" class="form-label">Categoría</label>
                                <select class="form-select" id="idTipo" name="idTipo" required>
                                    <option value="" disabled>Selecciona una categoría</option>
                                    <?php foreach ($categorias as $categoria): ?>
                                        <option value="<?= $categoria['idTipo'] ?>" 
                                            <?= $categoria['idTipo'] == $producto['idTipo'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($categoria['Nombre']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="mb-4">
                                <label for="foto" class="form-label">Imagen del Producto (dejar en blanco para mantener la actual)</label>
                                <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                                <div class="mt-2">
                                    <?php if (!empty($producto['fotoProducto'])): ?>
                                        <img src="data:image/jpeg;base64,<?= base64_encode($producto['fotoProducto']) ?>" 
                                             class="preview-img img-thumbnail" id="preview">
                                    <?php else: ?>
                                        <img src="https://via.placeholder.com/300x200?text=Producto" 
                                             class="preview-img img-thumbnail d-none" id="preview">
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" name="actualizar_producto" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Guardar Cambios
                                </button>
                                <a href="admin_productos.php?idCrew=<?= $idCrew ?>" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Vista previa de la imagen
        document.getElementById('foto').addEventListener('change', function(e) {
            const preview = document.getElementById('preview');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('d-none');
                }
                
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>