// assets/js/tienda.js
document.addEventListener('DOMContentLoaded', function() {
    // Actualizar contador del carrito
    //updateCartCount();
    
    // Manejar el rango de precios
    const priceRange = document.getElementById('priceRange');
    const minPriceSpan = document.getElementById('minPrice');
    const maxPriceSpan = document.getElementById('maxPrice');
    const precioMinInput = document.getElementById('precioMinInput');
    const precioMaxInput = document.getElementById('precioMaxInput');
    
    if (priceRange) {
        priceRange.addEventListener('input', function() {
            maxPriceSpan.textContent = '$' + this.value;
            precioMaxInput.value = this.value;
        });
        
        // Establecer valores iniciales si existen en los filtros
        if (precioMaxInput.value) {
            priceRange.value = precioMaxInput.value;
            maxPriceSpan.textContent = '$' + precioMaxInput.value;
        }
    }
    
    // Manejar añadir al carrito
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.getAttribute('data-product-id');
            const productName = this.getAttribute('data-product-name');
            const productPrice = parseFloat(this.getAttribute('data-product-price'));
            
            addToCart(productId, productName, productPrice);
            
            // Mostrar notificación
            const toast = document.createElement('div');
            toast.className = 'position-fixed bottom-0 end-0 p-3';
            toast.style.zIndex = '11';
            toast.innerHTML = `
                <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header bg-dark text-white">
                        <strong class="me-auto">Producto añadido</strong>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                    <div class="toast-body">
                        ${productName} ha sido añadido al carrito.
                    </div>
                </div>
            `;
            
            document.body.appendChild(toast);
            
            // Eliminar la notificación después de 3 segundos
            setTimeout(() => {
                toast.remove();
            }, 3000);
        });
    });
    
    // Cerrar notificaciones
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-close')) {
            e.target.closest('.toast').classList.remove('show');
            setTimeout(() => {
                e.target.closest('.position-fixed').remove();
            }, 300);
        }
    });
});

function updateCartCount() {
    const cart = getCart();
    const count = Object.keys(cart).length;
    document.getElementById('cartCount').textContent = count;
}

function getCart() {
    const idCrew = new URLSearchParams(window.location.search).get('idCrew');
    if (!idCrew) return {};
    
    const cartCookie = document.cookie.split('; ').find(row => row.startsWith(`wemotors_cart_${idCrew}=`));
    if (cartCookie) {
        return JSON.parse(decodeURIComponent(cartCookie.split('=')[1]));
    }
    return {};
}



function addToCart(productId, productName, productPrice) {
    const idCrew = new URLSearchParams(window.location.search).get('idCrew');
    if (!idCrew) {
        console.error('No se pudo determinar la tienda (idCrew)');
        return;
    }
    
    const cart = getCart();
    
    if (cart[productId]) {
        cart[productId].quantity += 1;
    } else {
        cart[productId] = {
            name: productName,
            price: productPrice,
            quantity: 1
        };
    }
    
    const date = new Date();
    date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
    document.cookie = `wemotors_cart_${idCrew}=${encodeURIComponent(JSON.stringify(cart))}; expires=${date.toUTCString()}; path=/`;
    
    //updateCartCount();
}