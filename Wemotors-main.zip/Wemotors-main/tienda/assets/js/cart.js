document.addEventListener('DOMContentLoaded', function() {
    // Manejar botones de cantidad
    document.querySelectorAll('.quantity-btn').forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('.quantity-control');
            let value = parseInt(input.value);
            const max = parseInt(input.getAttribute('max'));
            
            if (this.classList.contains('plus') && value < max) {
                value++;
            } else if (this.classList.contains('minus') && value > 1) {
                value--;
            }
            
            input.value = value;
        });
    });
    
    // Confirmar vaciar carrito
    document.querySelector('button[name="empty_cart"]')?.addEventListener('click', function(e) {
        const crewName = document.querySelector('h2')?.textContent.replace('Carrito de ', '') || 'esta tienda';
        if (!confirm(`¿Estás seguro de vaciar el carrito de ${crewName}?`)) {
            e.preventDefault();
        }
    });
    
    // Confirmar eliminar producto
    document.querySelectorAll('button[name="remove_item"]').forEach(button => {
        button.addEventListener('click', function(e) {
            const productName = this.closest('.row')?.querySelector('h5')?.textContent || 'este producto';
            if (!confirm(`¿Eliminar ${productName} del carrito?`)) {
                e.preventDefault();
            }
        });
    });

    // Auto-enviar formulario al cambiar cantidad
    document.querySelectorAll('.quantity-control').forEach(input => {
        input.addEventListener('change', function() {
            this.closest('form')?.submit();
        });
    });
    
    // Actualizar contador del carrito
    function updateCartCount() {
        const idCrew = new URLSearchParams(window.location.search).get('idCrew');
        if (!idCrew) return;
        
        fetch(`get_cart_count.php?id_crew=${idCrew}`)
            .then(response => response.text())
            .then(count => {
                const counterElements = document.querySelectorAll('.cart-count');
                counterElements.forEach(el => el.textContent = count || '0');
            });
    }
    
    // Actualizar cada 30 segundos
    //setInterval(updateCartCount, 30000);
    //updateCartCount();
});