<?php
require_once("funciones.php");

echo  BuscarUsuario($pdo, $_GET["texto"],$idUsu);
?>