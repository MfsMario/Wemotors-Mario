<?php
session_start();
$data=parse_ini_file("config.ini");

try {
    $pdo = new PDO(
        "mysql:host=" . $data["host"] . ";port=" . $data["port"] . ";dbname=" . $data["db"],
        $data["user"],
        $data["pass"]
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$idUsu="";
if (isset($_SESSION['usuario_id'])) {
    $idUsu = $_SESSION['usuario_id'];
    $idCR=DevolverCrewUsu($pdo);
}



if (isset($_GET['accion'])){

    switch ($_GET['accion']) {
        case 'login':
            IniciarSesiosn($pdo);
            break;
        
        case 'listVeh':
            ListarMisCoches($pdo);
            break;
        
        case 'compLog':
            comprobarLogado();
            break;
        
        case 'listcrews':
            listarCrews($pdo);
            break;
        
           
        case 'listchat':
            mostrarChat($pdo);
            break;

        case 'perfil':
            $id = isset($_GET['id']) ? $_GET['id'] : (isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null);
            if ($id) {
                echo detalleUsuario($pdo, $id);
            } else {
                echo "<div class='alert alert-warning'>Por favor inicie sesión para ver el perfil</div>";
            }
             break;

        case 'BuscEvento':
            BuscarEvento($pdo);
            break;

        case 'ListarEventos':
          $idUsu = $_SESSION['usuario_id'] ?? null;
    // Cambiar $_GET['search'] por $_GET['texto'] para coincidir con buscar_evento.js
            $searchTerm = isset($_GET['texto']) ? trim($_GET['texto']) : null;
            echo ListarEventos($pdo, $searchTerm, $idUsu);
            break;

        case 'BuscCrew':
            BuscarCrew($pdo);
            break;

        case 'cargarMarcas':
            $marcas = obtenerMarcasCoche($pdo);
            $options = '<option value="" selected disabled>Selecciona una marca</option>';
            foreach ($marcas as $marca) {
                $options .= '<option value="'.$marca['idMarca'].'">'.$marca['Nombre'].'</option>';
            }
            echo $options;
            break;
        
  case 'cargarDatosPublicacion':
    if (ob_get_level()) ob_end_clean();
    
    header('Content-Type: application/json');
    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    
    $response = [
        'success' => false,
        'debug_steps' => [],
        'message' => '',
        'marcas' => [],
        'crew' => null,
        'eventos' => []
    ];

    try {
        
        
        $marcas = obtenerMarcasCoche($pdo);
        
        if ($marcas === false) {
            throw new Exception("Error al obtener marcas");
        }
        $response['marcas'] = $marcas;
        
        // Get crew
        $response['debug_steps'][] = "Intentando obtener crew del usuario " . $_SESSION['usuario_id'];
        
        // Direct query to check user first
        $checkUser = $pdo->prepare("SELECT idUsu, Nick, idCrew FROM usuarios WHERE idUsu = ?");
        $checkUser->execute([$_SESSION['usuario_id']]);
        $userData = $checkUser->fetch(PDO::FETCH_ASSOC);
        
        if (!$userData) {
            $response['debug_steps'][] = "Usuario no encontrado en la base de datos";
            throw new Exception("Usuario no encontrado");
        }
        
        $response['debug_steps'][] = "Usuario encontrado: Nick=" . $userData['Nick'] . ", idCrew=" . 
                                    ($userData['idCrew'] ? $userData['idCrew'] : "NULL");
        
        // Now get crew details if user has a crew
        if ($userData['idCrew']) {
            $crewQuery = $pdo->prepare("SELECT idCrew, Nombre FROM crews WHERE idCrew = ?");
            $crewQuery->execute([$userData['idCrew']]);
            $crew = $crewQuery->fetch(PDO::FETCH_ASSOC);
            $response['crew'] = $crew;
        } else {
            $response['crew'] = null;
        }
        
        $eventos = obtenerEventosActivosUsuario($pdo, $_SESSION['usuario_id']);
        $response['eventos'] = $eventos;
        
        $response['success'] = true;
        $response['message'] = 'Datos cargados correctamente';
        
        echo json_encode($response, JSON_PRETTY_PRINT);
        
    } catch (Exception $e) {
        $response['debug_steps'][] = "ERROR: " . $e->getMessage() . " en " . $e->getFile() . " línea " . $e->getLine();
        $response['message'] = $e->getMessage();
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
    exit;
    break;

        case 'crearPublicacion':
            header('Content-Type: application/json');

              $idUsu = $_SESSION['usuario_id'] ?? null;
            if (!$idUsu) {
                echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
                break;
            }
            
            $fotoData = !empty($_FILES['foto']['tmp_name']) ? file_get_contents($_FILES['foto']['tmp_name']) : null;
            
           $idCrew = null;
            if (isset($_POST['añadirACrew']) && $_POST['añadirACrew'] === "1") {
                $crew = obtenerCrewUsuario($pdo, $idUsu);
                $idCrew = $crew ? $crew['idCrew'] : null;
            }
            
            $idEvento = (!empty($_POST['añadirAEvento']) && !empty($_POST['idEvento'])) 
                ? $_POST['idEvento'] 
                : null;
            
            $datos = [
                'idUsuario' => $idUsu,
                'idMarca' => $_POST['idMarca'],
                'descripcion' => $_POST['descripcion'],
                'fotoData' => $fotoData,
                'idCrew' => $idCrew,
                'idEvento' => $idEvento
            ];
            try {
                $exito = crearPublicacion($pdo, $datos);
                echo json_encode([
                    'success' => $exito,
                    'message' => $exito ? 'Publicación creada' : 'Error al crear'
                ]);
            } catch (PDOException $e) {
                echo json_encode([
                    'success' => false,
                    'message' => 'Error BD: ' . $e->getMessage()
                ]);
            }
            break;

        case 'dar_like':
            echo darLike($pdo);
            exit;
            break;

        case 'mostr':   
            devolverChat($pdo);
            break;
        
        case 'env':
            
            mandarmsj($pdo);
            break;
        
        case 'cambSeg':
            seguirDejarDeSeguir($pdo);
            break;
        
        case 'nseg':
            $idCRewPag=$_GET['idCrewpag'];
            mostrarNsegCrew($pdo);
            break;

        case 'obtener_comentarios':
            echo obtenerComentariosHTML($pdo, $_GET['idPubli']);
            break;
        case 'agregar_comentario':
            echo agregarComentario($pdo);
            break;

        case 'participar_evento':
            if (!isset($_SESSION['usuario_id'])) {
                echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
                exit;
            }
            $idEvento = $_GET['idEvento'] ?? '';
            $idUsuario = $_SESSION['usuario_id'];
            $success = unirseEvento($pdo, $idEvento, $idUsuario);
            echo json_encode([
                'success' => $success,
                'action' => 'salir',
                'nuevoConteo' => $success ? obtenerParticipantesEvento($pdo, $idEvento) : 0
            ]);
            break;
            
        case 'salir_evento':
            if (!isset($_SESSION['usuario_id'])) {
                echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
                exit;
            }
            $idEvento = $_GET['idEvento'] ?? '';
            $idUsuario = $_SESSION['usuario_id'];
            $success = salirEvento($pdo, $idEvento, $idUsuario);
            echo json_encode([
                'success' => $success,
                'action' => 'unirse',
                'nuevoConteo' => $success ? obtenerParticipantesEvento($pdo, $idEvento) : 0
            ]);
            break;

        case 'buscarUsuario':
            if(isset($_GET['texto'])) {
                echo BuscarUsuario($pdo, $_GET['texto'],$idUsu);
            }
            break;
        
        case 'seguirUsuario':
            echo seguirUsuario($pdo);
            break;

        case 'dejarSeguirUsuario':
            echo dejarSeguirUsuario($pdo);
            break;

        case 'manejarSolicitud':
            echo manejarSolicitud($pdo);
            break;
        
        case 'obtenerHtmlSolicitudes':
            echo generarHtmlSolicitudes($pdo);
            break;

        case 'obtenerSeguidores':
            if (!isset($_GET['id'])) {
                echo json_encode(['success' => false]);
                exit;
            }
            
            $sql = "SELECT COUNT(*) as seguidores 
                    FROM seguidores 
                    WHERE idSeguido = ? AND aceptado = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$_GET['id']]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'seguidores' => $result['seguidores'] ?? 0
            ]);
            break;

        case 'filtrar_publicaciones':
            $filtro = $_POST['filtro'] ?? 'todos';
            $idMarca = $_POST['idMarca'] ?? null;
            $limit = $_POST['limit'] ?? 7;
            $offset = $_POST['offset'] ?? 0;
            
            echo ListarPublicaciones($pdo, $filtro, $idMarca, $limit, $offset);
            break;
            
        case 'verificarAdmin':
            echo json_encode(['admin' => isset($_SESSION['admin']) && $_SESSION['admin']]);
            exit;
            break;

        case 'obtenerDatosUsuario':
            echo json_encode(obtenerDatosUsuarioActual($pdo));
            break;

      case 'obtenerPublicacionesUsuario':
            if (!isset($_SESSION['usuario_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'No autenticado']);
                exit;
            }
            
            try {
                $publicaciones = obtenerPublicacionesUsuario($pdo, $_SESSION['usuario_id']);
                // Asegurarse de que las imágenes se codifiquen en base64
                foreach ($publicaciones as &$pub) {
                    if ($pub['Foto']) {
                        $pub['Foto'] = base64_encode($pub['Foto']);
                    }
                }
                
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true, 
                    'publicaciones' => $publicaciones
                ]);
            } catch (Exception $e) {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false, 
                    'message' => 'Error al obtener publicaciones: ' . $e->getMessage()
                ]);
            }
            break;

    case 'obtenerPublicacion':
        if (!isset($_GET['idPubli'])) {
            echo json_encode(['success' => false, 'message' => 'ID de publicación no recibido']);
            exit;
        }
        
        $idPublicacion = $_GET['idPubli'];
        $sql = "SELECT * FROM publicaciones WHERE idPubli = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idPublicacion]);
        $publicacion = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($publicacion) {
            $publicacion['Foto'] = base64_encode($publicacion['Foto']);
            echo json_encode(['success' => true, 'publicacion' => $publicacion]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Publicación no encontrada']);
        }
        break;

    case 'mostrarChat':
        echo mostrarChatCrew($pdo);
        break;
        
    case 'enviarMensaje':
        header('Content-Type: application/json');
        echo enviarMensajeCrew($pdo);
        break;

    case 'borrarMensajeChat':
        header('Content-Type: application/json');
        echo json_encode(borrarMensajeChat($pdo));
        break;
    
    case 'verificarPertenencia':
        header('Content-Type: application/json');
        echo verificarPertenenciaCrew($pdo);
        break;
        
    case 'manejarCrew':
        header('Content-Type: application/json');
        echo manejarCrew($pdo);
        break;


    case 'obtenerDatosCrew':
    header('Content-Type: application/json');
    echo json_encode(obtenerDatosCrew($pdo, $_GET['idCrew']));
    break;

    case 'obtenerMiembrosCrew':
        header('Content-Type: application/json');
        echo json_encode(obtenerMiembrosCrew($pdo, $_GET['idCrew']));
        break;
        
    case 'obtenerPublicacionesCrewAdmin':
        header('Content-Type: application/json');
        echo json_encode(obtenerPublicacionesCrewAdmin($pdo, $_GET['idCrew']));
        break;
        
    case 'expulsarMiembro':
        header('Content-Type: application/json');
        echo json_encode(expulsarMiembroCrew($pdo, $_GET['idCrew'], $_GET['idUsuario']));
        break;
        
    case 'eliminarPublicacionCrew':
        header('Content-Type: application/json');
        echo json_encode(eliminarPublicacionCrew($pdo, $_GET['idPubli'], $_GET['idCrew']));
        break;

    case 'transferirAdmin':
        header('Content-Type: application/json');
        echo json_encode(transferirAdminCrew($pdo, $_GET['idCrew'], $_GET['idNuevoAdmin']));
        break;
        
    case 'eliminarCrew':
        header('Content-Type: application/json');
        echo json_encode(eliminarCrew($pdo, $_GET['idCrew']));
        break;

    case 'cargarModelos':
        if (isset($_GET['idMarca'])) {
            $modelos = obtenerModelosPorMarca($pdo, $_GET['idMarca']);
            $options = '<option value="" selected disabled>Selecciona un modelo</option>';
            foreach ($modelos as $modelo) {
                $options .= '<option value="'.$modelo['idModelos'].'">'.$modelo['NombreModelo'].'</option>';
            }
            echo $options;
        }
        break;

    case 'obtenerParticipantesEventoEditar':
        header('Content-Type: application/json');
        echo json_encode(obtenerParticipantesEventoEditar($pdo, $_GET["idEvento"]));
        break;

    case 'obtenerPublicacionesEventoAdmin':
            header('Content-Type: application/json');
            echo json_encode(obtenerPublicacionesEventoAdmin($pdo, $_GET["idEvento"]));
    break;

    case 'transferirAdminEvento':
        header('Content-Type: application/json');
        echo json_encode(transferirAdminEvento($pdo, $_GET['idEvento'], $_GET['idNuevoAdmin']));
        break;
        
    case 'eliminarEvento':
        header('Content-Type: application/json');
        echo json_encode(eliminarEvento($pdo, $_GET['idEvento']));
        break;

    case 'eliminarPublicacionEvento':
        header('Content-Type: application/json');
        echo json_encode(eliminarPublicacionEvento($pdo, $_GET['idPubli'], $_GET['idEvento']));
        break;

    case 'expulsarParticipanteEvento':
        header('Content-Type: application/json');
        echo json_encode(expulsarParticipanteEvento($pdo, $_GET['idEvento'], $_GET['idUsuario']));
        break;

    case 'obtenerVehiculosUsuario':
        if (!isset($_SESSION['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'No autenticado']);
            exit;
        }
        
        try {
            $sql = "SELECT v.*, m.Nombre as marcaNombre, mv.NombreModelo as modeloNombre 
                    FROM vehiculos v
                    LEFT JOIN marca m ON v.idMarca = m.idMarca
                    LEFT JOIN modelovehiculo mv ON v.Modelo = mv.idModelos
                    WHERE v.idUsu = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$_SESSION['usuario_id']]);
            $vehiculos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Codificar las imágenes en base64
            foreach ($vehiculos as &$vehiculo) {
                if ($vehiculo['FotoCoche']) {
                    $vehiculo['FotoCoche'] = base64_encode($vehiculo['FotoCoche']);
                }
            }
            
            echo json_encode(['success' => true, 'vehiculos' => $vehiculos]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Error al obtener vehículos']);
        }
        break;

    case 'quitar_like':
        echo quitarLike($pdo);
        exit;
        break;

    }
           
}

if (isset($_POST['accionP'])){

    switch ($_POST['accionP']) {
        case 'singIn':
            CrearCuenta($pdo);
            break;

        case 'enviarCodigoVerificacion':
            enviarCodigoVerificacion($pdo);
            break;
        case 'validarEmailYNick':
            validarEmailYNick($pdo);
            break;

        case 'CrearEvento':
            CrearEvento($pdo,$idUsu);
            break;

        case 'CrearCrew':
            CrearCrew($pdo,$idUsu);
            break;

        case 'crearVehiculo':
            crearVehiculo($pdo, $idUsu);
            break;

        case 'filtrar_publicaciones':
        case 'filtrar_marca':
         case 'filtrar_publicaciones':
            $filtro = $_POST['filtro'] ?? 'todos';
            $idMarca = $_POST['idMarca'] ?? null;
            $pais = $_POST['pais'] ?? null;
            $limit = $_POST['limit'] ?? 7;
            $offset = $_POST['offset'] ?? 0;
            
            echo ListarPublicaciones($pdo, $filtro, $idMarca, $limit, $offset, $pais);
            break;

        case 'reportar':
            echo json_encode(manejarReporte($pdo));
            break;

        case 'actualizarPerfil':
            actualizarPerfilUsuario($pdo);
            break;
        case 'eliminarCuenta':
            eliminarCuentaUsuario($pdo);
            break;

        case 'eliminarPublicacion':
            if (!isset($_SESSION['usuario_id'])) {
                echo json_encode(['success' => false, 'message' => 'No autenticado']);
                exit;
            }
            
            if (empty($_POST['idPublicacion'])) {
                echo json_encode(['success' => false, 'message' => 'ID de publicación no recibido']);
                exit;
            }
            
            $idPublicacion = $_POST['idPublicacion'];
            
            try {
                // Verificar que la publicación pertenece al usuario
                $sql = "SELECT idUsu FROM publicaciones WHERE idPubli = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$idPublicacion]);
                $publicacion = $stmt->fetch();
                
                if (!$publicacion || $publicacion['idUsu'] != $_SESSION['usuario_id']) {
                    echo json_encode(['success' => false, 'message' => 'No tienes permiso para eliminar esta publicación']);
                    exit;
                }
                
                // Eliminar la publicación
                $sql = "DELETE FROM publicaciones WHERE idPubli = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$idPublicacion]);
                
                echo json_encode(['success' => true]);
            } catch (PDOException $e) {
                error_log('Error al eliminar publicación: ' . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Error al eliminar la publicación']);
            }
            break;

         case 'actualizarPublicacion':
            if (!isset($_SESSION['usuario_id']) || empty($_POST['idPublicacion'])) {
                echo json_encode(['success' => false, 'message' => 'No autenticado o ID no recibido']);
                exit;
            }
            
            $idPublicacion = $_POST['idPublicacion'];
            $descripcion = $_POST['descripcion'] ?? '';
            
            // Verificar que la publicación pertenece al usuario
            $sql = "SELECT idUsu FROM publicaciones WHERE idPubli = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idPublicacion]);
            $publicacion = $stmt->fetch();
            
            if (!$publicacion || $publicacion['idUsu'] != $_SESSION['usuario_id']) {
                echo json_encode(['success' => false, 'message' => 'No tienes permiso para editar esta publicación']);
                exit;
            }
            
            // Actualizar la descripción
            $sql = "UPDATE publicaciones SET DescripcionPubli = ? WHERE idPubli = ?";
            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([$descripcion, $idPublicacion]);
            
            echo json_encode(['success' => $success, 'message' => $success ? 'Publicación actualizada' : 'Error al actualizar']);
            break;

    case 'eliminarComentario':
        if (!isset($_SESSION['usuario_id']) || empty($_POST['idComentario'])) {
            echo json_encode(['success' => false, 'message' => 'No autenticado o ID no recibido']);
            exit;
        }
        
        $idComentario = $_POST['idComentario'];
        
        // Verificar permisos (solo el dueño del comentario o de la publicación puede borrar)
        $sql = "SELECT c.idUsu, p.idUsu as idUsuPubli 
                FROM comentario c
                JOIN publicaciones p ON c.idPub = p.idPubli
                WHERE c.idComentario = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idComentario]);
        $datos = $stmt->fetch();
        
        if (!$datos) {
            echo json_encode(['success' => false, 'message' => 'Comentario no encontrado']);
            exit;
        }
        
        if ($datos['idUsu'] != $_SESSION['usuario_id'] && $datos['idUsuPubli'] != $_SESSION['usuario_id']) {
            echo json_encode(['success' => false, 'message' => 'No tienes permiso para eliminar este comentario']);
            exit;
        }
        
        $sql = "DELETE FROM comentario WHERE idComentario = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$idComentario]);
        
        echo json_encode(['success' => $success, 'message' => $success ? 'Comentario eliminado' : 'Error al eliminar']);
        break;

    case 'eliminarTodosComentarios':
        if (!isset($_SESSION['usuario_id']) || empty($_POST['idPublicacion'])) {
            echo json_encode(['success' => false, 'message' => 'No autenticado o ID no recibido']);
            exit;
        }
        
        $idPublicacion = $_POST['idPublicacion'];
        
        // Verificar que la publicación pertenece al usuario
        $sql = "SELECT idUsu FROM publicaciones WHERE idPubli = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idPublicacion]);
        $publicacion = $stmt->fetch();
        
        if (!$publicacion || $publicacion['idUsu'] != $_SESSION['usuario_id']) {
            echo json_encode(['success' => false, 'message' => 'No tienes permiso para eliminar estos comentarios']);
            exit;
        }
        
        $sql = "DELETE FROM comentario WHERE idPub = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$idPublicacion]);
        
        echo json_encode(['success' => $success, 'message' => $success ? 'Todos los comentarios eliminados' : 'Error al eliminar']);
        break;

    case 'actualizarCrew':
        actualizarCrew($pdo);
        break;

    case 'actualizarEvento':
        // Aquí va la lógica para actualizar el evento
        actualizarEvento($pdo);
        break;

    case 'eliminarVehiculo':
            if (!isset($_SESSION['usuario_id']) || empty($_POST['idVehiculo'])) {
                echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
                exit;
            }
            
            try {
                // Verificar que el vehículo pertenece al usuario
                $sql = "SELECT idVehiculo FROM vehiculos WHERE idVehiculo = ? AND idUsu = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$_POST['idVehiculo'], $_SESSION['usuario_id']]);
                
                if (!$stmt->fetch()) {
                    echo json_encode(['success' => false, 'message' => 'Vehículo no encontrado o no tienes permisos']);
                    exit;
                }
                
                // Eliminar el vehículo
                $sql = "DELETE FROM vehiculos WHERE idVehiculo = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$_POST['idVehiculo']]);
                
                echo json_encode(['success' => true]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar vehículo']);
            }
            break;

        case 'eliminarVehiculo':
            if (!isset($_SESSION['usuario_id']) || empty($_POST['idVehiculo'])) {
                echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
                exit;
            }
            
            try {
                // Verificar que el vehículo pertenece al usuario
                $sql = "SELECT idVehiculo FROM vehiculos WHERE idVehiculo = ? AND idUsu = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$_POST['idVehiculo'], $_SESSION['usuario_id']]);
                
                if (!$stmt->fetch()) {
                    echo json_encode(['success' => false, 'message' => 'Vehículo no encontrado o no tienes permisos']);
                    exit;
                }
                
                // Eliminar el vehículo
                $sql = "DELETE FROM vehiculos WHERE idVehiculo = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$_POST['idVehiculo']]);
                
                echo json_encode(['success' => true]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar vehículo']);
            }
            break;
        }


    
}
function IniciarSesiosn($pdo) {
    $nombreUsu = htmlentities($_GET['Nick']);
    $contrase = md5(htmlentities($_GET['contra']));

    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute([$nombreUsu]);

    if ($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
        $id = $fila['idUsu'];
        $nom = $fila['Nick'];
        $pass = $fila['contra'];
        $esAdmin = $fila['Admin'];

        if ($pass == $contrase) {
            $_SESSION['usuario_nombre'] = $nom; 
            $_SESSION['usuario_id'] = $id;

            if ($esAdmin) {
                $_SESSION['admin'] = true;
            }

            echo $nom; 
            exit;
        }
    }

    echo ""; 
    exit;
}

function CrearCuenta($pdo) {
    $nombre = htmlspecialchars($_POST['nomb'] ?? '');
    $apellidos = htmlspecialchars($_POST['apell'] ?? '');
    $nick = htmlspecialchars($_POST['nick'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $password = md5($_POST['contra'] ?? '');
    $privada = isset($_POST['privada']) && $_POST['privada'] === '1' ? 1 : 0;
    $fechaActual = date('Y-m-d H:i:s');

    if (empty($nombre) || empty($apellidos) || empty($nick) || empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'El email no es válido']);
        exit;
    }

    // La validación de duplicados ya se hizo antes, así que procedemos directamente con la imagen
    $imagenData = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        // Validar tipo de imagen
        $mimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($fileInfo, $_FILES['foto']['tmp_name']);
        finfo_close($fileInfo);

        if (!in_array($mime, $mimeTypes)) {
            echo json_encode(['success' => false, 'message' => 'Solo se permiten imágenes JPEG, PNG o GIF']);
            exit;
        }

        if ($_FILES['foto']['size'] > 2097152) {
            echo json_encode(['success' => false, 'message' => 'La imagen no debe superar los 2MB']);
            exit;
        }

        $imagenData = file_get_contents($_FILES['foto']['tmp_name']);
        if ($imagenData === false) {
            echo json_encode(['success' => false, 'message' => 'Error al leer la imagen']);
            exit;
        }
    }
    
    try {
        $sql = "INSERT INTO usuarios (Nombre, Apellidos, Nick, email, contra, FotoPerfil, privada, fecRegistro) 
                VALUES (:nomb, :ape, :nick, :ema, :con, :foto, :privada, :fec)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ":nomb" => $nombre,
            ":ape" => $apellidos,
            ":nick" => $nick,
            ":ema" => $email,
            ":con" => $password,
            ":foto" => $imagenData,
            ":privada" => $privada,
            ":fec" => $fechaActual
        ]);

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        error_log('Error en registro: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error en el registro. Por favor, inténtalo de nuevo.']);
    }
}


function validarEmailYNick($pdo) {
    $email = htmlspecialchars($_POST['email'] ?? '');
    $nick = htmlspecialchars($_POST['nick'] ?? '');
    
    if (empty($email) || empty($nick)) {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'El email no es válido']);
        exit;
    }
    
    try {
        $stmt = $pdo->prepare("SELECT idUsu FROM usuarios WHERE email = ? OR Nick = ?");
        $stmt->execute([$email, $nick]);
        $existentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($existentes as $usuario) {
            $stmt = $pdo->prepare("SELECT email, Nick FROM usuarios WHERE idUsu = ?");
            $stmt->execute([$usuario['idUsu']]);
            $datos = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($datos['email'] === $email) {
                echo json_encode(['success' => false, 'message' => 'El email ya está registrado']);
                exit;
            }
            if ($datos['Nick'] === $nick) {
                echo json_encode(['success' => false, 'message' => 'El nombre de usuario ya está en uso']);
                exit;
            }
        }
        
        // Si llegamos aquí, tanto el email como el nick están disponibles
        echo json_encode(['success' => true, 'message' => 'Email y nick disponibles']);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error al verificar datos existentes']);
        exit;
    }
}

function BuscarUsuario($pdo, $texto, $idUsu) {
  $sql = "SELECT idUsu, Nick, FotoPerfil, privada 
            FROM usuarios 
            WHERE Nick LIKE CONCAT(:texto, '%')
            AND idUsu != :idUsuarioActual 
            ORDER BY Nick 
            LIMIT 5";
    
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute([
        ':texto' => $texto,
        ':idUsuarioActual' => $idUsu
    ]);
    
    $output = '<ul class="list-group" id="lista-usuarios">';
    
    while($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
        $fotoPerfil = $fila['FotoPerfil'] ? 
                     'data:image/jpeg;base64,'.base64_encode($fila['FotoPerfil']) : 
                     'img/default-profile.png';
        
        $output .= '
        <li class="list-group-item list-group-item-action usuario-item" 
            data-user-id="'.$fila["idUsu"].'"
            data-privada="'.$fila["privada"].'"
            onclick="redirigirAPerfil('.$fila["idUsu"].')">
            <div class="d-flex align-items-center">
                <img src="'.$fotoPerfil.'" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">
                <span>'.htmlspecialchars($fila["Nick"]).'</span>
                '.($fila["privada"] ? '<span class="badge bg-secondary ms-2">Privada</span>' : '').'
            </div>
        </li>';
    }
    
    $output .= '</ul>';
    
    return $output ?: '<div class="p-2">No se encontraron usuarios</div>';
}

function ListarPublicaciones($pdo, $filtro = 'todos', $idMarca = null, $limit = 7, $offset = 0, $pais=null) {
    $usuarioId = $_SESSION['usuario_id'] ?? null;
    
    $sql = "SELECT p.*, u.*, m.Nombre, m.Pais 
            FROM publicaciones p
            INNER JOIN usuarios u ON u.idUsu = p.idUsu
            INNER JOIN marca m ON m.idMarca = p.idMarca";
    
    $where = [];
    $params = [];
    
    if ($filtro === 'siguiendo' && $usuarioId) {
        $where[] = "(p.idUsu IN (SELECT idSeguido FROM seguidores WHERE idSeguidor = :usuarioId AND aceptado = 1) OR p.idUsu = :usuarioId)";
        $params[':usuarioId'] = $usuarioId;
    } elseif ($filtro === 'todos') {
        if ($usuarioId) {
            // Mostrar publicaciones de: 
            // 1. Usuarios no privados O 
            // 2. Usuarios que sigues y te aceptaron O 
            // 3. Tus propias publicaciones
            $where[] = "(u.privada = 0 OR 
                        p.idUsu IN (SELECT idSeguido FROM seguidores WHERE idSeguidor = :usuarioId AND aceptado = 1) OR 
                        p.idUsu = :usuarioId)";
            $params[':usuarioId'] = $usuarioId;
        } else {
            // Usuario no logueado - solo ver usuarios no privados
            $where[] = "u.privada = 0";
        }
    }
    
    if ($filtro === 'marca' && $idMarca) {
        $where[] = "(u.privada = 0 OR 
                    p.idUsu IN (SELECT idSeguido FROM seguidores WHERE idSeguidor = :usuarioId AND aceptado = 1) OR 
                    p.idUsu = :usuarioId) AND p.idMarca = :idMarca";
        $params[':idMarca'] = $idMarca;
        $params[':usuarioId'] = $usuarioId;
    }

    if ($filtro === 'pais' && $pais) {
        if ($usuarioId) {
            // Aplicar las mismas restricciones de privacidad que en 'todos'
            $where[] = "(u.privada = 0 OR 
                        p.idUsu IN (SELECT idSeguido FROM seguidores WHERE idSeguidor = :usuarioId AND aceptado = 1) OR 
                        p.idUsu = :usuarioId) AND m.Pais = :pais";
            $params[':usuarioId'] = $usuarioId;
        } else {
            // Usuario no logueado - solo ver usuarios no privados del país
            $where[] = "u.privada = 0 AND m.Pais = :pais";
        }
        $params[':pais'] = $pais;
    }
    
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    $sql .= " ORDER BY p.fecPublicacion DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($sql);
    
    // Bind de parámetros
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $limit = (int)$limit;
    $offset = (int)$offset;
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();

    $output = '';
    
    if ($stmt->rowCount() > 0) {
        while($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $imagenBase64 = base64_encode($fila["Foto"]);
            $imagenSrc = 'data:image/jpeg;base64,'.$imagenBase64;
            
            $perfilBase64 = base64_encode($fila["FotoPerfil"]);
            $perfilSrc = 'data:image/jpeg;base64,'.$perfilBase64;

            $usuarioDioLike = isset($_SESSION['usuario_id']) ? yaDioLike($pdo, $fila['idPubli'], $_SESSION['usuario_id']) : false;

            // Determinar el enlace del perfil
            $enlacePerfil = ($fila['idUsu'] == $usuarioId) ? 'perfil_usuario.php' : 'perfil_ajeno.php?id='.$fila["idUsu"];

            $output .= '
            <div class="d-flex justify-content-center align-items-center mt-4 px-3">
                <div class="card text-center border border-dark border-2 border-opacity-75" style="max-width: 500px; width: 100%; height: auto;">
                    <div class="card-header d-flex align-items-center bg-dark text-white">
                        <a href="'.$enlacePerfil.'">
                            <img src="'.$perfilSrc.'" class="rounded-circle me-2" style="width: 40px; height: 40px;"> </a>
                            <span>'.$fila["Nick"].'</span>' ;
            
            if ($filtro === 'marca' && !empty($fila["Nombre"])) {
                $output .= '<span class="badge bg-primary ms-2">'.$fila["Nombre"].'</span>';
            }
            
            if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] != $fila['idUsu']) {
                $output .= '<div class="ms-auto">
                    <button class="btn btn-link text-danger p-0" 
                            onclick="abrirReporteModal(\'usuario\', '.$fila['idUsu'].', \''.htmlspecialchars($fila['Nick']).'\')">
                        <i class="bi bi-flag-fill"></i>
                    </button>
                </div>';
            }
            
            $output .= '</div>
                    <div class="card-body p-0" style="height: 350px; overflow: hidden;">
                        <img src="'.$imagenSrc.'" class="w-100 h-100" style="object-fit: cover;" alt="...">
                    </div>
                    <div class="card-footer text-body-secondary p-3 bg-dark text-white">
                        <div class="text-start mb-2">
                            <p class="m-0 text-white">'.$fila["DescripcionPubli"].'</p>
                        </div>
                        <hr class="mt-2 mb-3 border-white border-3 ">
                        <div class="d-flex align-items-center ps-1">
                            <i class="bi '.($usuarioDioLike ? 'bi-heart-fill text-danger' : 'bi-heart text-secondary').' fs-4 like-btn text-white" 
                               data-publi-id="'.$fila['idPubli'].'" 
                               style="cursor: pointer;"></i>
                            <span class="ms-2 like-count text-white">'.$fila["NLikes"].'</span>
                            <button class="btn btn-link text-dark p-0 ms-3 comment-btn" 
                                data-publi-id="'.$fila['idPubli'].'"
                                data-bs-toggle="offcanvas" 
                                data-bs-target="#commentsSidebar">
                                <i class="bi bi-chat-left-text fs-4 text-white"></i>
                            </button>
                            <span class="ms-2 text-white">'.obtenerCantidadComentarios($pdo, $fila['idPubli']).'</span>
                        </div>
                    </div>
                </div>
            </div>';
        }
    } else {
        if ($offset === 0) {
            $output = '<div class="text-center mt-4">No hay publicaciones para mostrar</div>';
        } else {
            $output = '<div class="text-center mt-4">No hay más publicaciones</div>';
            exit;
        }
    }
    
    return $output;
}

function ListarCrews($pdo) {
    $searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
    
    $sql = "SELECT * FROM crews";
    if (!empty($searchTerm)) {
        $sql .= " WHERE Nombre LIKE CONCAT(:search, '%')";
    }
    
    $sentencia = $pdo->prepare($sql);
    
    if (!empty($searchTerm)) {
        $sentencia->execute([':search' => $searchTerm]);
    } else {
        $sentencia->execute();
    }

    if ($sentencia->rowCount() == 0) {
        echo'<div class="col-12 text-center py-4"><p>No se encontraron crews.</p></div>';
    }

    while($crew = $sentencia->fetch(PDO::FETCH_ASSOC)){
        $imagenBase64 = base64_encode($crew["Foto"]);
        $imagenSrc = 'data:image/jpeg;base64,'.$imagenBase64;
    
        echo '
        <div class="card bg-dark text-white mb-4 crew-card p-2 position-relative">
            <div class="card-body">
                <a href="detalle_crew.php?id='.$crew['idCrew'].'" class="stretched-link"></a>
                <div class="d-flex align-items-center">
                    <img src="'.$imagenSrc.'" class="rounded me-4" style="width: 80px; height: 80px; object-fit: cover;">
                    <div>
                        <h5 class="card-title mb-1">'.$crew['Nombre'].'</h5>
                        <p class="card-text mb-1"><small>'.$crew['NUsuarios'].' participantes</small></p>
                        <p class="card-text mb-0">'.$crew['Descripcion'].'</p>
                    </div>
                </div>
            </div>';
            
        // Botón de reportar (solo visible si no es el administrador)
        if (isset($_SESSION['usuario_id']) && (!isset($_SESSION['admin']) || !$_SESSION['admin'])) {
            echo '<div class="position-absolute top-0 end-0 m-2"  style="z-index:1;>
                <button class="btn btn-link p-0" 
                        onclick="abrirReporteModal(\'crew\', '.$crew['idCrew'].', \''.htmlspecialchars($crew['Nombre']).'\')">
                    <i class="bi bi-flag-fill  text-danger"></i>
                </button>
            </div>';
        }
        
        echo '</div>';
    }
}

function ListarEventos($pdo, $searchTerm = null, $userId = null) {
    $sql = "SELECT e.*, COUNT(eu.idUsu) AS participantes,
            CASE WHEN EXISTS (
                SELECT 1 FROM evento_usu WHERE idEvento = e.idEvento AND idUsu = :userId
            ) THEN 1 ELSE 0 END AS usuario_participa
            FROM eventos AS e
            LEFT JOIN evento_usu AS eu ON e.idEvento = eu.idEvento";
    
    $params = [':userId' => $userId ?: 0];
    
    if($searchTerm) {
        $sql .= " WHERE e.Nombre LIKE :searchTerm";
        $params[':searchTerm'] = '%' . $searchTerm . '%';
    }
    
    $sql .= " GROUP BY e.idEvento
              ORDER BY usuario_participa DESC, e.fecEvento ASC";
    
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute($params);
    $output = '';

    if ($sentencia->rowCount() == 0) {
        return '<div class="col-12 text-center py-4"><p>No se encontraron eventos.</p></div>';
    }

    while($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
        $imagenBase64 = base64_encode($fila["PerfilEvento"]);
        $imagenSrc = 'data:image/jpeg;base64,'.$imagenBase64;
        
        $participaBadge = $fila["usuario_participa"] ? 
            '<span class="badge bg-success position-absolute top-0 end-0 m-2 me-5" >Participas</span>' : '';

        $output .= '
        <div class="col-lg-8 position-relative">
            <div class="card bg-dark text-white mb-4 crew-card">
                '.$participaBadge;
                
       if (isset($_SESSION['usuario_id'])) {
            $output .= '<div class="position-absolute top-0 end-0 m-2" style="z-index: 3;">
                <button class="btn btn-link text-danger p-0" 
                        onclick="event.stopPropagation(); abrirReporteModal(\'evento\', '.$fila["idEvento"].', \''.htmlspecialchars($fila["Nombre"]).'\')">
                    <i class="bi bi-flag-fill"></i>
                </button>
            </div>';
        }
                
        $output .= '
                <div class="card-body position-relative">
                    <a href="detalle_evento.php?idEvento='.$fila["idEvento"].'" class="stretched-link"></a>
                    <div class="d-flex flex-column flex-md-row align-items-center">
                        <img src="'. $imagenSrc.'" class="img-fluid me-md-4 mb-3 mb-md-0" style="height: 100px; width: auto; min-width: 100px;">
                        <div class="text-center text-md-start flex-grow-1 me-md-5 pe-md-3">
                            <p class="mb-1 fs-5">'.$fila["Nombre"].'</p>
                            <p class="mb-1">'.$fila["participantes"].' participantes</p>
                            <p class="mb-3 mb-md-1">'.$fila["Descripcion"].'</p>
                        </div>
                    </div>
                    <div class="d-flex flex-column mt-3 mt-md-0 position-static position-md-absolute bottom-0 end-0 p-md-3 ps-0">
                        <div class="d-flex align-items-center justify-content-center justify-content-md-start mb-2">
                            <i class="bi bi-geo-alt-fill me-2"></i>
                            <span>'.$fila["Lugar"].'</span>
                        </div>
                        <div class="d-flex align-items-center justify-content-center justify-content-md-start">
                            <i class="bi bi-clock-fill me-2"></i>
                            <span>'.$fila["fecEvento"].'</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }
    return $output;
}
function CrearEvento($pdo, $idUsu) {
    header('Content-Type: application/json');
   
    if (!isset($_POST['nomb']) || empty($_POST['nomb']) || 
        !isset($_POST['desc']) || empty($_POST['desc']) || 
        !isset($_POST['lugar']) || empty($_POST['lugar']) || 
        !isset($_POST['fecha']) || empty($_POST['fecha'])) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    $nombre = htmlspecialchars($_POST['nomb']);
    $descripcion = htmlspecialchars($_POST['desc']);
    $lugar = htmlspecialchars($_POST['lugar']);
    $fechaEvento = $_POST['fecha'];
    $aplicarFiltro = isset($_POST['aplicarFiltro']) && $_POST['aplicarFiltro'] === "1";
    $idMarca = $aplicarFiltro && isset($_POST['idMarca']) ? (int)$_POST['idMarca'] : null;
    $idModelo = $aplicarFiltro && isset($_POST['idModelo']) ? (int)$_POST['idModelo'] : null;
    $idTipo = $aplicarFiltro && isset($_POST['idTipo']) ? (int)$_POST['idTipo'] : null;

    try {
        // Verificar si ya existe un evento con el mismo nombre
        $sqlCheck = "SELECT idEvento FROM eventos WHERE Nombre = ?";
        $stmtCheck = $pdo->prepare($sqlCheck);
        $stmtCheck->execute([$nombre]);
        
        if ($stmtCheck->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Ya existe un evento con ese nombre']);
            exit;
        }

        $fechaObj = new DateTime($fechaEvento);
        $fechaFormateada = $fechaObj->format('Y-m-d H:i:s');
        
        $fechaActual = new DateTime();
        if ($fechaObj < $fechaActual) {
            echo json_encode(['success' => false, 'message' => 'No se pueden crear eventos con fecha pasada']);
            exit;
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Formato de fecha inválido']);
        exit;
    }

    // Resto del código permanece igual...
    $imagenData = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $mimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($fileInfo, $_FILES['foto']['tmp_name']);
        finfo_close($fileInfo);

        if (!in_array($mime, $mimeTypes)) {
            echo json_encode(['success' => false, 'message' => 'Solo se permiten imágenes JPEG, PNG o GIF']);
            exit;
        }

        if ($_FILES['foto']['size'] > 2097152) {
            echo json_encode(['success' => false, 'message' => 'La imagen no debe superar los 2MB']);
            exit;
        }

        $imagenData = file_get_contents($_FILES['foto']['tmp_name']);
    }

    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión para crear eventos']);
        exit;
    }

    try {
        // Modificar la consulta SQL para incluir los filtros
        $sql = "INSERT INTO eventos (Nombre, Descripcion, Lugar, fecEvento, PerfilEvento, idUsuAdmin, Marca, Modelo, TipoCoche) 
                VALUES (:nombre, :descripcion, :lugar, :fecha, :imagen, :idUsuario, :idMarca, :idModelo, :idTipo)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ":nombre" => $nombre,
            ":descripcion" => $descripcion,
            ":lugar" => $lugar,
            ":fecha" => $fechaFormateada,
            ":imagen" => $imagenData,
            ":idUsuario" => $idUsu,
            ":idMarca" => $idMarca,
            ":idModelo" => $idModelo,
            ":idTipo" => $idTipo
        ]);

        $idEvento = $pdo->lastInsertId();

        $sqlParticipante = "INSERT INTO evento_usu (idEvento, idUsu) VALUES (:idEvento, :idUsuario)";
        $stmtParticipante = $pdo->prepare($sqlParticipante);
        $stmtParticipante->execute([":idEvento" => $idEvento, ":idUsuario" => $idUsu]);

        echo json_encode(['success' => true, 'message' => 'Evento creado con éxito', 'idEvento' => $idEvento]);
    } catch (PDOException $e) {
        error_log('Error al crear evento: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al crear el evento. Por favor, inténtalo de nuevo.']);
    }
}

function CrearCrew($pdo, $idUsu) {
     header('Content-Type: application/json');
   
    // Primero verificar si el usuario ya está en una crew
    $sqlCheck = "SELECT idCrew FROM usuarios WHERE idUsu = ? AND idCrew IS NOT NULL";
    $stmtCheck = $pdo->prepare($sqlCheck);
    $stmtCheck->execute([$idUsu]);
    
    if ($stmtCheck->fetch()) {
        echo json_encode([
            'success' => false, 
            'message' => 'Ya perteneces a una crew. Debes salir de tu crew actual antes de crear una nueva.'
        ]);
        exit;
    }

    $requiredFields = ['nomb', 'desc'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => 'El campo ' . $field . ' es obligatorio']);
            exit;
        }
    }

    $nombre = htmlspecialchars(trim($_POST['nomb']));
    $descripcion = htmlspecialchars(trim($_POST['desc']));

    // Procesamiento de imagen
    $imagenData = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        try {
            // Validar tipo de imagen
            $mimeTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif'];
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $fileInfo->file($_FILES['foto']['tmp_name']);

            if (!array_key_exists($mime, $mimeTypes)) {
                throw new Exception('Solo se permiten imágenes JPEG, PNG o GIF');
            }

            if ($_FILES['foto']['size'] > 2097152) {
                throw new Exception('La imagen no debe superar los 2MB');
            }

            $imagenData = file_get_contents($_FILES['foto']['tmp_name']);
            if ($imagenData === false) {
                throw new Exception('Error al leer la imagen');
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    try {
        $pdo->beginTransaction();

        // 1. Crear la crew
        $sql = "INSERT INTO crews (Nombre, Descripcion, idAdmin, NUsuarios, Foto) 
                VALUES (:nombre, :descripcion, :idUsuario, 1, :imagen)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindParam(':idUsuario', $idUsu, PDO::PARAM_INT);
        $stmt->bindParam(':imagen', $imagenData, PDO::PARAM_LOB);
        
        if (!$stmt->execute()) {
            throw new Exception('Error al crear la crew');
        }

        $idCrew = $pdo->lastInsertId();

        // 2. Actualizar el usuario con el id_crew
        $sqlUsuario = "UPDATE usuarios SET idCrew = :idCrew WHERE idUsu = :idUsuario";
        $stmtUsuario = $pdo->prepare($sqlUsuario);
        $stmtUsuario->bindParam(':idCrew', $idCrew, PDO::PARAM_INT);
        $stmtUsuario->bindParam(':idUsuario', $idUsu, PDO::PARAM_INT);
        
        if (!$stmtUsuario->execute()) {
            throw new Exception('Error al actualizar el usuario');
        }

        $pdo->commit();

        echo json_encode([
            'success' => true, 
            'message' => 'Crew creada con éxito',
            'idCrew' => $idCrew
        ]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Error en CrearCrew: ' . $e->getMessage());
        echo json_encode([
            'success' => false, 
            'message' => 'Error en la base de datos: ' . $e->getMessage()
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log('Error en CrearCrew: ' . $e->getMessage());
        echo json_encode([
            'success' => false, 
            'message' => $e->getMessage()
        ]);
    }
}

///Para listar los coches del propio usuario, coge la información guardada en la sesión y devuelve sus coches en un array bidimensional que será (idVehiculo,marca,modelo,año,foto)
function ListarMisCoches($pdo){
    $array=[];
    $sql="SELECT * FROM vehiculos";
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute();
    while($fila=$sentencia->fetch(PDO::FETCH_ASSOC)){
        $id=$fila['idVehiculo'];
        $idUsuar=$fila['idUsu'];
        $idMarca=$fila['idMarca'];
        $mod=$fila['Modelo'];
        $agno=$fila['Agno'];
        $foto=$fila['foto'];

        if ($_SESSION['usuario'][0]==$idUsuar){
            array_push($array,[$id,DevolverNombreMarca($pdo,$idMarca),$mod,$agno,$foto]);
        }
    }
    var_dump($array);
    return $array;

}


function DevolverNombreMarca($pdo) {
    $sql = "SELECT idMarca, Nombre FROM marca
    ORDER BY Nombre";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function DevolverCrewUsu($pdo){
    $idCre=0;
    $sql="SELECT * FROM usuarios WHERE idUsu='".$_SESSION['usuario_id']."'";
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute();
    while($fila=$sentencia->fetch(PDO::FETCH_ASSOC)){
        $idCre=$fila['idCrew'];
    }
    return $idCre;

}




function detalleEvento($pdo, $ID,$esAdminEvento = false) {
    $sqlEvento = "SELECT e.*, m.Nombre as marcaNombre, mv.NombreModelo as modeloNombre, tv.TipoNombre as tipoNombre 
                 FROM eventos AS e
                 LEFT JOIN marca m ON e.Marca = m.idMarca
                 LEFT JOIN modelovehiculo mv ON e.Modelo = mv.idModelos
                 LEFT JOIN tipovehiculo tv ON e.TipoCoche = tv.idTipo
                 WHERE e.idEvento = :idEvento";
    
    $stmtEvento = $pdo->prepare($sqlEvento);
    $stmtEvento->bindParam(':idEvento', $ID, PDO::PARAM_INT);
    $stmtEvento->execute();
    $evento = $stmtEvento->fetch(PDO::FETCH_ASSOC);

    // Obtenemos el número de participantes
    $participantesCount = obtenerParticipantesEvento($pdo, $ID);

    $sqlPublicaciones = "SELECT p.*, u.Nick, u.FotoPerfil 
                        FROM publicaciones p
                        JOIN usuarios u ON p.idUsu = u.idUsu
                        WHERE p.idEvento = :idEvento";
    $stmtPublicaciones = $pdo->prepare($sqlPublicaciones);
    $stmtPublicaciones->bindParam(':idEvento', $ID, PDO::PARAM_INT);
    $stmtPublicaciones->execute();
    $publicaciones = $stmtPublicaciones->fetchAll(PDO::FETCH_ASSOC);

    $perfilBase64 = base64_encode($evento["PerfilEvento"]);
    $perfilSrc = 'data:image/jpeg;base64,'.$perfilBase64;

    // Verificar si el usuario actual está participando
    $participando = false;
    if (isset($_SESSION['usuario_id'])) {
        $participando = usuarioParticipaEvento($pdo, $ID, $_SESSION['usuario_id']);
    }

    // Verificar si el usuario tiene vehículos que cumplan los filtros
    $puedeParticipar = true;
    $mensajeFiltro = '';
    if (isset($_SESSION['usuario_id'])) {
        // Si es admin del evento, puede participar sin restricciones
        if ($esAdminEvento) {
            $puedeParticipar = true;
        } else {
            // Si no es admin, verificar los filtros normalmente
            $puedeParticipar = verificarFiltrosEvento($pdo, $evento, $_SESSION['usuario_id']);
            if (!$puedeParticipar) {
                $mensajeFiltro = '<div class="alert alert-warning mt-3">No tienes vehículos que cumplan con los filtros de este evento</div>';
            }
        }
    }

    // Mostrar filtros si existen
    $filtrosHTML = '';
    if ($evento['Marca'] || $evento['Modelo'] || $evento['TipoCoche']) {
        $filtrosHTML .= '<div class="mt-3"><h5>Filtros del evento:</h5><ul class="list-unstyled">';
        
        if ($evento['Marca']) {
            $filtrosHTML .= '<li><strong>Marca:</strong> '.htmlspecialchars($evento['marcaNombre']).'</li>';
        }
        
        if ($evento['Modelo']) {
            $filtrosHTML .= '<li><strong>Modelo:</strong> '.htmlspecialchars($evento['modeloNombre']).'</li>';
        }
        
        if ($evento['TipoCoche']) {
            $filtrosHTML .= '<li><strong>Tipo:</strong> '.htmlspecialchars($evento['tipoNombre']).'</li>';
        }
        
        $filtrosHTML .= '</ul></div>';
    }
    $output = '';

    $output = '
    <div class="container-fluid px-lg-5 px-md-3 px-sm-2 mt-5 z-2">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="border border-dark rounded-4 border-3 bg-dark mb-3 mx-auto p-3" style="max-width: 800px; min-height: 150px;">
                    <div class="row text-white align-items-center py-3 px-2">
                        <div class="col-12 col-md-auto text-center text-md-start mb-3 mb-md-0">
                            <img src="' . $perfilSrc. '" class="img-fluid mx-auto d-block" style="height: 150px; width: 150px;">
                            '.$filtrosHTML.'
                        </div>
                        <div class="col-12 col-md-4 text-center text-md-start mb-3 mb-md-0">
                            <h1 class="mb-1">' . $evento["Nombre"] . '</h1>
                            <p class="mb-0">' .$evento["Descripcion"] . '</p>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <p class="mb-1"><b>Participantes:</b></p>
                          <p class="mb-0 participantes-count">' . $participantesCount . '</p>
                        </div>
                        <div class="col-6 col-md-2 text-center">
                            <p class="mb-1"><b>Publicaciones:</b></p>
                            <p class="mb-0">' .count($publicaciones) . '</p>
                        </div>
                    </div>
                    <div class="text-white">
                        <h4 class="mb-1">' . $evento["Lugar"] . '</h4>
                        <h4 class="mb-1">' . $evento["fecEvento"] . '</h4>
                    </div>';
                   $output .= '
                <div class="row justify-content-center py-3">
                    <div class="col-12 col-md-6 text-center">
                        <div class="d-flex justify-content-center gap-3">
                            <button class="btn btn-participar ' . ($participando ? 'btn-outline-danger' : 'btn-outline-warning') . '" 
                                    data-action="' . ($participando ? 'salir' : 'unirse') . '"
                                    ' . (!$puedeParticipar ? 'disabled' : '') . '>
                                ' . ($participando ? 'Salir' : 'Participar') . '
                            </button>';
                        
                // Agregar botón de edición si es admin
                if ($esAdminEvento) {
                    $output .= '
                        <button class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#editarEventoModal" >
                            <i class="bi bi-gear"></i> Editar
                        </button>';
                }
                
                $output .= '
                                </div>
                                '.$mensajeFiltro.'
                            </div>
                        </div>
                    <h2 class="mt-4 mt-md-5 mb-3 mb-md-4 text-center text-md-start text-white">Publicaciones</h2>
                    <div class="row justify-content-center justify-content-md-start g-3">';

    
    foreach ($publicaciones as $publicacion) {
        $fotoSrc = $publicacion['Foto'] ? 'data:image/jpeg;base64,'.base64_encode($publicacion['Foto']) : 'img/default-post.jpg';
        $fotoPerfil = $publicacion['FotoPerfil'] ? 
            'data:image/jpeg;base64,'.base64_encode($publicacion['FotoPerfil']) : 
            'img/default-profile.png';
        
        $output .= '
            <div class="col-8 col-md-6 col-lg-4 mb-4">
                <div class="card border-white h-100">
                    <a href="Mirar_publicacion.php?idPubli='.$publicacion['idPubli'].'"><img src="'.$fotoSrc.'" class="card-img-top" style="height: 220px; width: 100%; object-fit: cover;"></a>
                    <div class="card-body">
                       <img src="'.$fotoPerfil.'" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">
                        <span>'.htmlspecialchars($publicacion['Nick']).'</span>
                    </div>
                </div>
            </div>';
    }
    
    $output .= '
                        </div>
                    </div>
                </div>
            </div>
        </div>';

    return $output;
}

function verificarFiltrosEvento($pdo, $evento, $idUsuario) {
    // 1. Si el evento no tiene filtros, cualquier usuario puede participar
    if (!$evento['Marca'] && !$evento['Modelo'] && !$evento['TipoCoche']) {
        return true;
    }
    
    // 2. Construir la consulta SQL para verificar vehículos del usuario
    $sql = "SELECT COUNT(*) FROM vehiculos WHERE idUsu = ?";
    $params = [$idUsuario];
    
    $conditions = [];
    
    if ($evento['Marca']) {
        $conditions[] = "idMarca = ?";
        $params[] = $evento['Marca'];
    }
    
    if ($evento['Modelo']) {
        $conditions[] = "Modelo = ?";
        $params[] = $evento['Modelo'];
    }
    
    if ($evento['TipoCoche']) {
        $conditions[] = "Tipo = ?";
        $params[] = $evento['TipoCoche'];
    }
    
    if (!empty($conditions)) {
        $sql .= " AND (" . implode(" AND ", $conditions) . ")";
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $count = $stmt->fetchColumn();
    
    return $count > 0;
}




function detalleUsuario($pdo, $idUsu) {
    // Consulta optimizada para contar solo seguidores aceptados
    $sqlUsuario = "SELECT u.*, p.*,
                  COUNT(DISTINCT p.idPubli) as numPublicaciones,
                  (SELECT COUNT(*) FROM seguidores WHERE idSeguido = u.idUsu AND aceptado = 1) as seguidores,
                  (SELECT COUNT(*) FROM seguidores WHERE idSeguidor = u.idUsu AND aceptado = 1) as siguiendo
           FROM usuarios u
           LEFT JOIN publicaciones p ON u.idUsu = p.idUsu
           WHERE u.idUsu = :idUsu
           GROUP BY u.idUsu";

    $stmtUsuario = $pdo->prepare($sqlUsuario);
    $stmtUsuario->execute([':idUsu' => $idUsu]);
    $usuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

    $vehiculos = obtenerVehiculosUsuario($pdo, $idUsu);
    $publicaciones = obtenerPublicacionesUsuario($pdo, $idUsu);

    if (!$usuario) {
        return '<div class="alert alert-danger">Usuario no encontrado</div>';
    }

    $perfilBase64 = base64_encode($usuario["FotoPerfil"]);
    $perfilSrc = $usuario["FotoPerfil"] ? 
                'data:image/jpeg;base64,'.$perfilBase64 : 
                'img/default-profile.png';

    $output = '
    <div class="container-fluid px-lg-5 px-md-3 px-sm-2 mt-5 z-2">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="border border-dark rounded-4 border-3 bg-dark mb-3 mx-auto p-3" style="max-width: 800px;">
                    <div class="row text-white align-items-center py-3 px-2">
                        <div class="col-12 col-md-auto text-center text-md-start mb-3 mb-md-0">
                            <img src="'.$perfilSrc.'" class="rounded-circle me-2" style="width: 100px; height: 100px; object-fit: cover;">
                        </div>
                        <div class="col-12 col-md-6">
                            <h1 class="mb-1">'.htmlspecialchars($usuario["Nick"]).'</h1>
                            <p class="mb-0">'.htmlspecialchars($usuario["Descripcion"] ?? '').'</p>
                        </div>
                          <div class="col-12 col-md-2 text-md-end">';

                       if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] == $idUsu) {
                            $output .= '<button class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#editarPerfilModal">
                                <i class="bi bi-pencil-square"></i> Editar
                            </button>';
                            }
                   
                     $output .= '</div>
                    </div>
                    <div class="row text-white text-center py-3">
                        <div class="col-4">
                            <h5 class="mb-0">'.$usuario['numPublicaciones'].'</h5>
                            <small>Publicaciones</small>
                        </div>
                        <div class="col-4">
                            <h5 class="mb-0" id="contadorSeguidores">'.$usuario['seguidores'].'</h5>
                            <small>Seguidores</small>
                        </div>
                        <div class="col-4">
                            <h5 class="mb-0">'.$usuario['siguiendo'].'</h5>
                            <small>Siguiendo</small>
                        </div>
                    </div>
                </div>

                <div class="border border-dark rounded-3 border-3 p-3 p-md-4 mx-auto mb-5" style="max-width: 800px;">
                    <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between mb-3">
                        <h2 class="mb-0">Tus Coches</h2>
                        <a href="añadir_vehiculo.php" class="btn btn-outline-dark mt-3 mt-sm-0">Añadir Vehículo</a>
                    </div>
                    <div class="row g-3">';

    if (empty($vehiculos)) {
        $output .= '<div class="col-12 text-center py-3">No hay vehículos registrados</div>';
    } else {
        foreach ($vehiculos as $vehiculo) {
            $vehiculoSrc = $vehiculo['FotoCoche'] ? 
                         'data:image/jpeg;base64,'.base64_encode($vehiculo['FotoCoche']) : 
                         'img/default-car.png';
            $output .= '
                <div class="col-6 col-md-4 text-center">
                    <img src="'.$vehiculoSrc.'" class="img-fluid" style="height: 150px; width: 150px; object-fit: cover;">
                </div>';
        }
    }

    $output .= '
                    </div>

                    <div class="d-flex flex-column flex-sm-row align-items-center mb-3">
                        <h2 class="mt-4 mt-md-5 mb-0 flex-grow-1">Tus Publicaciones</h2>
                        <a href="crear_publicacion.html" class="btn btn-outline-dark mt-3 mt-sm-4 mt-md-5 ms-0 ms-sm-3">Subir Publicación</a>
                    </div>
                    <div class="row justify-content-center justify-content-md-start g-3">';

    if (empty($publicaciones)) {
        $output .= '<div class="col-12 text-center py-3">No hay publicaciones registradas</div>';
    } else {
        foreach ($publicaciones as $publicacion) {
            $publicacionSrc = 'data:image/jpeg;base64,'.base64_encode($publicacion["Foto"]);
            $output .= '
                <div class="col-8 col-md-6 col-lg-4 text-center">
                    <a href="Mirar_publicacion.php?idPubli='.$publicacion["idPubli"].'"><img src="'.$publicacionSrc.'" class="img-fluid" style="height: 220px; width: 220px; object-fit: cover;"></a>
                </div>';
        }
    }

    $output .= '
                    </div>
                </div>
            </div>
        </div>
    </div>';

    return $output;
}

function BuscarEvento($pdo) {
    if(isset($_GET['texto']) && !empty(trim($_GET['texto']))) {
        $texto = trim($_GET['texto']);
        
        // Prevenir SQL injection
        if(strlen($texto) > 50) {
            echo '<li class="list-group-item">Búsqueda demasiado larga</li>';
            return;
        }
        
        $sql = "SELECT e.idEvento, e.Nombre, e.Descripcion, e.PerfilEvento, COUNT(eu.idUsu) AS participantes
                FROM eventos AS e
                LEFT JOIN evento_usu AS eu ON e.idEvento = eu.idEvento
                WHERE e.Nombre LIKE CONCAT(:texto, '%')
                GROUP BY e.idEvento
                ORDER BY e.Nombre
                LIMIT 5";
        
        $sentencia = $pdo->prepare($sql);
        $sentencia->execute([':texto' => $texto]);
        
        $output = '<ul class="list-group">';
        
        if($sentencia->rowCount() > 0) {
            while($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
                $imagenSrc = $fila['PerfilEvento'] ? 
                    'data:image/jpeg;base64,'.base64_encode($fila['PerfilEvento']) : 
                    'img/default-event.png';
                
                $output .= '
                <li class="list-group-item list-group-item-action d-flex align-items-center">
                    <img src="'.$imagenSrc.'" class="rounded me-2" style="width: 30px; height: 30px; object-fit: cover;">
                    <a href="detalle_evento.php?idEvento='.$fila["idEvento"].'" class="text-decoration-none text-dark flex-grow-1">
                        '.htmlspecialchars($fila["Nombre"]).'

                    </a>
                </li>';
            }
        } else {
            $output .= '<li class="list-group-item">No se encontraron eventos</li>';
        }
        
        $output .= '</ul>';
        echo $output;
    } else {
        echo '<li class="list-group-item">Ingrese un término de búsqueda</li>';
    }
}

function BuscarCrew($pdo) {
    if(isset($_GET['texto']) && !empty($_GET['texto'])) {
        $texto = $_GET['texto'];
        
        $sql = "SELECT idCrew, Nombre, Descripcion, NUsuarios
                FROM crews
                WHERE Nombre LIKE CONCAT(:texto, '%')
                ORDER BY Nombre
                LIMIT 5";
        
        $sentencia = $pdo->prepare($sql);
        $sentencia->execute([':texto' => $texto]);
        
        $output = '<ul class="list-group">';
        
        if($sentencia->rowCount() > 0) {
            while($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
                $output .= '
                <li class="list-group-item list-group-item-action">
                    <a href="#" class="text-decoration-none text-dark d-block">
                        '.htmlspecialchars($fila["Nombre"]).'
                    </a>
                </li>';
            }
        } else {
            $output .= '<li class="list-group-item">No se encontraron crews</li>';
        }
        
        $output .= '</ul>';
        echo $output;
    }
}


function devolverSesion(){
    return $_SESSION['usuario'][0];
}
    

function devolverNomUsu($pdo,$id){
    $sql = "SELECT Nick
    FROM usuarios
    WHERE idUsu =".$id;

    $sentencia = $pdo->prepare($sql);
    $sentencia->execute();
    while($fila = $sentencia->fetch(PDO::FETCH_ASSOC)){
        return $fila['Nick'];

    }
}
    

function obtenerMarcasCoche($pdo) {
    try {
        $stmt = $pdo->query("SELECT idMarca, Nombre FROM marca ORDER BY Nombre");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en obtenerMarcasCoche: " . $e->getMessage());
        return [];
    }
}

function obtenerCrewUsuario($pdo, $idUsuario) {
    try {
        // Use LEFT JOIN instead of JOIN to include users without crews
        $stmt = $pdo->prepare("SELECT c.idCrew, c.Nombre, c.Foto 
                             FROM usuarios u
                             LEFT JOIN crews c ON u.idCrew = c.idCrew
                             WHERE u.idUsu = ?");
        $stmt->execute([$idUsuario]);
        $crew = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Only return data if a crew was actually found
        if ($crew && $crew['idCrew']) {
            return $crew;
        } else {
            return null; // User has no crew
        }
    } catch (PDOException $e) {
        error_log("Error en obtenerCrewUsuario: " . $e->getMessage());
        return null;
    }
}

function obtenerEventosActivosUsuario($pdo, $idUsuario) {
    try {
        $stmt = $pdo->prepare("SELECT e.idEvento, e.Nombre 
                             FROM evento_usu eu
                             JOIN eventos e ON eu.idEvento = e.idEvento
                             WHERE eu.idUsu = ? AND e.fecEvento < NOW()");
        $stmt->execute([$idUsuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en obtenerEventosActivosUsuario: " . $e->getMessage());
        return [];
    }
}

function crearPublicacion($pdo, $datos) {
    try {
        $stmt = $pdo->prepare("INSERT INTO publicaciones 
                             (idUsu, idMarca, DescripcionPubli, Foto, idCrew, idEvento, fecPublicacion)
                             VALUES (?, ?, ?, ?, ?, ?, NOW())");
        
        return $stmt->execute([
            $datos['idUsuario'],
            $datos['idMarca'],
            $datos['descripcion'],
            $datos['fotoData'],
            $datos['idCrew'],
            $datos['idEvento']
        ]);
    } catch (PDOException $e) {
        error_log("Error en crearPublicacion: " . $e->getMessage());
        return false;
    }
}


function crearVehiculo($pdo, $idUsu) {
    header('Content-Type: application/json');
    
    if (!$idUsu) {
        echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
        exit;
    }

    $required = ['idMarca', 'idModelo', 'agno']; // Modificado
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
            exit;
        }
    }

    $idMarca = $_POST['idMarca'];
    $idModelo = $_POST['idModelo']; // Nuevo
    $agno = (int)$_POST['agno'];
    $currentYear = (int)date('Y');

    if ($agno < ($currentYear - 50) || $agno > $currentYear) {
        echo json_encode(['success' => false, 'message' => 'Año no válido']);
        exit;
    }

    $fotoData = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoData = file_get_contents($_FILES['foto']['tmp_name']);
    }

    try {
        // Obtener el idTipo del modelo
        $sqlTipo = "SELECT inTipo FROM modelovehiculo WHERE idModelos = ?";
        $stmtTipo = $pdo->prepare($sqlTipo);
        $stmtTipo->execute([$idModelo]);
        $tipo = $stmtTipo->fetch(PDO::FETCH_ASSOC);
        
        if (!$tipo) {
            throw new Exception('Modelo no encontrado');
        }

        $sql = "INSERT INTO vehiculos (idUsu, idMarca, Modelo, Agno, FotoCoche, Tipo) 
                VALUES (:idUsu, :idMarca, :modelo, :agno, :foto, :tipo)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':idUsu' => $idUsu,
            ':idMarca' => $idMarca,
            ':modelo' => $idModelo, // Ahora guardamos el idModelo
            ':agno' => $agno,
            ':foto' => $fotoData,
            ':tipo' => $tipo['inTipo'] // Añadido el tipo
        ]);

        echo json_encode(['success' => true, 'message' => 'Vehículo añadido con éxito']);
    } catch (PDOException $e) {
        error_log('Error al crear vehículo: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al guardar el vehículo']);
    }
}

function darLike($pdo) {
    // Limpiar buffer de salida
    if (ob_get_length()) ob_clean();
    
    // Forzar cabecera JSON
    header('Content-Type: application/json');
    
    try {
        if (!isset($_SESSION['usuario_id'])) {
            throw new Exception('Debes iniciar sesión');
        }

        if (!isset($_POST['idPubli'])) {
            throw new Exception('ID de publicación no recibido');
        }

        $idPubli = $_POST['idPubli'];
        $idUsu = $_SESSION['usuario_id'];

        // Verificar like existente
        $stmt = $pdo->prepare("SELECT 1 FROM likes WHERE idPubli = ? AND idUsu = ?");
        $stmt->execute([$idPubli, $idUsu]);
        
        if ($stmt->fetch()) {
            throw new Exception('Ya has dado like antes');
        }

        // Registrar like
        $pdo->beginTransaction();
        $insert = $pdo->prepare("INSERT INTO likes (idPubli, idUsu) VALUES (?, ?)");
        $insert->execute([$idPubli, $idUsu]);
        
        // Actualizar contador
        $update = $pdo->prepare("UPDATE publicaciones SET NLikes = NLikes + 1 WHERE idPubli = ?");
        $update->execute([$idPubli]);
        
        // Obtener nuevo total
        $count = $pdo->prepare("SELECT NLikes FROM publicaciones WHERE idPubli = ?");
        $count->execute([$idPubli]);
        $result = $count->fetch();
        
        $pdo->commit();

        // Retornar éxito
        return json_encode([
            'success' => true,
            'nuevoConteo' => $result['NLikes']
        ]);

    } catch (Exception $e) {
        // Revertir en caso de error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        return json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function yaDioLike($pdo, $idPubli, $idUsu) {
    // Si no hay usuario autenticado, nunca habrá dado like
    if (!$idUsu || $idUsu == 0) {
        return false;
    }
    
    $stmt = $pdo->prepare("SELECT 1 FROM likes WHERE idPubli = ? AND idUsu = ?");
    $stmt->execute([$idPubli, $idUsu]);
    return $stmt->fetch() ? true : false;
}   

function quitarLike($pdo) {
    header('Content-Type: application/json');
    
    try {
        if (!isset($_SESSION['usuario_id'])) {
            throw new Exception('Debes iniciar sesión');
        }

        if (!isset($_POST['idPubli'])) {
            throw new Exception('ID de publicación no recibido');
        }

        $idPubli = $_POST['idPubli'];
        $idUsu = $_SESSION['usuario_id'];

        // Verificar si existe el like
        $stmt = $pdo->prepare("SELECT 1 FROM likes WHERE idPubli = ? AND idUsu = ?");
        $stmt->execute([$idPubli, $idUsu]);
        
        if (!$stmt->fetch()) {
            throw new Exception('No has dado like a esta publicación');
        }

        // Quitar like
        $pdo->beginTransaction();
        $delete = $pdo->prepare("DELETE FROM likes WHERE idPubli = ? AND idUsu = ?");
        $delete->execute([$idPubli, $idUsu]);
        
        // Actualizar contador
        $update = $pdo->prepare("UPDATE publicaciones SET NLikes = NLikes - 1 WHERE idPubli = ?");
        $update->execute([$idPubli]);
        
        // Obtener nuevo total
        $count = $pdo->prepare("SELECT NLikes FROM publicaciones WHERE idPubli = ?");
        $count->execute([$idPubli]);
        $result = $count->fetch();
        
        $pdo->commit();

        return json_encode([
            'success' => true,
            'nuevoConteo' => $result['NLikes']
        ]);

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        return json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}


function obtenerCantidadComentarios($pdo, $idPubli) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM comentario WHERE idPub = ?");
    $stmt->execute([$idPubli]);
    return $stmt->fetchColumn();
}

function obtenerComentariosHTML($pdo, $idPubli) {
    try {
        $idUsuarioActual = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null;
        
        $stmt = $pdo->prepare("SELECT c.*, u.Nick, u.FotoPerfil 
                              FROM comentario c
                              JOIN usuarios u ON u.idUsu = c.idUsu
                              WHERE c.idPub = ?
                              ORDER BY c.fecCom ASC");
        $stmt->execute([$idPubli]);
        $comentarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($comentarios)) {
            return json_encode([
                'success' => true,
                'html' => '<div class="text-center text-muted py-3">No hay comentarios aún</div>',
                'count' => 0
            ]);
        }
        
        $html = '';
        foreach ($comentarios as $comentario) {
            $fotoPerfil = $comentario['FotoPerfil'] ? 
                         'data:image/jpeg;base64,'.base64_encode($comentario['FotoPerfil']) : 
                         'ruta/a/imagen/default.jpg';
            $fecha = date('d/m/Y H:i', strtotime($comentario['fecCom']));
            $nick = htmlspecialchars($comentario['Nick']);
            $texto = htmlspecialchars($comentario['texto']);
            
            // Verificar si el comentario es del usuario actual
            $esPropio = ($comentario['idUsu'] == $idUsuarioActual);

            $html .= '<div class="card comment-card" data-id="'.$comentario['idComentario'].'">
                <div class="card-body p-3">
                    <div class="d-flex">
                        <img src="'.$fotoPerfil.'" 
                             class="comment-avatar"
                             alt="Foto perfil">
                        <div class="comment-content flex-grow-1">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="card-title mb-0 fw-bold">'.$nick.'</h6>
                                <small class="text-muted">'.$fecha.'</small>
                            </div>
                            <p class="card-text mt-2 mb-0">'.$texto.'</p>
                        </div>';
            
            // Agregar botón de eliminar solo si es del usuario actual
            if ($esPropio) {
                $html .= '<button class="btn btn-sm btn-outline-danger delete-comment-btn ms-2" id="propio"
                              data-comment-id="'.$comentario['idComentario'].'">
                              <i class="bi bi-trash"></i>
                          </button>';
            }
            
            $html .= '</div>
                </div>
            </div>';
        }

        return json_encode([
            'success' => true,
            'html' => $html,
            'count' => count($comentarios)
        ]);
    } catch (Exception $e) {
        error_log("Error obtenerComentarios: ".$e->getMessage());
        return json_encode([
            'success' => false,
            'error' => 'Error al cargar comentarios'
        ]);
    }
}

function agregarComentario($pdo) {
    if (!isset($_SESSION['usuario_id'])) {
        return json_encode(['success' => false, 'error' => 'Debes iniciar sesión']);
    }

    if (empty($_POST['idPubli']) || empty($_POST['texto'])) {
        return json_encode(['success' => false, 'error' => 'Datos incompletos']);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO comentario (idPub, idUsu, texto, fecCom) VALUES (?, ?, ?, NOW())");
        $stmt->execute([
            $_POST['idPubli'],
            $_SESSION['usuario_id'],
            trim($_POST['texto'])
        ]);
        
        return json_encode(['success' => true]);
    } catch (Exception $e) {
        return json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

function devolverChat($pdo,$idCR){

    if(!isset($idCR)){
        echo "Tienes que unirte a la crew para poder hablar";
        exit;
    }

    $sql="SELECT * FROM chat_crew WHERE idCrew ='".$idCR."'";
    $sentencia = $pdo->prepare($sql);
    $sentencia->execute();
    
    while($fila=$sentencia->fetch(PDO::FETCH_ASSOC)){
        
        $nomUsu=devolverNomUsu($pdo,$fila['idUsu']);
        $tex=$fila['texto'];
        ?>
            <div class="mb-3">
              <div class="d-flex align-items-center mb-1">
                <strong><?=$nomUsu?></strong>
              </div>
              <p class="mb-0 ps-4"><?=$tex?></p>
            </div>

        <?php
    }
    
}




function mandarmsj($pdo,$idCR){

    if(!isset($idCR)){
        echo "Tienes que unirte a la crew para poder hablar";
        exit;
    }

    $sql = "INSERT INTO chat_crew (idUsu, idCrew, texto) 
    VALUES (:idUsu, :idCrew, :texto)";

    var_dump($_GET['text']);


    $stmt = $pdo->prepare($sql);
    $stmt->execute([
    ":idUsu" => $_SESSION['usuario_id'],
    ":idCrew" => $idCR,
    ":texto" => $_GET['text']

    ]);
    echo "ok";

            
}
    
function usuarioParticipaEvento($pdo, $idEvento, $idUsuario) {
    $sql = "SELECT 1 FROM evento_usu WHERE idEvento = ? AND idUsu = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idEvento, $idUsuario]);
    return $stmt->fetch() ? true : false;
}

function unirseEvento($pdo, $idEvento, $idUsuario) {
    try {
        $pdo->beginTransaction();
        
        if (usuarioParticipaEvento($pdo, $idEvento, $idUsuario)) {
            throw new Exception('Ya estás participando en este evento');
        }
        
        $sql = "INSERT INTO evento_usu (idEvento, idUsu) VALUES (?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento, $idUsuario]);
        
        // Eliminamos la actualización del contador ya que lo calcularemos con COUNT
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error en unirseEvento: " . $e->getMessage());
        return false;
    }
}

function salirEvento($pdo, $idEvento, $idUsuario) {
    try {
        $pdo->beginTransaction();
        
        if (!usuarioParticipaEvento($pdo, $idEvento, $idUsuario)) {
            throw new Exception('No estás participando en este evento');
        }
        
        $sql = "DELETE FROM evento_usu WHERE idEvento = ? AND idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento, $idUsuario]);
        
        // Eliminamos la actualización del contador ya que lo calcularemos con COUNT
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Error en salirEvento: " . $e->getMessage());
        return false;
    }
}

function manejarParticipacionEvento($pdo) {
    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
        exit;
    }

    $idEvento = $_POST['idEvento'] ?? '';
    $idUsuario = $_SESSION['usuario_id'];
    $respuesta = ['success' => false];
    
    if ($_POST['accionEvento'] == 'unirse') {
        $respuesta['success'] = unirseEvento($pdo, $idEvento, $idUsuario);
        $respuesta['action'] = 'salir';
    } elseif ($_POST['accionEvento'] == 'salir') {
        $respuesta['success'] = salirEvento($pdo, $idEvento, $idUsuario);
        $respuesta['action'] = 'unirse';
    }
    
    // Obtenemos el nuevo conteo de participantes
    $respuesta['nuevoConteo'] = obtenerParticipantesEvento($pdo, $idEvento);
    
    header('Content-Type: application/json');
    echo json_encode($respuesta);
    exit;
}


function obtenerParticipantesEvento($pdo, $idEvento) {
    $sql = "SELECT COUNT(*) as total FROM evento_usu WHERE idEvento = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idEvento]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0;
}

function obtenerDatosUsuario($pdo, $idUsuario) {
    $sql = "SELECT u.*, 
                   COUNT(DISTINCT p.idPubli) as numPublicaciones,
                   (SELECT COUNT(*) FROM seguidores WHERE idSeguido = u.idUsu AND aceptado = 1) as seguidores,
                   (SELECT COUNT(*) FROM seguidores WHERE idSeguidor = u.idUsu AND aceptado = 1) as siguiendo
            FROM usuarios u
            LEFT JOIN publicaciones p ON u.idUsu = p.idUsu
            WHERE u.idUsu = ?
            GROUP BY u.idUsu";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function puedeVerContenido($pdo, $idUsuarioPerfil, $idUsuarioVisitante) {
    // Si es el propio usuario, puede ver todo
    if ($idUsuarioPerfil == $idUsuarioVisitante) {
        return true;
    }
    
    // Obtenemos si la cuenta es privada
    $sql = "SELECT privada FROM usuarios WHERE idUsu = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuarioPerfil]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Si la cuenta no es privada, puede ver todo
    if (!$usuario || !$usuario['privada']) {
        return true;
    }
    
    // Si es privada, verificamos si el visitante sigue al usuario
    $sql = "SELECT 1 FROM seguidores WHERE idSeguidor = ? AND idSeguido = ? AND aceptado = 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuarioVisitante, $idUsuarioPerfil]);
    
    return $stmt->fetch() ? true : false;
}

function obtenerPublicacionesUsuario($pdo, $idUsuario) {
    $sql = "SELECT idPubli, Foto, DescripcionPubli, fecPublicacion 
            FROM publicaciones 
            WHERE idUsu = ? 
            ORDER BY fecPublicacion DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function yaSigueUsuario($pdo, $idSeguidor, $idSeguido) {
    $sql = "SELECT aceptado FROM seguidores WHERE idSeguidor = ? AND idSeguido = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idSeguidor, $idSeguido]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $resultado ? ($resultado['aceptado'] == 1 ? 'siguiendo' : 'pendiente') : false;
}

function seguirUsuario($pdo) {
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idUsuario'])) {
        return json_encode(['success' => false]);
    }
    
    $idSeguidor = $_SESSION['usuario_id'];
    $idSeguido = $_GET['idUsuario'];
    
    try {
        $sql = "SELECT privada FROM usuarios WHERE idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idSeguido]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $aceptado = $usuario && $usuario['privada'] ? 0 : 1;
        
        $sql = "INSERT INTO seguidores (idSeguidor, idSeguido, aceptado) VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE aceptado = VALUES(aceptado)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idSeguidor, $idSeguido, $aceptado]);
        
        return json_encode([
            'success' => true, 
            'pendiente' => !$aceptado,
            'textoBoton' => $aceptado ? 'Dejar de seguir' : 'Pendiente'
        ]);
    } catch (PDOException $e) {
        return json_encode(['success' => false]);
    }
}

function dejarSeguirUsuario($pdo) {
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idUsuario'])) {
        return json_encode(['success' => false]);
    }
    
    try {
        $sql = "DELETE FROM seguidores WHERE idSeguidor = ? AND idSeguido = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_SESSION['usuario_id'], $_GET['idUsuario']]);
        return json_encode(['success' => true]);
    } catch (PDOException $e) {
        return json_encode(['success' => false]);
    }
}
    

function mostrarVehiculosUsuario($pdo, $idUsuario) {
    $vehiculos = obtenerVehiculosUsuario($pdo, $idUsuario);
    
    $output = '
                <h2 class="mb-4">Vehículos</h2>
                <div class="row justify-content-center g-3">';
    
    if (empty($vehiculos)) {
        $output .= '<div class="col-12 text-center py-3">No hay vehículos registrados</div>';
    } else {
        foreach ($vehiculos as $vehiculo) {
            $fotoVehiculo = $vehiculo['FotoCoche'] ? 
                          'data:image/jpeg;base64,'.base64_encode($vehiculo['FotoCoche']) : 
                          'img/default-car.png';
            $output .= '
                <div class="col-8 col-md-6 col-lg-4 text-center">
                    <img src="'.$fotoVehiculo.'" 
                         class="img-fluid" 
                         style="height: 220px; width: 220px; object-fit: cover;">
                </div>';
        }
    }
    
    $output .= '</div>';
    
    return $output;
}

function obtenerVehiculosUsuario($pdo, $idUsuario) {
    $sql = "SELECT * FROM vehiculos WHERE idUsu = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function obtenerSolicitudesPendientes($pdo, $idUsuario) {
    $sql = "SELECT s.idSeguidor, u.Nick, u.FotoPerfil 
            FROM seguidores s
            JOIN usuarios u ON s.idSeguidor = u.idUsu
            WHERE s.idSeguido = ? AND s.aceptado = 0";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



function generarHtmlSolicitudes($pdo) {
    if (!isset($_SESSION['usuario_id'])) {
        return '<li><span class="dropdown-item text-muted">Inicia sesión para ver solicitudes</span></li>';
    }

    $solicitudes = obtenerSolicitudesPendientes($pdo, $_SESSION['usuario_id']);
    
    if (empty($solicitudes)) {
        return '<li><span class="dropdown-item text-muted">No hay solicitudes pendientes</span></li>';
    }

    $html = '';
    foreach ($solicitudes as $solicitud) {
        $fotoPerfil = $solicitud['FotoPerfil'] ? 
                     'data:image/jpeg;base64,'.base64_encode($solicitud['FotoPerfil']) : 
                     'img/default-profile.png';
        
        $html .= '
        <li class="solicitud-item">
            <div class="solicitud-info">
                <img src="'.$fotoPerfil.'" class="solicitud-img" alt="Foto perfil">
                <span title="'.htmlspecialchars($solicitud['Nick']).'">'.htmlspecialchars($solicitud['Nick']).'</span>
            </div>
            <div class="solicitud-botones">
                <button class="btn btn-success btn-accion aceptar-btn" 
                        data-action="aceptar" 
                        data-id="'.$solicitud['idSeguidor'].'">
                    <i class="bi bi-check-lg"></i>
                    <span class="d-none d-sm-inline">Aceptar</span>
                </button>
                <button class="btn btn-danger btn-accion rechazar-btn" 
                        data-action="rechazar" 
                        data-id="'.$solicitud['idSeguidor'].'">
                    <i class="bi bi-x-lg"></i>
                    <span class="d-none d-sm-inline">Rechazar</span>
                </button>
            </div>
        </li>';
    }
    
    return $html;
}


function manejarSolicitud($pdo) {
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idSeguidor']) || !isset($_GET['tipo'])) {
        return json_encode(['success' => false]);
    }

    $idSeguido = $_SESSION['usuario_id'];
    $idSeguidor = $_GET['idSeguidor'];
    $tipo = $_GET['tipo'];

    try {
        $pdo->beginTransaction();
        
        if ($tipo === 'aceptar') {
            // 1. Actualizar estado a aceptado
            $sql = "UPDATE seguidores SET aceptado = 1 
                    WHERE idSeguidor = ? AND idSeguido = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idSeguidor, $idSeguido]);
            
        } else {
            // Eliminar la solicitud rechazada
            $sql = "DELETE FROM seguidores 
                    WHERE idSeguidor = ? AND idSeguido = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idSeguidor, $idSeguido]);
        }
        
        // Verificar si quedan solicitudes pendientes
        $sqlPendientes = "SELECT COUNT(*) FROM seguidores WHERE idSeguido = ? AND aceptado = 0";
        $stmtPendientes = $pdo->prepare($sqlPendientes);
        $stmtPendientes->execute([$idSeguido]);
        $pendientes = $stmtPendientes->fetchColumn() > 0;
        
        $pdo->commit();
        
        return json_encode([
            'success' => true,
            'pendientes' => $pendientes
        ]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        return json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

function tieneSolicitudesPendientes($pdo, $idUsuario) {
    if (!$idUsuario) return false;
    
    $sql = "SELECT COUNT(*) FROM seguidores 
            WHERE idSeguido = ? AND aceptado = 0";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario]);
    return $stmt->fetchColumn() > 0;
}



function manejarReporte($pdo) {
    if (!isset($_SESSION['usuario_id'])) {
        return ['success' => false, 'message' => 'Debes iniciar sesión para reportar'];
    }

    $required = ['tipo', 'idReportado', 'descripcion'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            return ['success' => false, 'message' => 'Faltan datos obligatorios'];
        }
    }

    $tipo = $_POST['tipo'];
    $idReportado = $_POST['idReportado'];
    $descripcion = htmlspecialchars(trim($_POST['descripcion']));
    $idNotificador = $_SESSION['usuario_id'];

    try {
        $sql = "INSERT INTO reportes (UsuNotificador, UsuReportado, crewReportada, EventoReportado, Descripcion) 
                VALUES (:notificador, :usuario, :crew, :evento, :descripcion)";
        
        $stmt = $pdo->prepare($sql);
        
        // Configurar parámetros según el tipo de reporte
        $params = [
            ':notificador' => $idNotificador,
            ':descripcion' => $descripcion,
            ':usuario' => null,
            ':crew' => null,
            ':evento' => null
        ];

        switch ($tipo) {
            case 'usuario':
                $params[':usuario'] = $idReportado;
                break;
            case 'crew':
                $params[':crew'] = $idReportado;
                break;
            case 'evento':
                $params[':evento'] = $idReportado;
                break;
            default:
                return ['success' => false, 'message' => 'Tipo de reporte no válido'];
        }

        $stmt->execute($params);
        
        return ['success' => true, 'message' => 'Reporte enviado correctamente'];
    } catch (PDOException $e) {
        error_log('Error al reportar: ' . $e->getMessage());
        return ['success' => false, 'message' => 'Error al procesar el reporte'];
    }
}

function obtenerDatosUsuarioActual($pdo) {
    if (!isset($_SESSION['usuario_id'])) {
        return ['success' => false, 'message' => 'No autenticado'];
    }

    $sql = "SELECT Nick, Descripcion, privada FROM usuarios WHERE idUsu = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        return ['success' => false, 'message' => 'Usuario no encontrado'];
    }

    return ['success' => true, 'usuario' => $usuario];
}

function actualizarPerfilUsuario($pdo) {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
        exit;
    }

    $required = ['editNick'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['success' => false, 'message' => 'El nombre de usuario es obligatorio']);
            exit;
        }
    }

    $nick = htmlspecialchars(trim($_POST['editNick']));
    $descripcion = isset($_POST['editDescripcion']) ? htmlspecialchars(trim($_POST['editDescripcion'])) : null;
    $privada = isset($_POST['editPrivada']) ? 1 : 0;

    // Verificar si el nick ya existe (excluyendo al usuario actual)
    $sqlCheck = "SELECT idUsu FROM usuarios WHERE Nick = ? AND idUsu != ?";
    $stmtCheck = $pdo->prepare($sqlCheck);
    $stmtCheck->execute([$nick, $_SESSION['usuario_id']]);
    
    if ($stmtCheck->fetch()) {
        echo json_encode(['success' => false, 'message' => 'El nombre de usuario ya está en uso']);
        exit;
    }

    // Procesar imagen si se subió
    $imagenData = null;
    if (isset($_FILES['editFoto']) && $_FILES['editFoto']['error'] === UPLOAD_ERR_OK) {
        // Validar tipo de imagen
        $mimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($fileInfo, $_FILES['editFoto']['tmp_name']);
        finfo_close($fileInfo);

        if (!in_array($mime, $mimeTypes)) {
            echo json_encode(['success' => false, 'message' => 'Solo se permiten imágenes JPEG, PNG o GIF']);
            exit;
        }

        if ($_FILES['editFoto']['size'] > 2097152) {
            echo json_encode(['success' => false, 'message' => 'La imagen no debe superar los 2MB']);
            exit;
        }

        $imagenData = file_get_contents($_FILES['editFoto']['tmp_name']);
    }

    try {
        // Construir la consulta SQL según si hay imagen o no
        if ($imagenData) {
            $sql = "UPDATE usuarios SET Nick = ?, Descripcion = ?, privada = ?, FotoPerfil = ? WHERE idUsu = ?";
            $params = [$nick, $descripcion, $privada, $imagenData, $_SESSION['usuario_id']];
        } else {
            $sql = "UPDATE usuarios SET Nick = ?, Descripcion = ?, privada = ? WHERE idUsu = ?";
            $params = [$nick, $descripcion, $privada, $_SESSION['usuario_id']];
        }

        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute($params);

        if ($success) {
            // Actualizar el nombre en la sesión si cambió
            $_SESSION['usuario_nombre'] = $nick;
            echo json_encode(['success' => true, 'message' => 'Perfil actualizado correctamente']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se realizaron cambios']);
        }
    } catch (PDOException $e) {
        error_log('Error al actualizar perfil: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el perfil']);
    }
}

function eliminarCuentaUsuario($pdo) {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['usuario_id']) || empty($_POST['password'])) {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        exit;
    }

    // Verificar contraseña
    $sql = "SELECT contra FROM usuarios WHERE idUsu = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario || md5($_POST['password']) !== $usuario['contra']) {
        echo json_encode(['success' => false, 'message' => 'Contraseña incorrecta']);
        exit;
    }

    try {
        $pdo->beginTransaction();

        // Eliminar todas las relaciones y datos del usuario
        // (Asegúrate de que todas estas tablas tengan ON DELETE CASCADE configurado)
        $sqlDelete = "DELETE FROM usuarios WHERE idUsu = ?";
        $stmtDelete = $pdo->prepare($sqlDelete);
        $stmtDelete->execute([$_SESSION['usuario_id']]);

        $pdo->commit();

        // Limpiar sesión
        session_unset();
        session_destroy();

        echo json_encode(['success' => true, 'message' => 'Cuenta eliminada correctamente']);
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('Error al eliminar cuenta: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al eliminar la cuenta']);
    }
}

function obtenerEventosUsuarioParticipa($pdo, $idUsuario) {
    error_log("Llamada a obtenerEventosUsuarioParticipa con idUsuario: $idUsuario");
    try {
        $sql = "SELECT e.* 
                FROM eventos e
                JOIN evento_usu eu ON e.idEvento = eu.idEvento
                WHERE eu.idUsu = :idUsuario
                ORDER BY e.fecEvento ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        error_log("Resultados obtenidos: " . count($resultados));
        return $resultados;
    } catch (PDOException $e) {
        error_log("Error en obtenerEventosUsuarioParticipa: " . $e->getMessage());
        return [];
    }
}

function perteneceACrew($pdo, $idUsuario, $idCrew) {
    $sql = "SELECT 1 FROM usuarios WHERE idUsu = ? AND idCrew = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idUsuario, $idCrew]);
    return $stmt->fetch() ? true : false;
}

// Función para obtener el texto del botón de unirse/salir
function obtenerTextoBotonCrew($pdo, $idUsuario, $idCrew) {
    if (!isset($idUsuario)) {
        return "Unirse"; // Si no está logueado
    }
    
    if (perteneceACrew($pdo, $idUsuario, $idCrew)) {
        return "Salir";
    } else {
        return "Unirse";
    }
}

// Función para manejar unirse/salir de una crew
function manejarCrew($pdo) {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idCrewpag'])) {
        return json_encode(['success' => false, 'message' => 'Datos incompletos']);
    }

    $idUsuario = $_SESSION['usuario_id'];
    $idCrew = $_GET['idCrewpag'];
    
    try {
        $pdo->beginTransaction();
        
        if (perteneceACrew($pdo, $idUsuario, $idCrew)) {
            // Salir de la crew
            $sql = "UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idUsuario]);
            
            // Actualizar contador de miembros
            $sql = "UPDATE crews SET NUsuarios = NUsuarios - 1 WHERE idCrew = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idCrew]);
            
            $mensaje = "Has salido de la crew";
            $pertenece = false;
            $textoBoton = "Unirse";
        } else {
            // Unirse a la crew
            // Primero verificar si ya está en otra crew
            $sql = "SELECT idCrew FROM usuarios WHERE idUsu = ? AND idCrew IS NOT NULL";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idUsuario]);
            
            if ($stmt->fetch()) {
                throw new Exception('Ya perteneces a otra crew');
            }
            
            $sql = "UPDATE usuarios SET idCrew = ? WHERE idUsu = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idCrew, $idUsuario]);
            
            // Actualizar contador de miembros
            $sql = "UPDATE crews SET NUsuarios = NUsuarios + 1 WHERE idCrew = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$idCrew]);
            
            $mensaje = "Te has unido a la crew";
            $pertenece = true;
            $textoBoton = "Salir";
        }
        
        $pdo->commit();
        
        return json_encode([
            'success' => true,
            'message' => $mensaje,
            'textoBoton' => $textoBoton,
            'pertenece' => $pertenece,
            'numMiembros' => obtenerNumeroMiembrosCrew($pdo, $idCrew)
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        return json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// Función para obtener el número de miembros de una crew
function obtenerNumeroMiembrosCrew($pdo, $idCrew) {
    $sql = "SELECT NUsuarios FROM crews WHERE idCrew = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idCrew]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? $result['NUsuarios'] : 0;
}

// Función mejorada para mostrar datos de la crew
function mostrarDatosCrew($pdo, $idC) {
    $sql = "SELECT c.*, u.Nick as adminNick 
            FROM crews c
            LEFT JOIN usuarios u ON c.idAdmin = u.idUsu
            WHERE c.idCrew = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idC]);
    
    if ($crew = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $fotoPerfil = $crew["Foto"] ? 'data:image/jpeg;base64,'.base64_encode($crew["Foto"]) : 'img/default-crew.jpg';
        
        echo '
        <div class="col-12 col-md-auto text-center text-md-start mb-3 mb-md-0">
            <img src="'.$fotoPerfil.'" class="img-fluid mx-auto d-block" style="height: 150px; width: 150px;">
        </div>
        <div class="col-12 col-md-4 text-center text-md-start mb-3 mb-md-0">
            <h1 class="mb-1">'.$crew['Nombre'].'</h1>
            <p class="mb-0">'.$crew['Descripcion'].'</p>
            <p class="mb-0"><small>Creada por: '.htmlspecialchars($crew['adminNick']).'</small></p>
        </div>
        <div class="col-6 col-md-3 text-center">
            <p class="mb-1"><b>Miembros:</b></p>
            <p class="mb-0" id="contadorMiembros">'.$crew['NUsuarios'].'</p>
        </div>
        <div class="col-6 col-md-2 text-center">
            <p class="mb-1"><b>Publicaciones:</b></p>
            <p class="mb-0">'.obtenerNumeroPublicacionesCrew($pdo, $idC).'</p>
        </div>';
    }
}

// Función para obtener número de publicaciones de una crew
function obtenerNumeroPublicacionesCrew($pdo, $idCrew) {
    $sql = "SELECT COUNT(*) FROM publicaciones WHERE idCrew = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idCrew]);
    return $stmt->fetchColumn();
}


// Función mejorada para mostrar publicaciones de la crew
function mostrarPublicacionesCrew($pdo, $idC) {
    $sql = "SELECT p.*, u.Nick, u.FotoPerfil 
            FROM publicaciones p
            JOIN usuarios u ON p.idUsu = u.idUsu
            WHERE p.idCrew = ?
            ORDER BY p.fecPublicacion DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idC]);
    
    $output = '';
    
    if ($stmt->rowCount() == 0) {
        $output = '<div class="col-12 text-center py-3">No hay publicaciones en esta crew</div>';
    } else {
        $output .= '<div class="row justify-content-center justify-content-md-start g-3">';
        
        while($publicacion = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $fotoSrc = $publicacion['Foto'] ? 'data:image/jpeg;base64,'.base64_encode($publicacion['Foto']) : 'img/default-post.jpg';
            $fotoPerfil = $publicacion['FotoPerfil'] ? 
                'data:image/jpeg;base64,'.base64_encode($publicacion['FotoPerfil']) : 
                'img/default-profile.png';
            
            $output .= '
            <div class="col-8 col-md-6 col-lg-4 mb-4">
                <div class="card border-white h-100">
                     <a href="Mirar_publicacion.php?idPubli='.$publicacion["idPubli"].'"><img src="'.$fotoSrc.'" class="card-img-top" style="height: 220px; width: 100%; object-fit: cover;"></a>
                    <div class="card-body">
                         <img src="'.$fotoPerfil.'" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">
                        <span>'.htmlspecialchars($publicacion['Nick']).'</span>
                    </div>
                </div>
            </div>';
        }
        
        $output .= '</div>';
    }
    
    return $output;
}

function mostrarChatCrew($pdo) {
    if (!isset($_GET['idCrew'])) {
        return "<div class='p-3 text-center'>ID de crew no especificado</div>";
    }

    $idCrew = $_GET['idCrew'];
    $idUsuario = $_SESSION['usuario_id'] ?? null;

    // Verificar que el usuario pertenece a la crew
    if (!$idUsuario || !perteneceACrew($pdo, $idUsuario, $idCrew)) {
        return "<div class='p-3 text-center'>Únete a la crew para participar en el chat</div>";
    }

    // Verificar si el usuario es admin de la crew
    $esAdmin = false;
    $sqlAdmin = "SELECT idAdmin FROM crews WHERE idCrew = ?";
    $stmtAdmin = $pdo->prepare($sqlAdmin);
    $stmtAdmin->execute([$idCrew]);
    $crew = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
    $esAdmin = ($crew && $crew['idAdmin'] == $idUsuario);

    $sql = "SELECT c.*, u.Nick, u.FotoPerfil 
            FROM chat_crew c
            JOIN usuarios u ON c.idUsu = u.idUsu
            WHERE c.idCrew = ?
            ORDER BY c.fecMsj ASC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idCrew]);
    
    $output = '';
    
    while($mensaje = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $esPropio = ($mensaje['idUsu'] == $idUsuario) ? 'propio' : '';
        $fotoPerfil = $mensaje['FotoPerfil'] ? 
            'data:image/jpeg;base64,'.base64_encode($mensaje['FotoPerfil']) : 
            'img/default-profile.png';
        
        $output .= '
        <div class="mensaje-chat '.$esPropio.'">
            <div class="d-flex align-items-center mb-1">
                <img src="'.$fotoPerfil.'" class="rounded-circle me-2" style="width: 25px; height: 25px;">
                <div class="nombre-usuario">'.htmlspecialchars($mensaje['Nick']).'</div>
                '.($esPropio || $esAdmin ? '<button class="btn btn-sm btn-danger btn-borrar-mensaje ms-2" data-id-mensaje="'.$mensaje['idMsj'].'">
                    <i class="bi bi-trash">Borrar</i>
                </button>' : '').'
            </div>
            <div class="texto-mensaje">'.htmlspecialchars($mensaje['texto']).'</div>
            <div class="hora-mensaje">'.date('H:i', strtotime($mensaje['fecMsj'])).'</div>
        </div>';
    }
    
    return $output ?: '<div class="p-3 text-center">No hay mensajes en el chat</div>';
}


// Función para enviar mensaje al chat de la crew
function enviarMensajeCrew($pdo) {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idCrew']) || empty($_GET['texto'])) {
        return json_encode(['success' => false, 'message' => 'Datos incompletos']);
    }

    $idUsuario = $_SESSION['usuario_id'];
    $idCrew = $_GET['idCrew'];
    $texto = htmlspecialchars(trim($_GET['texto']));

    // Verificar que el usuario pertenece a la crew
    if (!perteneceACrew($pdo, $idUsuario, $idCrew)) {
        return json_encode(['success' => false, 'message' => 'No perteneces a esta crew']);
    }

    try {
        $sql = "INSERT INTO chat_crew (idUsu, idCrew, texto, fecMsj) VALUES (?, ?, ?, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idUsuario, $idCrew, $texto]);
        
        return json_encode(['success' => true]);
    } catch (PDOException $e) {
        return json_encode(['success' => false, 'message' => 'Error al enviar mensaje']);
    }
}

function borrarMensajeChat($pdo) {
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idMensaje']) || !isset($_GET['idCrew'])) {
        return ['success' => false, 'message' => 'Datos incompletos'];
    }

    $idMensaje = $_GET['idMensaje'];
    $idUsuario = $_SESSION['usuario_id'];
    $idCrew = $_GET['idCrew'];

    try {
        // Verificar si el usuario es admin de la crew
        $sqlAdmin = "SELECT idAdmin FROM crews WHERE idCrew = ?";
        $stmtAdmin = $pdo->prepare($sqlAdmin);
        $stmtAdmin->execute([$idCrew]);
        $crew = $stmtAdmin->fetch(PDO::FETCH_ASSOC);
        $esAdmin = ($crew && $crew['idAdmin'] == $idUsuario);

        // Verificar que el mensaje pertenece a la crew
        $sql = "SELECT idMsj, idUsu FROM chat_crew WHERE idMsj = ? AND idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idMensaje, $idCrew]);
        $mensaje = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mensaje) {
            return ['success' => false, 'message' => 'Mensaje no encontrado'];
        }

        // Solo permitir borrar si es el autor o admin
        if ($mensaje['idUsu'] != $idUsuario && !$esAdmin) {
            return ['success' => false, 'message' => 'No tienes permiso para borrar este mensaje'];
        }

        // Borrar el mensaje
        $sql = "DELETE FROM chat_crew WHERE idMsj = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idMensaje]);

        return ['success' => true, 'message' => 'Mensaje borrado correctamente'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al borrar el mensaje'];
    }
}

// Función para verificar pertenencia a la crew (para AJAX)
function verificarPertenenciaCrew($pdo) {
    if (!isset($_SESSION['usuario_id']) || !isset($_GET['idCrew'])) {
        return json_encode(['pertenece' => false]);
    }

    $pertenece = perteneceACrew($pdo, $_SESSION['usuario_id'], $_GET['idCrew']);
    return json_encode(['pertenece' => $pertenece]);
}

function obtenerDatosCrew($pdo, $idCrew) {
    try {
        $sql = "SELECT * FROM crews WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        $crew = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($crew) {
            return [
                'success' => true,
                'crew' => $crew
            ];
        } else {
            return ['success' => false, 'message' => 'Crew no encontrada'];
        }
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al obtener datos de la crew'];
    }
}

function obtenerMiembrosCrew($pdo, $idCrew) {
    try {
        $sql = "SELECT u.idUsu, u.Nick, u.FotoPerfil 
                FROM usuarios u 
                WHERE u.idCrew = ? ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        $miembros = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Convertir FotoPerfil a base64 si existe
        foreach ($miembros as &$miembro) {

            if ($miembro['FotoPerfil']) {
                $miembro['FotoPerfil'] = base64_encode($miembro['FotoPerfil']);
            }
        }
        
        return [
            'success' => true,
            'miembros' => $miembros
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al obtener miembros'];
    }
}

function obtenerPublicacionesCrewAdmin($pdo, $idCrew) {
    try {
        $sql = "SELECT p.*, u.Nick, u.FotoPerfil 
                FROM publicaciones p
                JOIN usuarios u ON p.idUsu = u.idUsu
                WHERE p.idCrew = ?
                ORDER BY p.fecPublicacion DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        $publicaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Convertir imágenes a base64
        foreach ($publicaciones as &$publi) {
            $publi['Foto'] = base64_encode($publi['Foto']);
            if ($publi['FotoPerfil']) {
                $publi['FotoPerfil'] = base64_encode($publi['FotoPerfil']);
            }
        }
        
        return [
            'success' => true,
            'publicaciones' => $publicaciones
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al obtener publicaciones'];
    }
}

function expulsarMiembroCrew($pdo, $idCrew, $idUsuario) {
    try {
        $pdo->beginTransaction();
        
        // 1. Quitar al usuario de la crew
        $sql = "UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idUsuario]);
        
        // 2. Actualizar contador de miembros
        $sql = "UPDATE crews SET NUsuarios = NUsuarios - 1 WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        // 3. Obtener nuevo conteo
        $sql = "SELECT NUsuarios FROM crews WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $pdo->commit();
        
        return [
            'success' => true,
            'nuevoConteo' => $result['NUsuarios']
        ];
    } catch (PDOException $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => 'Error al expulsar miembro'];
    }
}

function eliminarPublicacionCrew($pdo, $idPublicacion, $idCrew) {
    try {
        $pdo->beginTransaction();
        
        // 1. Verificar que la publicación pertenece a la crew
        $sql = "SELECT idPubli FROM publicaciones WHERE idPubli = ? AND idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idPublicacion, $idCrew]);
        
        if (!$stmt->fetch()) {
            throw new Exception('La publicación no pertenece a esta crew');
        }
        
        // 2. Eliminar la publicación (quitando su relación con la crew)
        $sql = "UPDATE publicaciones SET idCrew = NULL WHERE idPubli = ? AND idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idPublicacion, $idCrew]);
        
        $pdo->commit();
        
        return ['success' => true];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function actualizarCrew($pdo) {
    header('Content-Type: application/json');
    
    $response = ['success' => false, 'message' => 'Error desconocido'];
    
    try {
        if (!isset($_SESSION['usuario_id'])) {
            throw new Exception('Debes iniciar sesión');
        }
        
        if (empty($_POST['idCrew'])) {
            throw new Exception('ID de crew no especificado');
        }
        
        $idCrew = $_POST['idCrew'];
        
        // Verificar permisos de admin
        $sql = "SELECT idAdmin FROM crews WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        $crew = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$crew || $crew['idAdmin'] != $_SESSION['usuario_id']) {
            throw new Exception('No tienes permisos para editar esta crew');
        }
        
        // Construir la consulta dinámicamente según los campos proporcionados
        $updates = [];
        $params = [];
        
        if (!empty($_POST['nombre'])) {
            $updates[] = "Nombre = ?";
            $params[] = htmlspecialchars(trim($_POST['nombre']));
        }
        
        if (!empty($_POST['descripcion'])) {
            $updates[] = "Descripcion = ?";
            $params[] = htmlspecialchars(trim($_POST['descripcion']));
        }
        
        // Procesar imagen si se proporcionó
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            // Validar tipo de imagen
            $mimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($fileInfo, $_FILES['foto']['tmp_name']);
            finfo_close($fileInfo);

            if (!in_array($mime, $mimeTypes)) {
                throw new Exception('Solo se permiten imágenes JPEG, PNG o GIF');
            }

            if ($_FILES['foto']['size'] > 2097152) {
                throw new Exception('La imagen no debe superar los 2MB');
            }

            $updates[] = "Foto = ?";
            $params[] = file_get_contents($_FILES['foto']['tmp_name']);
        }
        
        // Si no hay nada que actualizar
        if (empty($updates)) {
            throw new Exception('No se proporcionaron datos para actualizar');
        }
        
        $params[] = $idCrew; // Añadir el ID al final para el WHERE
        
        $sql = "UPDATE crews SET " . implode(', ', $updates) . " WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute($params);
        
        $response = [
            'success' => $success,
            'message' => $success ? 'Crew actualizada correctamente' : 'No se realizaron cambios'
        ];
        
    } catch (Exception $e) {
        $response = [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
    
    echo json_encode($response);
    exit;
}

function transferirAdminCrew($pdo, $idCrew, $idNuevoAdmin) {
    try {
        $pdo->beginTransaction();
        
        // 1. Verificar que el nuevo admin pertenece a la crew
        $sql = "SELECT 1 FROM usuarios WHERE idUsu = ? AND idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idNuevoAdmin, $idCrew]);
        
        if (!$stmt->fetch()) {
            throw new Exception('El nuevo administrador no pertenece a esta crew');
        }
        
        // 2. Transferir admin
        $sql = "UPDATE crews SET idAdmin = ? WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idNuevoAdmin, $idCrew]);
        
        // 3. Quitar al admin actual de la crew
        $sql = "UPDATE usuarios SET idCrew = NULL WHERE idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_SESSION['usuario_id']]);

        $sql = "UPDATE crews SET NUsuarios = NUsuarios - 1 WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        $pdo->commit();
        
        return ['success' => true, 'message' => 'Administración transferida con éxito'];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function eliminarCrew($pdo, $idCrew) {
    try {
        $pdo->beginTransaction();
        
        // 1. Eliminar todas las publicaciones de la crew
        $sql = "UPDATE  publicaciones SET idCrew = NULL  WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        // 2. Eliminar el chat de la crew
        $sql = "DELETE FROM chat_crew WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        // 3. Quitar a todos los miembros de la crew
        $sql = "UPDATE usuarios SET idCrew = NULL WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        // 4. Eliminar la crew
        $sql = "DELETE FROM crews WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCrew]);
        
        $pdo->commit();
        
        return ['success' => true, 'message' => 'Crew eliminada con éxito'];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function obtenerPaisesMarcas($pdo) {
    try {
        $stmt = $pdo->query("SELECT DISTINCT Pais FROM marca ORDER BY Pais");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log("Error en obtenerPaisesMarcas: " . $e->getMessage());
        return [];
    }
}

function obtenerModelosPorMarca($pdo, $idMarca) {
    try {
        $stmt = $pdo->prepare("SELECT idModelos, NombreModelo FROM modelovehiculo WHERE idMarca = ? ORDER BY NombreModelo");
        $stmt->execute([$idMarca]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error en obtenerModelosPorMarca: " . $e->getMessage());
        return [];
    }
}
function obtenerDatosEvento($pdo, $idEvento) {
    try {
        $sql = "SELECT * FROM eventos WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        $evento = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($evento) {
            return [
                'success' => true,
                'evento' => $evento
            ];
        } else {
            return ['success' => false, 'message' => 'Evento no encontrado'];
        }
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al obtener datos del evento'];
    }
}



function actualizarEvento($pdo) {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['usuario_id'])) {
        echo json_encode(['success' => false, 'message' => 'Debes iniciar sesión']);
        exit;
    }

    if (empty($_POST['idEvento'])) {
        echo json_encode(['success' => false, 'message' => 'ID de evento no especificado']);
        exit;
    }

    $idEvento = $_POST['idEvento'];
    
    // Verificar que el usuario es admin del evento
    $sql = "SELECT idUsuAdmin FROM eventos WHERE idEvento = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$idEvento]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$evento || $evento['idUsuAdmin'] != $_SESSION['usuario_id']) {
        echo json_encode(['success' => false, 'message' => 'No tienes permisos']);
        exit;
    }

    try {
        // Construir la consulta dinámicamente según los campos proporcionados
        $updates = [];
        $params = [];
        
        if (isset($_POST['nombre']) && $_POST['nombre'] !== '') {
            $updates[] = "Nombre = ?";
            $params[] = $_POST['nombre'];
        }
        
        if (isset($_POST['descripcion']) && $_POST['descripcion'] !== '') {
            $updates[] = "Descripcion = ?";
            $params[] = $_POST['descripcion'];
        }
        
        if (isset($_POST['lugar']) && $_POST['lugar'] !== '') {
            $updates[] = "Lugar = ?";
            $params[] = $_POST['lugar'];
        }
        
        if (isset($_POST['fecha']) && $_POST['fecha'] !== '') {
            $updates[] = "fecEvento = ?";
            $params[] = $_POST['fecha'];
        }
        
        // Procesar imagen si se subió
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $imagenData = file_get_contents($_FILES['foto']['tmp_name']);
            $updates[] = "PerfilEvento = ?";
            $params[] = $imagenData;
        }
        
        // Si no hay nada que actualizar
        if (empty($updates)) {
            echo json_encode(['success' => false, 'message' => 'No se proporcionaron datos para actualizar']);
            exit;
        }
        
        $params[] = $idEvento; // Añadir el ID al final para el WHERE
        
        $sql = "UPDATE eventos SET " . implode(', ', $updates) . " WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute($params);

        echo json_encode(['success' => $success, 'message' => $success ? 'Evento actualizado' : 'No se realizaron cambios']);
    } catch (PDOException $e) {
        error_log('Error al actualizar evento: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al actualizar']);
    }
}

function obtenerParticipantesEventoEditar($pdo, $idEvento) {
    try {
        $sql = "SELECT u.idUsu, u.Nick, u.FotoPerfil 
                FROM evento_usu eu
                JOIN usuarios u ON eu.idUsu = u.idUsu
                WHERE eu.idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        $participantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($participantes as &$participante) {
            if ($participante['FotoPerfil']) {
                $participante['FotoPerfil'] = base64_encode($participante['FotoPerfil']);
            }
        }
        
        return [
            'success' => true,
            'participantes' => $participantes
        ];
    } catch (PDOException $e) {
        return [
            'success' => false,
            'message' => 'Error al obtener participantes: ' . $e->getMessage()
        ];
    }
}
function obtenerPublicacionesEventoAdmin($pdo, $idEvento) {
    try {
        $sql = "SELECT p.*, u.Nick, u.FotoPerfil 
                FROM publicaciones p
                JOIN usuarios u ON p.idUsu = u.idUsu
                WHERE p.idEvento = ?
                ORDER BY p.fecPublicacion DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        $publicaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Convertir imágenes a base64
        foreach ($publicaciones as &$publi) {
            $publi['Foto'] = base64_encode($publi['Foto']);
            if ($publi['FotoPerfil']) {
                $publi['FotoPerfil'] = base64_encode($publi['FotoPerfil']);
            }
        }
        
        return [
            'success' => true,
            'publicaciones' => $publicaciones
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Error al obtener publicaciones'];
    }
}

function transferirAdminEvento($pdo, $idEvento, $idNuevoAdmin) {
    try {
        $pdo->beginTransaction();
        
        // 1. Verificar que el nuevo admin es participante del evento
        $sql = "SELECT 1 FROM evento_usu WHERE idEvento = ? AND idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento, $idNuevoAdmin]);
        
        if (!$stmt->fetch()) {
            throw new Exception('El nuevo administrador no participa en este evento');
        }
        
        // 2. Transferir admin
        $sql = "UPDATE eventos SET idUsuAdmin = ? WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idNuevoAdmin, $idEvento]);
        
        $pdo->commit();
        
        return ['success' => true, 'message' => 'Administración transferida con éxito'];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function eliminarEvento($pdo, $idEvento) {
    try {
        $pdo->beginTransaction();
        
        // 1. Eliminar todas las publicaciones asociadas al evento
       $sql = "UPDATE  publicaciones SET idEvento = NULL  WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        
        // 2. Eliminar todas las participaciones en el evento
        $sql = "DELETE FROM evento_usu WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        
        // 3. Eliminar el evento
        $sql = "DELETE FROM eventos WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        
        $pdo->commit();
        
        return ['success' => true, 'message' => 'Evento eliminado con éxito'];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function eliminarPublicacionEvento($pdo, $idPublicacion, $idEvento) {
    try {
        $pdo->beginTransaction();
        
        $sql = "SELECT idPubli FROM publicaciones WHERE idPubli = ? AND idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idPublicacion, $idEvento]);
        
        if (!$stmt->fetch()) {
            throw new Exception('La publicación no pertenece a esta crew');
        }
        
        // 2. Eliminar la publicación
        $sql = "UPDATE publicaciones SET idEvento = NULL WHERE idEvento= ? AND idPubli = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento,$idPublicacion]);
        
        $pdo->commit();
        
        return ['success' => true];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
function expulsarParticipanteEvento($pdo, $idEvento, $idUsuario) {
    try {
        $pdo->beginTransaction();
        
        // 1. Verificar que el usuario es admin del evento
        $sql = "SELECT idUsuAdmin FROM eventos WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        $evento = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$evento || $evento['idUsuAdmin'] != $_SESSION['usuario_id']) {
            throw new Exception('No tienes permisos para expulsar participantes');
        }
        
        // 2. Verificar que el usuario no es el admin
        if ($idUsuario == $evento['idUsuAdmin']) {
            throw new Exception('No puedes expulsar al administrador del evento');
        }
        
        // 3. Expulsar al usuario
        $sql = "DELETE FROM evento_usu WHERE idEvento = ? AND idUsu = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento, $idUsuario]);
        
        // 4. Obtener nuevo conteo de participantes
        $sql = "SELECT COUNT(*) as total FROM evento_usu WHERE idEvento = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idEvento]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $pdo->commit();
        
        return [
            'success' => true,
            'message' => 'Participante expulsado correctamente',
            'nuevoConteo' => $result['total']
        ];
    } catch (Exception $e) {
        $pdo->rollBack();
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}


function enviarCodigoVerificacion($pdo) {
    require_once '../tienda/pasarela/mail_functions.php';
    
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $codigo = $_POST['codigo'] ?? '';
    
    if (empty($email) || empty($codigo)) {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        return;
    }
    
    $asunto = "Código de verificación para Wemotors";
    $cuerpo = "
        <h1>¡Gracias por registrarte en Wemotors!</h1>
        <p>Tu código de verificación es: <strong>$codigo</strong></p>
        <p>Por favor, introduce este código en la página de verificación para completar tu registro.</p>
        <p>El código expirará en 2 minutos.</p>
    ";
    
    if (enviarCorreoConfirmacion($email, 'Nuevo usuario', $asunto, $cuerpo)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al enviar el correo de verificación']);
    }
}
?>
