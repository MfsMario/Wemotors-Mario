document.addEventListener("DOMContentLoaded", () => {
    const dropdown = document.getElementById("userDropdown");
    const dropdownButton = document.getElementById("dropdownMenuButton");

    // Verificar que los elementos existen antes de agregar event listeners
    if (dropdown && dropdownButton) {
        dropdownButton.addEventListener("click", () => {
            const screenWidth = window.innerWidth;

            if (screenWidth <= 768) {
                const buttonRect = dropdownButton.getBoundingClientRect();
                dropdown.style.position = 'absolute';
                dropdown.style.top = `${buttonRect.bottom + window.scrollY}px`;
                dropdown.style.left = `${buttonRect.left + window.scrollX}px`;
            } else {
                // Restablecer estilos para pantallas grandes
                dropdown.style.position = '';
                dropdown.style.top = '';
                dropdown.style.left = '';
            }
        });

        // Cerrar el dropdown al hacer clic fuera
        document.addEventListener('click', (event) => {
            if (!dropdown.contains(event.target) && event.target !== dropdownButton) {
                dropdown.classList.remove('show');
            }
        });
    }

    document.querySelectorAll('.btn').forEach(btn => {
        btn.classList.add('btn-standard');
    });
    
    // Específicamente para los botones de la página de inicio
    const contPubli = document.getElementById('cont-publi');
    if (contPubli) {
        contPubli.querySelectorAll('.btn').forEach(btn => {
            btn.classList.add('btn-inicio');
        });
    }
    
    // Específicamente para los botones del perfil
    const perfilContainer = document.querySelector('.perfil-container');
    if (perfilContainer) {
        perfilContainer.querySelectorAll('.btn').forEach(btn => {
            btn.classList.add('btn-perfil');
        });
    }
});