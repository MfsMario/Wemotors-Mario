<?php
require_once("php/funciones.php");

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

if(!isset($_SESSION['usuario_id'])){
    header("Location: pagina_entrada.php"); 
}

$crewUsuario = isset($_SESSION['usuario_id']) ? obtenerCrewUsuario($pdo, $_SESSION['usuario_id']) : [];
$eventosUsuario = isset($_SESSION['usuario_id']) ? obtenerEventosUsuarioParticipa($pdo, $_SESSION['usuario_id']) : [];
?>
<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wemotors</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="inicio.css">
    <link rel="stylesheet" href="solicitudes.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="javaScript\mostrar_publicaciones.js"></script>
    <script src="javaScript\buscar_usuarios.js"></script>
    <script src="javaScript\likes.js"></script>
    <script src="javaScript\comentarios_publicaciones.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-light m-0 p-0 d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                <li class="nav-item">
                    <a class="nav-link active" href="inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="eventos.php">Eventos</a>
                </li>
                <li class="nav-item position-relative">
                    <input type="text" class="form-control ms-3 " id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                    <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                </li>
            </ul>
            <div class="dropdown">
                <button 
                    class="btn btn-outline-light dropdown-toggle" 
                    type="button" 
                    id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false">
                    <?php echo $usuario; ?>

                     <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                            style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                            <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#" aria-expanded="false">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo generarHtmlSolicitudes($pdo); ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid main-content mt-2">
  <div class="row gx-2">
    <!-- Sección lateral izquierda (Crew y Eventos) -->
    <?php if($crewUsuario || !empty($eventosUsuario)): ?>
    <div class="col-lg-3 left-sidebar">
        <?php if($crewUsuario): ?>
        <div class="card mb-2 crew-card">
            <div class="card-header bg-dark text-white p-2">
                <h5 class="mb-0">Mi Crew</h5>
            </div>
            <a href="detalle_crew.php?id=<?= $crewUsuario['idCrew'] ?>" class="text-decoration-none text-dark d-flex h-100">
                <div class="crew-image">
                    <img src="data:image/jpeg;base64,<?= base64_encode($crewUsuario['Foto']) ?>" 
                         class="img-fluid h-100" style="max-width:150px; max-height:100px;" alt="Foto del Crew">
                </div>
                <div class="crew-info d-flex align-items-center p-2">
                    <h5 class="mb-0"><?= htmlspecialchars($crewUsuario['Nombre']) ?></h5>
                </div>
            </a>
            <div class="crew-tienda-btn">
                <a href="tienda/tienda.php?idCrew=<?= $crewUsuario['idCrew'] ?>" class="btn btn-sm btn-outline-dark w-100">
                    Ver tienda
                </a>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if(!empty($eventosUsuario)): ?>
        <div class="card mb-2 eventos-card">
            <div class="card-header bg-dark text-white p-2">
                <h5 class="mb-0">Mis Eventos</h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php foreach($eventosUsuario as $evento): ?>
                        <a href="detalle_evento.php?idEvento=<?= $evento['idEvento'] ?>" 
                           class="list-group-item list-group-item-action d-flex p-0">
                            <div class="event-image">
                                <?php if($evento['PerfilEvento']): ?>
                                    <img src="data:image/jpeg;base64,<?= base64_encode($evento['PerfilEvento']) ?>" 
                                         class="img-fluid h-100"  style="max-width:150px; max-height:100px;" alt="Foto del Evento">
                                <?php else: ?>
                                    <div class="no-image h-100 d-flex align-items-center justify-content-center">
                                        <i class="bi bi-calendar-event text-white"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="event-info p-2 d-flex flex-column justify-content-center">
                                <h6 class="fw-bold mb-1"><?= htmlspecialchars($evento['Nombre']) ?></h6>
                                <small class="text-muted">
                                    <?= date('d/m/Y', strtotime($evento['fecEvento'])) ?><br>
                                    <?= htmlspecialchars($evento['Lugar'] ?? 'Lugar no especificado') ?>
                                </small>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <!-- Sección de Publicaciones (centrada) -->
    <div class="<?php echo ($crewUsuario || !empty($eventosUsuario)) ? 'col-lg-6' : 'col-lg-8 offset-lg-2'; ?> publicaciones-section">
        <div class="sticky-top filter-header bg-transparent">
            <div class="text-center">
                <div class="btn-group bg-white">
                    <button class="btn btn-outline-dark active" id="btnTodos">Todos</button>
                    <button class="btn btn-outline-dark" id="btnSiguiendo">Siguiendo</button>
                    <div class="btn-group">
                        <button class="btn btn-outline-dark dropdown-toggle" type="button" id="marcasDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Marcas
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="marcasDropdown" style="max-height: 200px; overflow-y: auto;">
                            <li><a class="dropdown-item" href="#" id="todasMarcas">Todas las marcas</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php
                                $marcas = DevolverNombreMarca($pdo);
                                foreach ($marcas as $marca) {
                                    echo '<li><a class="dropdown-item" href="#" data-marca-id="'.$marca['idMarca'].'">'.$marca['Nombre'].'</a></li>';
                                }
                            ?>
                        </ul>
                    </div>
                        <div class="btn-group">
                        <button class="btn btn-outline-dark dropdown-toggle" type="button" id="paisesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            Países
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="paisesDropdown" style="max-height: 200px; overflow-y: auto;">
                            <li><a class="dropdown-item" href="#" id="todosPaises">Todos los países</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php
                                $paises = obtenerPaisesMarcas($pdo);
                                foreach ($paises as $pais) {
                                    echo '<li><a class="dropdown-item" href="#" data-pais="'.$pais.'">'.$pais.'</a></li>';
                                }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="cont-publi"></div>
    </div>
    
    <!-- Columna derecha vacía para balancear el layout -->
    <?php if($crewUsuario || !empty($eventosUsuario)): ?>
    <div class="col-lg-3"></div>
    <?php endif; ?>
  </div>
</div>

<!-- Sidebar de comentarios -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="commentsSidebar" aria-labelledby="commentsSidebarLabel" style="width: 450px; border-left: 3px solid #000;">
  <div class="offcanvas-header bg-light" style="border-bottom: 2px solid #4C585B; border-radius: 0 0.375rem 0 0;">
    <h5 class="offcanvas-title fw-bold" id="commentsSidebarLabel">Comentarios</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body p-0" id="commentsContainer" style="background-color: #f8f9fa; border-radius: 0.375rem;">
    <!-- Los comentarios se cargarán aquí dinámicamente -->
  </div>
  <div class="border-top p-3" style="border-top: 2px solid #000 !important; border-radius: 0 0 0.375rem 0.375rem;">
    <?php if(isset($_SESSION['usuario_id'])): ?>
      <div class="input-group mb-0">
        <input type="text" id="commentInput" class="form-control border-dark" placeholder="Escribe un comentario..." style="border-radius: 20px 0 0 20px;">
        <button class="btn btn-primary" type="button" id="sendComment" style="border-radius: 0 20px 20px 0;">
          <i class="bi bi-send-fill"></i>
        </button>
      </div>
    <?php else: ?>
      <div class="alert alert-warning mb-0">
        <a href="inicio_sesion.php" class="alert-link">Inicia sesión</a> 
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="offcanvas-backdrop fade show d-none" id="commentsBackdrop" style="display: none;"></div>
<?php require_once("footer.html");?>
<?php include("reportar_modal.php"); ?>
<script src="navegDesplegable.js"></script>
<script src="javaScript/solicitud.js"></script>
</body>
</html>