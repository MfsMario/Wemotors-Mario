-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-05-2025 a las 12:42:03
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `wemotors`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carritos`
--

CREATE TABLE `carritos` (
  `id_carrito` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_crew` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito_items`
--

CREATE TABLE `carrito_items` (
  `id_item` int(11) NOT NULL,
  `id_carrito` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat_crew`
--

CREATE TABLE `chat_crew` (
  `idMsj` int(11) NOT NULL,
  `idCrew` int(11) NOT NULL,
  `idUsu` int(11) NOT NULL,
  `texto` varchar(500) NOT NULL,
  `fecMsj` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario`
--

CREATE TABLE `comentario` (
  `idComentario` int(11) NOT NULL,
  `idUsu` int(11) NOT NULL,
  `idPub` int(11) NOT NULL,
  `fecCom` datetime NOT NULL,
  `texto` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `crews`
--

CREATE TABLE `crews` (
  `idCrew` int(11) NOT NULL,
  `Nombre` varchar(40) NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `idAdmin` int(11) DEFAULT NULL,
  `fecCreacion` datetime NOT NULL,
  `Foto` mediumblob NOT NULL,
  `NUsuarios` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `idEvento` int(11) NOT NULL,
  `idUsuAdmin` int(11) DEFAULT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `Lugar` varchar(200) NOT NULL,
  `fecEvento` datetime NOT NULL,
  `PerfilEvento` mediumblob NOT NULL,
  `Modelo` int(11) DEFAULT NULL,
  `TipoCoche` int(11) DEFAULT NULL,
  `Marca` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento_usu`
--

CREATE TABLE `evento_usu` (
  `idUsu` int(11) NOT NULL,
  `idEvento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `likes`
--

CREATE TABLE `likes` (
  `idLike` int(11) NOT NULL,
  `idPubli` int(11) NOT NULL,
  `idUsu` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE `marca` (
  `idMarca` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Pais` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`idMarca`, `Nombre`, `Pais`) VALUES
(550, 'Toyota', 'Japón'),
(551, 'Volkswagen', 'Alemania'),
(552, 'Ford', 'Estados Unidos'),
(553, 'Honda', 'Japón'),
(554, 'Chevrolet', 'Estados Unidos'),
(555, 'Nissan', 'Japón'),
(556, 'BMW', 'Alemania'),
(557, 'Mercedes-Benz', 'Alemania'),
(558, 'Hyundai', 'Corea del Sur'),
(559, 'Kia', 'Corea del Sur'),
(560, 'Audi', 'Alemania'),
(561, 'Volvo', 'Suecia'),
(562, 'Subaru', 'Japón'),
(563, 'Mazda', 'Japón'),
(564, 'Lexus', 'Japón'),
(565, 'Tesla', 'Estados Unidos'),
(566, 'Porsche', 'Alemania'),
(567, 'Jeep', 'Estados Unidos'),
(568, 'Land Rover', 'Reino Unido'),
(569, 'Jaguar', 'Reino Unido'),
(570, 'Ferrari', 'Italia'),
(571, 'Lamborghini', 'Italia'),
(572, 'Maserati', 'Italia'),
(573, 'Alfa Romeo', 'Italia'),
(574, 'Bentley', 'Reino Unido'),
(575, 'Rolls-Royce', 'Reino Unido'),
(576, 'Aston Martin', 'Reino Unido'),
(577, 'McLaren', 'Reino Unido'),
(578, 'Lotus', 'Reino Unido'),
(579, 'Bugatti', 'Francia'),
(580, 'Pagani', 'Italia'),
(581, 'Koenigsegg', 'Suecia'),
(582, 'Rimac', 'Croacia'),
(583, 'Spyker', 'Países Bajos'),
(585, 'Zenvo', 'Dinamarca'),
(590, 'Peugeot', 'Francia'),
(591, 'Renault', 'Francia'),
(592, 'Citroën', 'Francia'),
(593, 'Opel', 'Alemania'),
(594, 'Fiat', 'Italia'),
(595, 'Lancia', 'Italia'),
(596, 'Seat', 'España'),
(597, 'Skoda', 'República Checa'),
(598, 'Dacia', 'Rumanía'),
(599, 'Saab', 'Suecia'),
(600, 'Smart', 'Alemania'),
(601, 'Maybach', 'Alemania'),
(602, 'Mini', 'Reino Unido'),
(603, 'DS Automobiles', 'Francia'),
(605, 'Alpine', 'Francia'),
(606, 'Cupra', 'España'),
(610, 'Cadillac', 'Estados Unidos'),
(612, 'Chrysler', 'Estados Unidos'),
(613, 'Dodge', 'Estados Unidos'),
(614, 'GMC', 'Estados Unidos'),
(616, 'Ram', 'Estados Unidos'),
(617, 'Pontiac', 'Estados Unidos'),
(619, 'Plymouth', 'Estados Unidos'),
(621, 'Hummer', 'Estados Unidos'),
(622, 'DeLorean', 'Irlanda del Norte'),
(625, 'Hennessey', 'Estados Unidos'),
(627, 'Fisker', 'Estados Unidos'),
(628, 'Lucid', 'Estados Unidos'),
(630, 'Suzuki', 'Japón'),
(631, 'Mitsubishi', 'Japón'),
(632, 'Isuzu', 'Japón'),
(634, 'Infiniti', 'Japón'),
(635, 'Acura', 'Japón'),
(636, 'Genesis', 'Corea del Sur'),
(637, 'Tata', 'India'),
(639, 'BYD', 'China'),
(646, 'Dongfeng', 'China'),
(647, 'FAW', 'China'),
(648, 'JAC', 'China'),
(649, 'Haval', 'China'),
(650, 'Polestar', 'Suecia'),
(651, 'NIO', 'China'),
(652, 'XPeng', 'China'),
(653, 'Li Auto', 'China'),
(654, 'Proton', 'Malasia'),
(655, 'Perodua', 'Malasia'),
(656, 'Holden', 'Australia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelovehiculo`
--

CREATE TABLE `modelovehiculo` (
  `idModelos` int(11) NOT NULL,
  `idMarca` int(11) NOT NULL,
  `NombreModelo` varchar(100) NOT NULL,
  `inTipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `modelovehiculo`
--

INSERT INTO `modelovehiculo` (`idModelos`, `idMarca`, `NombreModelo`, `inTipo`) VALUES
(11, 550, 'Corolla', 3),
(12, 550, 'Camry', 3),
(13, 550, 'RAV4', 2),
(14, 550, 'Hilux', 6),
(15, 550, 'Prius', 14),
(16, 551, 'Golf', 4),
(17, 551, 'Passat', 3),
(18, 551, 'Tiguan', 2),
(19, 551, 'Polo', 4),
(20, 551, 'Arteon', 8),
(21, 552, 'Fiesta', 4),
(22, 552, 'Focus', 4),
(23, 552, 'Mustang', 5),
(24, 552, 'Explorer', 2),
(25, 552, 'Transit', 7),
(26, 556, 'Serie 3', 10),
(27, 556, 'X5', 2),
(28, 556, 'i8', 13),
(29, 556, 'Serie 5', 10),
(30, 556, 'Z4', 9),
(31, 557, 'Clase A', 4),
(32, 557, 'Clase C', 3),
(33, 557, 'GLE', 2),
(34, 557, 'Clase E', 10),
(35, 557, 'AMG GT', 5),
(36, 553, 'Civic', 3),
(37, 553, 'Accord', 3),
(38, 553, 'CR-V', 2),
(39, 553, 'HR-V', 2),
(40, 553, 'Jazz', 4),
(41, 565, 'Model S', 13),
(42, 565, 'Model 3', 13),
(43, 565, 'Model X', 13),
(44, 565, 'Model Y', 13),
(45, 565, 'Cybertruck', 6),
(46, 570, '488 GTB', 5),
(47, 570, 'F8 Tributo', 5),
(48, 570, 'Portofino', 9),
(49, 570, 'SF90 Stradale', 5),
(50, 570, 'Roma', 8),
(51, 566, '911', 8),
(52, 566, 'Taycan', 13),
(53, 566, 'Cayenne', 2),
(54, 566, 'Panamera', 10),
(55, 566, 'Macan', 2),
(56, 571, 'Huracán', 5),
(57, 571, 'Aventador', 5),
(58, 571, 'Urus', 2),
(59, 571, 'Sian', 5),
(60, 571, 'Countach', 5),
(61, 554, 'Spark', 4),
(62, 554, 'Cruze', 3),
(63, 554, 'Malibu', 3),
(64, 554, 'Tahoe', 2),
(65, 554, 'Silverado', 6),
(66, 555, 'Sentra', 3),
(67, 555, 'Altima', 3),
(68, 555, 'Qashqai', 2),
(69, 555, 'X-Trail', 2),
(70, 555, 'GT-R', 5),
(71, 558, 'Elantra', 3),
(72, 558, 'Sonata', 3),
(73, 558, 'Tucson', 2),
(74, 558, 'Santa Fe', 2),
(75, 558, 'i30', 4),
(76, 559, 'Rio', 4),
(77, 559, 'Forte', 3),
(78, 559, 'Sportage', 2),
(79, 559, 'Sorento', 2),
(80, 559, 'Stinger', 5),
(81, 560, 'A3', 4),
(82, 560, 'A4', 3),
(83, 560, 'Q5', 2),
(84, 560, 'Q7', 2),
(85, 560, 'TT', 8),
(86, 561, 'S60', 3),
(87, 561, 'S90', 10),
(88, 561, 'XC60', 2),
(89, 561, 'XC90', 2),
(90, 561, 'V40', 4),
(91, 562, 'Impreza', 3),
(92, 562, 'Legacy', 3),
(93, 562, 'Outback', 12),
(94, 562, 'Forester', 2),
(95, 562, 'WRX', 5),
(96, 563, 'Mazda3', 4),
(97, 563, 'Mazda6', 3),
(98, 563, 'CX-5', 2),
(99, 563, 'CX-9', 2),
(100, 563, 'MX-5', 9),
(101, 564, 'IS', 3),
(102, 564, 'ES', 3),
(103, 564, 'RX', 2),
(104, 564, 'GX', 2),
(105, 564, 'LC', 8),
(106, 567, 'Wrangler', 12),
(107, 567, 'Grand Cherokee', 2),
(108, 567, 'Cherokee', 2),
(109, 567, 'Compass', 2),
(110, 567, 'Renegade', 2),
(111, 568, 'Range Rover', 2),
(112, 568, 'Discovery', 2),
(113, 568, 'Defender', 12),
(114, 568, 'Evoque', 2),
(115, 568, 'Velar', 2),
(116, 569, 'XE', 3),
(117, 569, 'XF', 10),
(118, 569, 'F-PACE', 2),
(119, 569, 'E-PACE', 2),
(120, 569, 'F-TYPE', 8),
(121, 572, 'Ghibli', 10),
(122, 572, 'Quattroporte', 10),
(123, 572, 'Levante', 2),
(124, 572, 'GranTurismo', 8),
(125, 572, 'MC20', 5),
(126, 573, 'Giulia', 3),
(127, 573, 'Stelvio', 2),
(128, 573, 'Giulietta', 4),
(129, 573, '4C', 5),
(130, 573, 'Tonale', 2),
(131, 574, 'Continental', 8),
(132, 574, 'Bentayga', 2),
(133, 574, 'Flying Spur', 10),
(134, 574, 'Mulsanne', 10),
(135, 574, 'Bacalar', 9),
(136, 575, 'Ghost', 10),
(137, 575, 'Phantom', 15),
(138, 575, 'Wraith', 8),
(139, 575, 'Dawn', 9),
(140, 575, 'Cullinan', 2),
(141, 576, 'DB11', 8),
(142, 576, 'Vantage', 5),
(143, 576, 'DBS', 8),
(144, 576, 'DBX', 2),
(145, 576, 'Valkyrie', 5),
(146, 577, '720S', 5),
(147, 577, '570S', 5),
(148, 577, 'GT', 8),
(149, 577, 'Senna', 5),
(150, 577, 'P1', 5),
(151, 578, 'Evora', 5),
(152, 578, 'Elise', 5),
(153, 578, 'Exige', 5),
(154, 578, 'Emira', 5),
(155, 578, 'Evija', 13),
(156, 579, 'Chiron', 5),
(157, 579, 'Veyron', 5),
(158, 579, 'Divo', 5),
(159, 579, 'Centodieci', 5),
(160, 579, 'La Voiture Noire', 5),
(161, 580, 'Huayra', 5),
(162, 580, 'Zonda', 5),
(163, 580, 'Utopia', 5),
(164, 580, 'Imola', 5),
(165, 580, 'Roadster BC', 9),
(166, 581, 'Regera', 5),
(167, 581, 'Agera', 5),
(168, 581, 'Jesko', 5),
(169, 581, 'Gemera', 14),
(170, 581, 'CC850', 5),
(171, 582, 'Nevera', 13),
(172, 582, 'Concept One', 13),
(173, 582, 'C_Two', 13),
(174, 582, 'Scalatan', 13),
(175, 582, 'Automobili', 13),
(176, 590, '208', 4),
(177, 590, '308', 4),
(178, 590, '3008', 2),
(179, 590, '5008', 2),
(180, 590, '508', 3),
(181, 591, 'Clio', 4),
(182, 591, 'Megane', 4),
(183, 591, 'Captur', 2),
(184, 591, 'Koleos', 2),
(185, 591, 'Talisman', 3),
(186, 592, 'C3', 4),
(187, 592, 'C4', 4),
(188, 592, 'C5 Aircross', 2),
(189, 592, 'Berlingo', 11),
(190, 592, 'C-Elysée', 3),
(191, 593, 'Corsa', 4),
(192, 593, 'Astra', 4),
(193, 593, 'Crossland', 2),
(194, 593, 'Grandland', 2),
(195, 593, 'Insignia', 3),
(196, 594, '500', 4),
(197, 594, 'Panda', 4),
(198, 594, 'Tipo', 4),
(199, 594, '500X', 2),
(200, 594, 'Ducato', 7),
(201, 595, 'Ypsilon', 4),
(202, 595, 'Delta', 4),
(203, 595, 'Stratos', 5),
(204, 595, 'Thesis', 10),
(205, 595, 'Musa', 11),
(206, 596, 'Ibiza', 4),
(207, 596, 'Leon', 4),
(208, 596, 'Arona', 2),
(209, 596, 'Ateca', 2),
(210, 596, 'Tarraco', 2),
(211, 597, 'Fabia', 4),
(212, 597, 'Octavia', 3),
(213, 597, 'Karoq', 2),
(214, 597, 'Kodiaq', 2),
(215, 597, 'Superb', 10),
(216, 598, 'Sandero', 4),
(217, 598, 'Logan', 3),
(218, 598, 'Duster', 2),
(219, 598, 'Lodgy', 11),
(220, 598, 'Dokker', 7),
(221, 600, 'ForTwo', 4),
(222, 600, 'ForFour', 4),
(223, 600, 'EQfortwo', 13),
(224, 600, 'Roadster', 9),
(225, 600, 'Crossblade', 9),
(226, 602, 'Cooper', 4),
(227, 602, 'Countryman', 2),
(228, 602, 'Clubman', 4),
(229, 602, 'Convertible', 9),
(230, 602, 'Paceman', 8),
(231, 610, 'ATS', 3),
(232, 610, 'CTS', 3),
(233, 610, 'Escalade', 2),
(234, 610, 'XT5', 2),
(235, 610, 'CT6', 10),
(241, 612, '300', 3),
(242, 612, 'Pacifica', 11),
(243, 612, 'Voyager', 11),
(244, 612, 'Sebring', 9),
(245, 612, 'Crossfire', 8),
(246, 613, 'Charger', 3),
(247, 613, 'Challenger', 8),
(248, 613, 'Durango', 2),
(249, 613, 'Journey', 2),
(250, 613, 'Viper', 5),
(251, 630, 'Swift', 4),
(252, 630, 'Vitara', 2),
(253, 630, 'SX4', 4),
(254, 630, 'Jimny', 12),
(255, 630, 'Baleno', 4),
(256, 631, 'Lancer', 3),
(257, 631, 'Outlander', 2),
(258, 631, 'ASX', 2),
(259, 631, 'Eclipse Cross', 2),
(260, 631, 'Mirage', 4),
(261, 634, 'Q50', 3),
(262, 634, 'Q60', 8),
(263, 634, 'QX50', 2),
(264, 634, 'QX60', 2),
(265, 634, 'QX80', 2),
(266, 635, 'TLX', 3),
(267, 635, 'ILX', 3),
(268, 635, 'RDX', 2),
(269, 635, 'MDX', 2),
(270, 635, 'NSX', 5),
(271, 636, 'G70', 3),
(272, 636, 'G80', 3),
(273, 636, 'G90', 10),
(274, 636, 'GV70', 2),
(275, 636, 'GV80', 2),
(276, 639, 'Han', 13),
(277, 639, 'Tang', 13),
(278, 639, 'Song', 2),
(279, 639, 'Qin', 3),
(280, 639, 'Yuan', 2),
(281, 650, 'Polestar 1', 14),
(282, 650, 'Polestar 2', 13),
(283, 650, 'Polestar 3', 13),
(284, 650, 'Polestar 4', 13),
(285, 650, 'Polestar 5', 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `idPedido` int(11) NOT NULL,
  `idPago` varchar(150) NOT NULL,
  `Descripcion` varchar(500) NOT NULL,
  `precioPago` decimal(10,2) NOT NULL,
  `NombreComprador` varchar(100) NOT NULL,
  `emailComprador` varchar(200) NOT NULL,
  `fechaPedido` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idCrew` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `idProducto` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` varchar(500) NOT NULL,
  `precio` int(11) NOT NULL,
  `fotoProducto` mediumblob NOT NULL,
  `idCrew` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecSubida` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idTipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE `publicaciones` (
  `idPubli` int(11) NOT NULL,
  `idUsu` int(11) NOT NULL,
  `Foto` mediumblob NOT NULL,
  `DescripcionPubli` varchar(200) NOT NULL,
  `NLikes` int(11) NOT NULL,
  `fecPublicacion` datetime NOT NULL,
  `idMarca` int(11) NOT NULL,
  `idCrew` int(11) DEFAULT NULL,
  `idEvento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes`
--

CREATE TABLE `reportes` (
  `UsuNotificador` int(11) DEFAULT NULL,
  `UsuReportado` int(11) DEFAULT NULL,
  `crewReportada` int(11) DEFAULT NULL,
  `EventoReportado` int(11) DEFAULT NULL,
  `Descripcion` varchar(500) NOT NULL,
  `idReporte` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguidores`
--

CREATE TABLE `seguidores` (
  `idSeguidor` int(11) NOT NULL,
  `idSeguido` int(11) NOT NULL,
  `aceptado` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoprod`
--

CREATE TABLE `tipoprod` (
  `idTipo` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipoprod`
--

INSERT INTO `tipoprod` (`idTipo`, `Nombre`) VALUES
(1, 'pegatinas'),
(2, 'ropa'),
(3, 'llaveros'),
(4, 'Otros');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipovehiculo`
--

CREATE TABLE `tipovehiculo` (
  `idTipo` int(11) NOT NULL,
  `TipoNombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipovehiculo`
--

INSERT INTO `tipovehiculo` (`idTipo`, `TipoNombre`) VALUES
(2, 'SUV'),
(3, 'Sedán'),
(4, 'Hatchback'),
(5, 'Deportivo'),
(6, 'Pickup'),
(7, 'Furgoneta'),
(8, 'Coupé'),
(9, 'Convertible'),
(10, 'Berlina'),
(11, 'Monovolumen'),
(12, 'Todoterreno'),
(13, 'Eléctrico'),
(14, 'Híbrido'),
(15, 'Limusina'),
(16, 'Camión'),
(17, 'Autobús'),
(18, 'Motocicleta'),
(19, 'Quad'),
(20, 'Tractor'),
(21, 'Militar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsu` int(11) NOT NULL,
  `Nick` varchar(25) NOT NULL,
  `contra` varchar(100) NOT NULL,
  `FotoPerfil` mediumblob NOT NULL,
  `Descripcion` varchar(300) NOT NULL,
  `Admin` tinyint(1) NOT NULL,
  `fecRegistro` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `Nombre` varchar(30) NOT NULL,
  `Apellidos` varchar(100) NOT NULL,
  `idCrew` int(11) DEFAULT NULL,
  `privada` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `idVehiculo` int(11) NOT NULL,
  `idUsu` int(11) NOT NULL,
  `idMarca` int(11) NOT NULL,
  `Modelo` int(11) NOT NULL,
  `Agno` int(11) NOT NULL,
  `FotoCoche` mediumblob NOT NULL,
  `Tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carritos`
--
ALTER TABLE `carritos`
  ADD PRIMARY KEY (`id_carrito`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_crew` (`id_crew`);

--
-- Indices de la tabla `carrito_items`
--
ALTER TABLE `carrito_items`
  ADD PRIMARY KEY (`id_item`),
  ADD KEY `id_carrito` (`id_carrito`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `chat_crew`
--
ALTER TABLE `chat_crew`
  ADD PRIMARY KEY (`idMsj`),
  ADD KEY `idCrew` (`idCrew`),
  ADD KEY `idUsu` (`idUsu`);

--
-- Indices de la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`idComentario`),
  ADD KEY `idPub` (`idPub`),
  ADD KEY `idUsu` (`idUsu`);

--
-- Indices de la tabla `crews`
--
ALTER TABLE `crews`
  ADD PRIMARY KEY (`idCrew`),
  ADD KEY `idAdmin` (`idAdmin`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`idEvento`),
  ADD KEY `eventos_ibfk_1` (`idUsuAdmin`),
  ADD KEY `Marca` (`Marca`),
  ADD KEY `Modelo` (`Modelo`),
  ADD KEY `TipoCoche` (`TipoCoche`);

--
-- Indices de la tabla `evento_usu`
--
ALTER TABLE `evento_usu`
  ADD KEY `idUsu` (`idUsu`),
  ADD KEY `idEvento` (`idEvento`);

--
-- Indices de la tabla `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`idLike`),
  ADD KEY `idPubli` (`idPubli`),
  ADD KEY `idUsu` (`idUsu`);

--
-- Indices de la tabla `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`idMarca`);

--
-- Indices de la tabla `modelovehiculo`
--
ALTER TABLE `modelovehiculo`
  ADD PRIMARY KEY (`idModelos`),
  ADD KEY `inTipo` (`inTipo`),
  ADD KEY `idMarca` (`idMarca`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idPedido`),
  ADD KEY `idCrew` (`idCrew`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`idProducto`),
  ADD KEY `idTipo` (`idTipo`),
  ADD KEY `idCrew` (`idCrew`);

--
-- Indices de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD PRIMARY KEY (`idPubli`),
  ADD KEY `idCrew` (`idCrew`),
  ADD KEY `idEvento` (`idEvento`),
  ADD KEY `idMarca` (`idMarca`),
  ADD KEY `idUsu` (`idUsu`);

--
-- Indices de la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD PRIMARY KEY (`idReporte`),
  ADD KEY `UsuReportado` (`UsuReportado`),
  ADD KEY `crewReportada` (`crewReportada`),
  ADD KEY `eventoReportado` (`EventoReportado`),
  ADD KEY `usuNotificador` (`UsuNotificador`);

--
-- Indices de la tabla `seguidores`
--
ALTER TABLE `seguidores`
  ADD KEY `idSeguido` (`idSeguido`),
  ADD KEY `idSeguidor` (`idSeguidor`);

--
-- Indices de la tabla `tipoprod`
--
ALTER TABLE `tipoprod`
  ADD PRIMARY KEY (`idTipo`);

--
-- Indices de la tabla `tipovehiculo`
--
ALTER TABLE `tipovehiculo`
  ADD PRIMARY KEY (`idTipo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsu`),
  ADD KEY `idCrew` (`idCrew`);

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`idVehiculo`),
  ADD KEY `idMarca` (`idMarca`),
  ADD KEY `idUsu` (`idUsu`),
  ADD KEY `Tipo` (`Tipo`),
  ADD KEY `Modelo` (`Modelo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carritos`
--
ALTER TABLE `carritos`
  MODIFY `id_carrito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `carrito_items`
--
ALTER TABLE `carrito_items`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `chat_crew`
--
ALTER TABLE `chat_crew`
  MODIFY `idMsj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `comentario`
--
ALTER TABLE `comentario`
  MODIFY `idComentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `crews`
--
ALTER TABLE `crews`
  MODIFY `idCrew` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `idEvento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `likes`
--
ALTER TABLE `likes`
  MODIFY `idLike` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `marca`
--
ALTER TABLE `marca`
  MODIFY `idMarca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=657;

--
-- AUTO_INCREMENT de la tabla `modelovehiculo`
--
ALTER TABLE `modelovehiculo`
  MODIFY `idModelos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=286;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idPedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  MODIFY `idPubli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de la tabla `reportes`
--
ALTER TABLE `reportes`
  MODIFY `idReporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `tipoprod`
--
ALTER TABLE `tipoprod`
  MODIFY `idTipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tipovehiculo`
--
ALTER TABLE `tipovehiculo`
  MODIFY `idTipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `idVehiculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carritos`
--
ALTER TABLE `carritos`
  ADD CONSTRAINT `carritos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`idUsu`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `carritos_ibfk_2` FOREIGN KEY (`id_crew`) REFERENCES `crews` (`idCrew`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `carrito_items`
--
ALTER TABLE `carrito_items`
  ADD CONSTRAINT `carrito_items_ibfk_1` FOREIGN KEY (`id_carrito`) REFERENCES `carritos` (`id_carrito`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `carrito_items_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`idProducto`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `chat_crew`
--
ALTER TABLE `chat_crew`
  ADD CONSTRAINT `chat_crew_ibfk_1` FOREIGN KEY (`idCrew`) REFERENCES `crews` (`idCrew`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chat_crew_ibfk_2` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `comentario_ibfk_1` FOREIGN KEY (`idPub`) REFERENCES `publicaciones` (`idPubli`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comentario_ibfk_2` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `crews`
--
ALTER TABLE `crews`
  ADD CONSTRAINT `crews_ibfk_1` FOREIGN KEY (`idAdmin`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`idUsuAdmin`) REFERENCES `usuarios` (`idUsu`) ON UPDATE CASCADE,
  ADD CONSTRAINT `eventos_ibfk_2` FOREIGN KEY (`Marca`) REFERENCES `marca` (`idMarca`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `eventos_ibfk_3` FOREIGN KEY (`Modelo`) REFERENCES `modelovehiculo` (`idModelos`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `eventos_ibfk_4` FOREIGN KEY (`TipoCoche`) REFERENCES `tipovehiculo` (`idTipo`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `evento_usu`
--
ALTER TABLE `evento_usu`
  ADD CONSTRAINT `evento_usu_ibfk_1` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `evento_usu_ibfk_2` FOREIGN KEY (`idEvento`) REFERENCES `eventos` (`idEvento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`idPubli`) REFERENCES `publicaciones` (`idPubli`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE;

--
-- Filtros para la tabla `modelovehiculo`
--
ALTER TABLE `modelovehiculo`
  ADD CONSTRAINT `modelovehiculo_ibfk_1` FOREIGN KEY (`inTipo`) REFERENCES `tipovehiculo` (`idTipo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modelovehiculo_ibfk_2` FOREIGN KEY (`idMarca`) REFERENCES `marca` (`idMarca`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`idCrew`) REFERENCES `crews` (`idCrew`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`idTipo`) REFERENCES `tipoprod` (`idTipo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`idCrew`) REFERENCES `crews` (`idCrew`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `publicaciones`
--
ALTER TABLE `publicaciones`
  ADD CONSTRAINT `publicaciones_ibfk_1` FOREIGN KEY (`idCrew`) REFERENCES `crews` (`idCrew`) ON UPDATE CASCADE,
  ADD CONSTRAINT `publicaciones_ibfk_2` FOREIGN KEY (`idEvento`) REFERENCES `eventos` (`idEvento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `publicaciones_ibfk_3` FOREIGN KEY (`idMarca`) REFERENCES `marca` (`idMarca`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `publicaciones_ibfk_4` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `reportes`
--
ALTER TABLE `reportes`
  ADD CONSTRAINT `Notificador` FOREIGN KEY (`UsuNotificador`) REFERENCES `usuarios` (`idUsu`) ON UPDATE CASCADE,
  ADD CONSTRAINT `UsuReportado` FOREIGN KEY (`UsuReportado`) REFERENCES `usuarios` (`idUsu`) ON UPDATE CASCADE,
  ADD CONSTRAINT `crewReportada` FOREIGN KEY (`crewReportada`) REFERENCES `crews` (`idCrew`) ON UPDATE CASCADE,
  ADD CONSTRAINT `eventoReportado` FOREIGN KEY (`EventoReportado`) REFERENCES `eventos` (`idEvento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `usuNotificador` FOREIGN KEY (`UsuNotificador`) REFERENCES `usuarios` (`idUsu`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `seguidores`
--
ALTER TABLE `seguidores`
  ADD CONSTRAINT `seguidores_ibfk_1` FOREIGN KEY (`idSeguido`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `seguidores_ibfk_2` FOREIGN KEY (`idSeguidor`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`idCrew`) REFERENCES `crews` (`idCrew`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD CONSTRAINT `vehiculos_ibfk_1` FOREIGN KEY (`idMarca`) REFERENCES `marca` (`idMarca`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehiculos_ibfk_2` FOREIGN KEY (`idUsu`) REFERENCES `usuarios` (`idUsu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehiculos_ibfk_3` FOREIGN KEY (`Tipo`) REFERENCES `tipovehiculo` (`idTipo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehiculos_ibfk_4` FOREIGN KEY (`Modelo`) REFERENCES `modelovehiculo` (`idModelos`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
