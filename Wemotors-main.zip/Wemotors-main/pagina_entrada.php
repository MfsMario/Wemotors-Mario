<?php
session_start();

if (isset($_SESSION['usuario_id'])) {
    header("Location: inicio.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WeMotors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="pagina_inicias.css" rel="stylesheet">
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body>
    <div class="container-fluid h-100 p-0">
        <!-- Contenido superpuesto (logo y botón) -->
        <div class="overlay-content">
            <div class="square-logo">
                <h1>WEMOTORS</h1>
                <a href="inicio_sesion.php" class="login-btn">INICIAR SESIÓN</a>
                <a href="crear_cuenta.html" class="login-btn mt-4">CREAR CUENTA</a>
            </div>
        </div>
        
        <!-- Fila de imágenes (3 columnas) -->
        <div class="row g-0 img-row">
            <div class="img-col">
                <img src="imagenes/gtr355.jpg" style="filter: brightness(2)"  alt="Auto 1">
            </div>
            <div class="img-col">
                <img src="imagenes/camaro.jpg" alt="Auto 2">
            </div>
            <div class="img-col">
                <img src="imagenes/lambo3.jpg" alt="Auto 3">
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>