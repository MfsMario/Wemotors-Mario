<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio sesión</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./javaScript/inicio_sesionn.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
    <style>
        .error-message {
            color: red;
            margin-top: 10px;
            text-align: center;
            display: none;
        }
    </style>
</head>
<body class="bg-white">
    <div class="d-flex justify-content-center align-items-center min-vh-100"> 
        <div class="w-100 border border-black border-2 border-opacity-75" style="max-width: 400px;"> 
          <form class="p-4 shadow rounded-3 bg-light">
            <h2 class="text-center mb-4">Iniciar sesión</h2> 
            
            <div class="mb-3">
              <label for="emailusu" class="form-label">Email</label>
              <input type="email" class="form-control" id="emailusu" placeholder="ejemplo@email.com">
            </div>
            
            <div class="mb-3 position-relative">
              <label for="Password" class="form-label">Contraseña</label>
              <div class="input-group">
                <input type="password" class="form-control" id="Password" placeholder="••••••••">
                <button 
                  type="button" 
                  class="btn btn-outline-secondary" 
                  onclick="verContraseña()">
                  <i id="passwordIcon" class="bi bi-eye"></i>
                </button>
              </div>
            </div>
            
            <div class="d-grid gap-2">
              <button type="button" onclick="IniciarSesion()" class="btn btn-primary">Ingresar</button>
            </div>
            
            <p id="errorMessage" class="error-message">Email o contraseña incorrectos.</p>
            <div class="text-center mt-3">
                <a href="crear_cuenta.html" class="text-decoration-none">¿Eres nuevo? -> Crear cuenta</a>
            </div>
            <div class="text-center mt-3">
                <a href="pagina_entrada.php" class="text-decoration-none">Volver</a>
            </div>
          </form>
        </div>
      </div>
</body>
</html>