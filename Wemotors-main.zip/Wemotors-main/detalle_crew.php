<?php
    require_once("php/funciones.php");

    $usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
    $inicio="";
    if(!isset($_SESSION['usuario_nombre'])){
        $inicio=' <li><a class="dropdown-item" href="inicio_sesion.php">Iniciar sesión</a></li>';
    } 
    
    $idC = $_GET['id'];
    $pertenece = false;
    $esAdmin = false;
    if(isset($_SESSION['usuario_id'])) {
        $pertenece = perteneceACrew($pdo, $_SESSION['usuario_id'], $idC);
        // Verificar si el usuario es admin de la crew
        $sql = "SELECT idAdmin FROM crews WHERE idCrew = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idC]);
        $crew = $stmt->fetch(PDO::FETCH_ASSOC);
        $esAdmin = ($crew && $crew['idAdmin'] == $_SESSION['usuario_id']);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="node_modules\bootstrap-icons\font\bootstrap-icons.css"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="javaScript\buscar_usuarios.js"></script>
    <link rel="stylesheet" href="solicitudes.css">
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
    <style>
         .profile-img {
            width: 200px;
            height: 200px;
            object-fit: cover;
        }
        .gallery-img {
            max-width: 100px;
            max-height: 150px;
            object-fit: cover;
        }
        .chat-container {
            height: 100%;
            background-color: #f8f9fa;
            border-left: 1px solid #dee2e6;
        }
        .chat-messages {
            height: calc(100% - 120px);
            overflow-y: auto;
            padding: 15px;
        }
        .chat-input {
            position: absolute;
            bottom: 0;
            width: 100%;
            padding: 15px;
            background-color: white;
            border-top: 1px solid #dee2e6;
        }
        .mensaje-chat {
            margin-bottom: 10px;
            padding: 8px 12px;
            border-radius: 15px;
            background-color: #e9ecef;
            max-width: 80%;
        }
        .mensaje-chat.propio {
            margin-left: auto;
            background-color: #007bff;
            color: white;
        }
        .nombre-usuario {
            font-weight: bold;
            font-size: 0.8rem;
        }
        .texto-mensaje {
            word-wrap: break-word;
        }
        .hora-mensaje {
            font-size: 0.7rem;
            text-align: right;
            opacity: 0.7;
        }
        .miembro-item {
            transition: background-color 0.2s;
        }
        .miembro-item:hover {
            background-color: #f8f9fa;
        }

        .btn-borrar-mensaje {
            padding: 0.1rem 0.3rem;
            font-size: 0.7rem;
            opacity: 0;
            transition: opacity 0.2s;
        }

        .mensaje-chat:hover .btn-borrar-mensaje {
            opacity: 1;
        }
    </style>
</head>
<body class=" h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link " href="inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="eventos.php">Eventos</a>
                </li>
                <li class="nav-item position-relative">
                    <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                    <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                </li>
            </ul>
           <div class="dropdown">
                <button  
                    class="btn btn-outline-light dropdown-toggle" 
                    type="button" 
                    id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false">
                    <?php echo $usuario; ?>
                         <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                            style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                            <span class="visually-hidden">Solicitudes pendientes</span>
                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                      <li class="dropdown-submenu">
                        <a class="dropdown-item dropdown-toggle" href="#" aria-expanded="false">Solicitudes</a>
                        <ul class="dropdown-menu" id="listaSolicitudes">
                            <?php echo generarHtmlSolicitudes($pdo); ?>
                        </ul>
                    </li>
                    <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
                </div>
        </div>
    </div>
</nav>
<div class="container-fluid px-lg-5 px-md-3 px-sm-2 mt-5 z-2">
    <div class="row">
      <!-- Contenido principal - ahora siempre ocupa 12 columnas si no pertenece -->
      <div class="<?= $pertenece ? 'col-lg-8' : 'col-12' ?>">
        <div class="border border-dark rounded-4 border-3 bg-dark mb-3 mx-auto p-3" style="max-width: 800px; min-height: 150px;">
            <div class="row text-white align-items-center py-3 px-2">
            <?php mostrarDatosCrew($pdo,$idC); ?>
            </div>
            <!-- Botones centrados -->
            <div class="row justify-content-center py-3">
                <div class="col-12 col-md-6 text-center">
                    <div class="d-flex justify-content-center gap-3">
                        <?php if(isset($_SESSION['usuario_id'])): ?>
                            <button class="btn <?= $pertenece ? 'btn-outline-danger' : 'btn-outline-warning' ?>" 
                                    onclick="manejarCrew()" 
                                    id="btnCrew">
                                <?= $pertenece ? 'Salir' : 'Unirse' ?>
                            </button>
                        <?php endif; ?>
                        <a href="tienda/tienda.php?idCrew=<?=$_GET['id']?>"> 
                            <button class="btn btn-outline-light">Ver tienda</button>
                        </a>
                        <?php if($esAdmin): ?>
                            <button class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#editarCrewModal">
                                <i class="bi bi-gear"></i> Editar Crew
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($pertenece): ?>
            <h2 class="mt-4 mt-md-5 mb-3 mb-md-4 text-center text-md-start text-white">Publicaciones</h2>
            <div class="row justify-content-center justify-content-md-start g-3">
                <?= mostrarPublicacionesCrew($pdo,$idC); ?>
            </div>
            <?php else: ?>
            <div class="text-center text-white py-4">
                <h3>Únete a esta crew para ver sus publicaciones</h3>
                <p>Haz clic en el botón "Unirse" para formar parte de esta crew y acceder a todo su contenido.</p>
            </div>
            <?php endif; ?>
        </div>
      </div>

      <!-- Sección de chat (derecha) - solo si pertenece -->
      <?php if($pertenece): ?>
      <div class="col-lg-4 z-2 mb-3"> 
        <div class="chat-container sticky-top" style="top: 80px; max-height: 720px; background-color: #e3e6e7; min-height: 350px;">
          <div class="p-3 border-bottom">
            <h4 class="mb-0">Chat de la Crew</h4>
          </div>
          <div class="chat-messages" id="chat-box">
            <!-- Los mensajes se cargarán aquí via AJAX -->
          </div>
          <div class="chat-input border-bottom">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Escribe un mensaje..." id="mensajeInput">
              <button class="btn btn-primary" type="button" onclick="enviarMensaje()">Enviar</button>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
</div>

  <!-- Modal para editar crew -->
  <?php if($esAdmin): ?>
  <div class="modal fade" id="editarCrewModal" tabindex="-1" aria-labelledby="editarCrewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editarCrewModalLabel">Editar Crew</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="nav nav-tabs" id="crewTabs" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info-tab-pane" type="button" role="tab" aria-controls="info-tab-pane" aria-selected="true">Información</button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="miembros-tab" data-bs-toggle="tab" data-bs-target="#miembros-tab-pane" type="button" role="tab" aria-controls="miembros-tab-pane" aria-selected="false">Miembros</button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="publicaciones-tab" data-bs-toggle="tab" data-bs-target="#publicaciones-tab-pane" type="button" role="tab" aria-controls="publicaciones-tab-pane" aria-selected="false">Publicaciones</button>
            </li>
          </ul>
          <div class="tab-content" id="crewTabsContent">
            <!-- Pestaña de información -->
            <div class="tab-pane fade show active" id="info-tab-pane" role="tabpanel" aria-labelledby="info-tab" tabindex="0">
              <form id="formEditarCrew" class="mt-3">
                <div class="mb-3">
                  <label for="nombreCrew" class="form-label">Nombre</label>
                  <input type="text" class="form-control" id="nombreCrew" name="nombreCrew" required>
                </div>
                <div class="mb-3">
                  <label for="descripcionCrew" class="form-label">Descripción</label>
                  <textarea class="form-control" id="descripcionCrew" name="descripcionCrew" rows="3"></textarea>
                </div>
                <div class="mb-3">
                  <label for="fotoCrew" class="form-label">Foto de perfil</label>
                  <input class="form-control" type="file" id="fotoCrew" name="fotoCrew" accept="image/*">
                </div>
                <div class="text-center">
                  <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </div>
              </form>
            </div>
            
            <!-- Pestaña de miembros -->
            <div class="tab-pane fade" id="miembros-tab-pane" role="tabpanel" aria-labelledby="miembros-tab" tabindex="0">
              <div class="mt-3" id="listaMiembros">
                <!-- Los miembros se cargarán aquí via AJAX -->
                Cargando miembros...
              </div>
            </div>
            
            <!-- Pestaña de publicaciones -->
            <div class="tab-pane fade" id="publicaciones-tab-pane" role="tabpanel" aria-labelledby="publicaciones-tab" tabindex="0">
              <div class="mt-3" id="listaPublicaciones">
                <!-- Las publicaciones se cargarán aquí via AJAX -->
                Cargando publicaciones...
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

<?php if($esAdmin): ?>
<!-- Modal para transferir admin -->
<div class="modal fade" id="transferirAdminModal" tabindex="-1" aria-labelledby="transferirAdminModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="transferirAdminModalLabel">Transferir administración</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Selecciona un nuevo administrador para la crew o la crew será eliminada si no hay miembros.</p>
                <div class="list-group" id="listaMiembrosTransferencia">
                    <!-- Los miembros se cargarán aquí via AJAX -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="btnEliminarCrew">Eliminar Crew</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
  <script src="navDesplegable.js"></script>
  <script>
    let primeraCargaChat = true;
    // Función para cargar los mensajes del chat
 function cargarChat() {
    fetch(`php/funciones.php?accion=mostrarChat&idCrew=<?=$idC?>`)
        .then(response => response.text())
        .then(data => {
            const chatBox = document.getElementById("chat-box");
            const estabaAbajo = chatBox.scrollHeight - chatBox.scrollTop === chatBox.clientHeight;
            
            document.getElementById("chat-box").innerHTML = data;
            
            // Añadir event listeners a los botones de borrado
            document.querySelectorAll('.btn-borrar-mensaje').forEach(btn => {
                btn.addEventListener('click', function() {
                    manejarBorradoMensaje(this.dataset.idMensaje);
                });
            });
            
            // Auto-scroll solo en primera carga o si ya estaba abajo
            if (primeraCargaChat || estabaAbajo) {
                chatBox.scrollTop = chatBox.scrollHeight;
                primeraCargaChat = false;
            }
        });
}

    // Función para enviar mensaje
    function enviarMensaje() {
        const mensaje = document.getElementById("mensajeInput").value.trim();
        if(mensaje === "") return;

        fetch(`php/funciones.php?accion=enviarMensaje&idCrew=<?=$idC?>&texto=${encodeURIComponent(mensaje)}`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    document.getElementById("mensajeInput").value = "";
                    cargarChat();
                }
            });
    }

    function manejarBorradoMensaje(idMensaje) {
        if (confirm('¿Estás seguro de que quieres borrar este mensaje?')) {
            fetch(`php/funciones.php?accion=borrarMensajeChat&idMensaje=${idMensaje}&idCrew=<?=$idC?>`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        cargarChat(); // Recargar el chat
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
        }
    }
    // Función principal para manejar unirse/salir de la crew
    function manejarCrew() {
        <?php if($esAdmin): ?>
            // Si es admin y está intentando salir, mostrar modal de transferencia
            const btn = document.getElementById("btnCrew");
            if(btn.textContent.trim() === 'Salir') {
                manejarSalidaAdmin();
                return; // Salir de la función después de mostrar el modal
            }
        <?php endif; ?>
        
        // Para usuarios normales o cuando no es salida de admin
        fetch(`php/funciones.php?accion=manejarCrew&idCrewpag=<?=$idC?>`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    // Actualizar el botón
                    const btn = document.getElementById("btnCrew");
                    btn.textContent = data.textoBoton;
                    btn.className = data.textoBoton === 'Salir' ? 'btn btn-outline-danger' : 'btn btn-outline-warning';
                    
                    // Mostrar u ocultar el chat según corresponda
                    if(data.pertenece) {
                        location.reload(); // Recargar para mostrar el chat
                    } else {
                        location.reload(); // Recargar para ocultar el chat
                    }
                }
            });
    }

    <?php if($esAdmin): ?>
    // Mostrar modal de transferencia cuando el admin intenta salir
 function manejarSalidaAdmin() {
    fetch(`php/funciones.php?accion=obtenerMiembrosCrew&idCrew=<?=$idC?>`)
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                const lista = document.getElementById('listaMiembrosTransferencia');
                lista.innerHTML = '';
                
                // Filtrar miembros excluyendo al admin actual
                const miembrosFiltrados = data.miembros.filter(miembro => miembro.idUsu != <?=$_SESSION['usuario_id'] ?? 0 ?>);
                
                if(miembrosFiltrados.length > 0) {
                    miembrosFiltrados.forEach(miembro => {
                        const item = document.createElement('button');
                        item.className = 'list-group-item list-group-item-action';
                        item.innerHTML = `
                            <div class="d-flex align-items-center">
                                <img src="${miembro.FotoPerfil ? 'data:image/jpeg;base64,' + miembro.FotoPerfil : 'img/default-profile.png'}" 
                                     class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                <span>${miembro.Nick}</span>
                            </div>
                        `;
                        item.onclick = () => transferirAdmin(miembro.idUsu);
                        lista.appendChild(item);
                    });
                } else {
                      lista.innerHTML = '<p class="text-center">No hay otros miembros en la crew. Si sales, la crew será eliminada.</p>';
                    document.getElementById('btnEliminarCrew').disabled = false;
                }
                
                // Mostrar el modal
                const modal = new bootstrap.Modal(document.getElementById('transferirAdminModal'));
                modal.show();
            }
        });
}

    // Función para transferir admin
    function transferirAdmin(idNuevoAdmin) {
        if(confirm('¿Estás seguro de transferir la administración a este miembro y salir de la crew?')) {
            fetch(`php/funciones.php?accion=transferirAdmin&idCrew=<?=$idC?>&idNuevoAdmin=${idNuevoAdmin}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('Administración transferida con éxito');
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
        }
    }

    // Función para eliminar la crew
    document.getElementById('btnEliminarCrew').addEventListener('click', function() {
        if(confirm('¿Estás seguro de eliminar permanentemente esta crew? Esta acción no se puede deshacer.')) {
            fetch(`php/funciones.php?accion=eliminarCrew&idCrew=<?=$idC?>`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        alert('Crew eliminada con éxito');
                        window.location.href = 'crews.php';
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
        }
    });
    <?php endif; ?>

    // Cargar el chat inicialmente y cada 2 segundos
    <?php if($pertenece): ?>
     primeraCargaChat = true;
    cargarChat();
    setInterval(cargarChat, 2000);
    <?php endif; ?>

    <?php if($esAdmin): ?>
    // Cargar datos de la crew al abrir el modal
    document.getElementById('editarCrewModal').addEventListener('shown.bs.modal', function () {
        cargarDatosCrew();
        cargarMiembrosCrew();
        cargarPublicacionesCrew();
    });

    // Función para cargar datos de la crew
    function cargarDatosCrew() {
        fetch(`php/funciones.php?accion=obtenerDatosCrew&idCrew=<?=$idC?>`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    document.getElementById('nombreCrew').value = data.crew.Nombre;
                    document.getElementById('descripcionCrew').value = data.crew.Descripcion;
                }
            });
    }

    // Función para cargar miembros de la crew
    function cargarMiembrosCrew() {
        fetch(`php/funciones.php?accion=obtenerMiembrosCrew&idCrew=<?=$idC?>`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    let html = '';
                    if(data.miembros.length > 0) {
                        html = '<div class="list-group">';
                        data.miembros.forEach(miembro => {
                            html += `
                            <div class="list-group-item d-flex justify-content-between align-items-center miembro-item">
                                <div class="d-flex align-items-center">
                                    <img src="${miembro.FotoPerfil ? 'data:image/jpeg;base64,' + miembro.FotoPerfil : 'img/default-profile.png'}" 
                                         class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                    <span>${miembro.Nick}</span>
                                </div>
                                ${miembro.idUsu != <?=$_SESSION['usuario_id'] ?? 0 ?> ? 
                                    `<button class="btn btn-sm btn-danger" onclick="expulsarMiembro(${miembro.idUsu})">
                                        <i class="bi bi-person-x"></i> Expulsar
                                    </button>` : 
                                    '<span class="badge bg-primary">Admin</span>'
                                }
                            </div>`;
                        });
                        html += '</div>';
                    } else {
                        html = '<p class="text-center">No hay miembros en esta crew.</p>';
                    }
                    document.getElementById('listaMiembros').innerHTML = html;
                }
            });
    }

    // Función para cargar publicaciones de la crew
    function cargarPublicacionesCrew() {
    fetch(`php/funciones.php?accion=obtenerPublicacionesCrewAdmin&idCrew=<?=$idC?>`)
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                const listaPublicaciones = document.getElementById('listaPublicaciones');
                listaPublicaciones.innerHTML = '';
                
                if(data.publicaciones && data.publicaciones.length > 0) {
                    listaPublicaciones.innerHTML = '<div class="row g-3" id="gridPublicaciones"></div>';
                    const grid = document.getElementById('gridPublicaciones');
                    
                    data.publicaciones.forEach(publicacion => {
                        const publicacionElement = document.createElement('div');
                        publicacionElement.className = 'col-md-4 mb-3';
                        publicacionElement.innerHTML = `
                            <div class="card h-100">
                                <img src="${publicacion.Foto ? 'data:image/jpeg;base64,' + publicacion.Foto : 'img/default-post.jpg'}" 
                                    class="card-img-top" 
                                    style="height: 150px; object-fit: cover;">
                                <div class="card-body">
                                    <p class="card-text">${publicacion.DescripcionPubli || 'Sin descripción'}</p>
                                    <div class="d-flex justify-content-between">
                                        <small class="text-muted">${new Date(publicacion.fecPublicacion).toLocaleDateString()}</small>
                                        <div>
                                            <button class="btn btn-sm btn-outline-danger eliminar-publicacion-crew" 
                                                    data-id="${publicacion.idPubli}">
                                                <i class="bi bi-trash"></i> Borrar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                        grid.appendChild(publicacionElement);
                    });
                    
                    // Agregar eventos a los botones de eliminar
                    document.querySelectorAll('.eliminar-publicacion-crew').forEach(btn => {
                        btn.addEventListener('click', function() {
                            eliminarPublicacionCrew(this.dataset.id);
                        });
                    });
                } else {
                    listaPublicaciones.innerHTML = '<div class="col-12 text-center py-4">No hay publicaciones</div>';
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            const listaPublicaciones = document.getElementById('listaPublicaciones');
            listaPublicaciones.innerHTML = `
                <div class="col-12 text-center py-4 text-danger">
                    Error al cargar publicaciones: ${error.message}
                </div>`;
        });
}

    // Función para expulsar a un miembro
    function expulsarMiembro(idUsuario) {
        if(confirm('¿Estás seguro de que deseas expulsar a este miembro?')) {
            fetch(`php/funciones.php?accion=expulsarMiembro&idCrew=<?=$idC?>&idUsuario=${idUsuario}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        cargarMiembrosCrew();
                        // Actualizar contador de miembros en la página principal
                        if(document.getElementById('contadorMiembros')) {
                            document.getElementById('contadorMiembros').textContent = data.nuevoConteo;
                        }
                    }
                });
        }
    }

    // Función para eliminar una publicación de la crew
    function eliminarPublicacionCrew(idPublicacion) {
    if(confirm('¿Estás seguro de que deseas eliminar esta publicación?')) {
        fetch(`php/funciones.php?accion=eliminarPublicacionCrew&idPubli=${idPublicacion}&idCrew=<?=$idC?>`)
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    cargarPublicacionesCrew();

                } else {
                    alert('Error: ' + data.message);
                }
            });
    }
}

    // Manejar el envío del formulario de edición
    document.getElementById('formEditarCrew').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData();
        formData.append('nombre', document.getElementById('nombreCrew').value);
        formData.append('descripcion', document.getElementById('descripcionCrew').value);
        
        const fotoInput = document.getElementById('fotoCrew');
        if(fotoInput.files[0]) {
            formData.append('foto', fotoInput.files[0]);
        }
        formData.append('idCrew', <?=$idC?>);
        formData.append('accionP', 'actualizarCrew'); // Asegúrate de incluir esto

        fetch('php/funciones.php?accionP=actualizarCrew', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if(data.success) {
                alert('Crew actualizada correctamente');
                // Recargar la página para ver los cambios
                location.reload();
            } else {
                alert('Error al actualizar: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ocurrió un error al actualizar la crew');
        });
    });
    <?php endif; ?>
</script>
<?php require_once("footer.html");?>
<script src="javaScript/solicitud.js"></script>
</body> 
</html>