<?php
require_once("php/funciones.php");
if (!isset($_GET['id'])) {
    header("Location: inicio.php");
    exit();
}
 if(!isset($_SESSION['usuario_id'])){
  header("Location: pagina_entrada.php"); 
 }

$idUsuario = $_GET['id'];
$esMiPerfil = isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] == $idUsuario;
$usuarioPerfil = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';

$usuario = obtenerDatosUsuario($pdo, $idUsuario);
if (!$usuario) {
    header("Location: inicio.php");
    exit();
}

$puedeVerContenido = $esMiPerfil || puedeVerContenido($pdo, $idUsuario, $_SESSION['usuario_id'] ?? 0);
$siguiendo = false;

if(isset($_SESSION['usuario_id'])) {
    $siguiendo = yaSigueUsuario($pdo, $_SESSION['usuario_id'], $idUsuario);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de <?= htmlspecialchars($usuario['Nick']) ?></title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <script src="javaScript/buscar_usuarios.js"></script>
     <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" href="inicio.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="crews.php">Crew</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="eventos.php">Eventos</a>
                </li>
                <li class="nav-item position-relative">
                    <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                    <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                </li>
            </ul>
            <div class="dropdown">
                <button 
                    class="btn btn-outline-light dropdown-toggle" 
                    type="button" 
                    id="dropdownMenuButton" 
                    data-bs-toggle="dropdown" 
                    aria-expanded="false">
                    <?php echo $usuarioPerfil ; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                    <li><a class="dropdown-item" href="#">Solicitudes</a></li>
                    <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
    <div class="container-fluid px-lg-5 px-md-3 px-sm-2 mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="border border-dark rounded-4 border-3 bg-dark mb-3 mx-auto p-3" style="max-width: 800px;">
                    <div class="row text-white align-items-center py-3 px-2">
                        <div class="col-12 col-md-auto text-center text-md-start mb-3 mb-md-0">
                            <img src="<?= $usuario['FotoPerfil'] ? 'data:image/jpeg;base64,'.base64_encode($usuario['FotoPerfil']) : 'img/default-profile.png' ?>" 
                                 class="img-fluid rounded-circle mx-auto d-block" 
                                 style="height: 100px; width: 100px;">
                        </div>
                        <div class="col-12 col-md-6">
                            <h1 class="mb-1"><?= htmlspecialchars($usuario['Nick']) ?></h1>
                            <p class="mb-0"><?= htmlspecialchars($usuario['Descripcion'] ?? '') ?></p>
                        </div>
                        <div class="col-12 col-md-4 text-center text-md-end mt-3 mt-md-0">
                            <?php if (!$esMiPerfil && isset($_SESSION['usuario_id'])): 
                                $estadoSeguimiento = yaSigueUsuario($pdo, $_SESSION['usuario_id'], $idUsuario);
                            ?>
                                <?php if ($estadoSeguimiento === 'siguiendo'): ?>
                                    <button id="seguirBtn" class="btn btn-outline-danger">Dejar de seguir</button>
                                <?php elseif ($estadoSeguimiento === 'pendiente'): ?>
                                    <button id="seguirBtn" class="btn btn-outline-secondary" disabled>Pendiente</button>
                                <?php else: ?>
                                    <button id="seguirBtn" class="btn btn-outline-warning">Seguir</button>
                                <?php endif; ?>
                                
                                <!-- Botón de reportar -->
                                <?php if (!$esMiPerfil): ?>
                                    <button class="btn btn-link text-danger p-0 ms-2" 
                                            onclick="abrirReporteModal('usuario', <?= $idUsuario ?>, '<?= htmlspecialchars($usuario['Nick']) ?>')">
                                        <i class="bi bi-flag-fill"></i>
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row text-white text-center py-3">
                        <div class="col-4">
                            <h5 class="mb-0"><?= $usuario['numPublicaciones'] ?></h5>
                            <small>Publicaciones</small>
                        </div>
                        <div class="col-4">
                            <h5 class="mb-0"><?= $usuario['seguidores'] ?></h5>
                            <small>Seguidores</small>
                        </div>
                        <div class="col-4">
                            <h5 class="mb-0"><?= $usuario['siguiendo'] ?></h5>
                            <small>Siguiendo</small>
                        </div>
                    </div>
                </div>
              
                <!-- Publicaciones del usuario -->
      <?php if (!$puedeVerContenido): ?>
                 <div class="border border-dark rounded-3 border-3 p-3 p-md-4 mx-auto mb-5" style="max-width: 800px;">
                    <div class="text-center py-4">
                        <h3>Cuenta privada</h3>
                        <p>Sigue a este usuario para ver su contenido</p>
                        <?php if ($estadoSeguimiento === 'pendiente'): ?>
                            <p class="text-muted">Solicitud de seguimiento pendiente</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <!-- Publicaciones del usuario -->
                <div class="border border-dark rounded-3 border-3 p-3 p-md-4 mx-auto mb-5" style="max-width: 800px;">
                    <?php echo mostrarVehiculosUsuario($pdo, $idUsuario); ?>
                    <h2 class="mb-4">Publicaciones</h2>
                    <div class="row justify-content-center g-3" id="publicaciones-container">
                        <?php 
                        $publicaciones = obtenerPublicacionesUsuario($pdo, $idUsuario);
                        if (empty($publicaciones)): ?>
                            <div class="col-12 text-center py-4">
                                <p class="text-muted">No hay publicaciones registradas</p>
                            </div>
                        <?php else: 
                            foreach($publicaciones as $publicacion): ?>
                                <div class="col-8 col-md-6 col-lg-4 text-center">
                                   <a href="Mirar_publicacion.php?idPubli=<?=$publicacion["idPubli"]?>"> <img src="data:image/jpeg;base64,<?= base64_encode($publicacion['Foto']) ?>" 
                                        class="img-fluid" 
                                        style="height: 220px; width: 220px; object-fit: cover;"></a>
                                </div>
                            <?php endforeach;
                        endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once("footer.html");?>
<?php include("reportar_modal.php"); ?>
    <script>
        // Script para manejar el botón de seguir
        document.getElementById('seguirBtn')?.addEventListener('click', function() {
        const userId = <?= $idUsuario ?>;
        const seguir = this.textContent.trim() === 'Seguir';

        fetch(`php/funciones.php?accion=${seguir ? 'seguirUsuario' : 'dejarSeguirUsuario'}&idUsuario=${userId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.pendiente) {
                        this.textContent = 'Pendiente';
                        this.classList.remove('btn-outline-warning');
                        this.classList.add('btn-outline-secondary');
                        this.disabled = true;
                    } else {
                        this.textContent = seguir ? 'Dejar de seguir' : 'Seguir';
                        this.classList.toggle('btn-outline-warning');
                        this.classList.toggle(seguir ? 'btn-outline-danger' : 'btn-outline-warning');
                    }
                    // Recargar la página para actualizar contadores
                    location.reload();
                }
            });
        });

        function redirigirAPerfil(userId) {
              window.location.href = 'perfil_ajeno.php?id=' + userId;
        }
    </script>
</body>
</html>