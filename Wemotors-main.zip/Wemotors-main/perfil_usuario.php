<?php
     require_once("php/funciones.php");
      $usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
       if(!isset($_SESSION['usuario_id'])){
        header("Location: pagina_entrada.php"); 
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi perfil</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
       <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="solicitudes.css">
    <script src="javaScript/buscar_usuarios.js"></script>
    <script src="javaScript/perfil.js"></script>
    <script src="javaScript/editar_perfil.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
  <style>
    /* Estilos para botones en móviles */
    @media (max-width: 575.98px) {
        #editarPerfilModal .btn span {
            display: inline !important; /* Mostrar texto siempre */
            font-size: 0.8rem;
            margin-left: 0.25rem;
        }
        
        #editarPerfilModal .btn i {
            margin-right: 0.25rem;
        }
        
        /* Ajustar espaciado */
        #editarPerfilModal .btn {
            padding: 0.5rem;
            min-width: auto;
        }
    }

    /* Asegurar que los botones no se rompan */
    #editarPerfilModal .modal-footer .btn {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        min-width: max-content;
        color: white;
    }

    #listaComentarios {
    border: 1px solid #dee2e6;
    border-radius: 0.25rem;
    padding: 1rem;
}

    .comment-card {
        margin-bottom: 1rem;
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
    }

    .comment-card:last-child {
        margin-bottom: 0;
    }

    .comment-avatar {
        max-width: 40px;
        max-height: 40px;
        border-radius: 50%;
        object-fit: cover;
        margin-right: 1rem;
    }
    
    .comment-content {
        flex: 1;
    }
    
    .comment-card {
        margin-bottom: 1rem;
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
        padding: 1rem;
    }
    
    #listaComentarios {
        border: 1px solid #dee2e6;
        border-radius: 0.25rem;
        padding: 1rem;
    }
    
    /* Estilos para la pestaña de vehículos */
    .vehiculo-card {
        position: relative;
        margin-bottom: 1.5rem;
        border: 1px solid #dee2e6;
        border-radius: 0.5rem;
        padding: 1rem;
    }
    
    .vehiculo-img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-radius: 0.25rem;
        margin-bottom: 1rem;
    }
    
    .btn-eliminar-vehiculo {
        position: absolute;
        top: 0.5rem;
        right: 0.5rem;
    }
    
    #listaVehiculos {
        max-height: 400px;
        overflow-y: auto;
    }
    
    /* Estilos para el modal de confirmación de eliminación de vehículo */
    #confirmarEliminarVehiculoModal .modal-body {
        padding: 1.5rem;
    }
    #propio{

        display:none;
    }
</style>
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand navbar-brand-custom" href="inicio.html">Wemotors</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="inicio.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="crews.php">Crew</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="eventos.php">Eventos</a>
                    </li>
                    <li class="nav-item position-relative">
                      <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                      <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                    </li>
                </ul>
                <div class="dropdown">
                    <button 
                        class="btn btn-outline-light dropdown-toggle" 
                        type="button" 
                        id="dropdownMenuButton" 
                        data-bs-toggle="dropdown" 
                        aria-expanded="false">
                        <?php echo $usuario ?>

                        <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                            style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                            <span class="visually-hidden">Solicitudes pendientes</span>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                            <ul class="dropdown-menu" id="listaSolicitudes">
                                <?php echo generarHtmlSolicitudes($pdo); ?>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div id="Perfil"></div>
    <?php require_once("footer.html");?>
  <!-- Modal Editar Perfil -->
<div class="modal fade" id="editarPerfilModal" tabindex="-1" aria-labelledby="editarPerfilModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="editarPerfilModalLabel">Editar Perfil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs" id="perfilTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="datos-tab" data-bs-toggle="tab" data-bs-target="#datos" type="button" role="tab">Datos</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="publicaciones-tab" data-bs-toggle="tab" data-bs-target="#publicaciones" type="button" role="tab">Publicaciones</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="vehiculos-tab" data-bs-toggle="tab" data-bs-target="#vehiculos" type="button" role="tab">Vehículos</button>
                    </li>
                </ul>
                
                <div class="tab-content p-3">
                    <!-- Pestaña de Datos -->
                    <div class="tab-pane fade show active" id="datos" role="tabpanel">
                        <form id="formEditarPerfil" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="editNick" class="form-label">Nombre de usuario</label>
                                <input type="text" class="form-control" id="editNick" name="editNick" required>
                            </div>
                            <div class="mb-3">
                                <label for="editDescripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" id="editDescripcion" name="editDescripcion" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="editFoto" class="form-label">Cambiar foto de perfil</label>
                                <input class="form-control" type="file" id="editFoto" name="editFoto" accept="image/*">
                                <div class="form-text">Formatos aceptados: JPG, PNG, GIF (Máx. 2MB)</div>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="editPrivada" name="editPrivada">
                                <label class="form-check-label" for="editPrivada">
                                    Cuenta privada
                                </label>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Pestaña de Publicaciones -->
                    <div class="tab-pane fade" id="publicaciones" role="tabpanel">
                        <div class="row" id="listaPublicaciones">
                            <!-- Las publicaciones se cargarán aquí dinámicamente -->
                        </div>
                    </div>
                    
                    <!-- Pestaña de Vehículos -->
                    <div class="tab-pane fade" id="vehiculos" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5>Mis Vehículos</h5>
                        </div>
                        <div id="listaVehiculos" class="row">
                            <!-- Los vehículos se cargarán aquí dinámicamente -->
                        </div>
                    </div>
                </div>
            </div>
        <div class="modal-footer">
            <div class="d-flex flex-column flex-md-row justify-content-between w-100 gap-2">
                    <button type="button" class="btn btn-danger order-md-1" id="btnEliminarCuenta">
                        <i class="bi bi-trash-fill me-1"></i>
                        <span class="text-white">Eliminar cuenta</span>
                    </button>
                    <div class="d-flex flex-column flex-md-row gap-2">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-lg me-1"></i>
                            <span>Cancelar</span>
                        </button>
                        <button type="submit" form="formEditarPerfil" class="btn btn-primary">
                            <i class="bi bi-check-lg me-1"></i>
                            <span>Guardar cambios</span>
                        </button>
                    </div>
                </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Eliminación -->
<div class="modal fade" id="confirmarEliminarModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirmar eliminación</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.</p>
                <div class="mb-3">
                    <label for="confirmPassword" class="form-label">Ingresa tu contraseña para confirmar:</label>
                    <input type="password" class="form-control" id="confirmPassword" required>
                </div>
            </div>
           <div class="modal-footer">
                <div class="d-flex flex-column flex-md-row gap-2 w-100">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-lg"></i>
                        <span class="ms-1 d-none d-sm-inline">Cancelar</span>
                    </button>
                    <button type="submit" form="formEditarPerfil" class="btn btn-primary">
                        <i class="bi bi-check-lg"></i>
                        <span class="ms-1 d-none d-sm-inline">Guardar cambios</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Eliminación de Vehículo -->
<div class="modal fade" id="confirmarEliminarVehiculoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirmar eliminación</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que quieres eliminar este vehículo? Esta acción no se puede deshacer.</p>
                <input type="hidden" id="idVehiculoEliminar">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg me-1"></i>
                    <span>Cancelar</span>
                </button>
                <button type="button" class="btn btn-danger" id="btnConfirmarEliminarVehiculo">
                    <i class="bi bi-trash-fill me-1"></i>
                    <span>Eliminar</span>
                </button>
            </div>
        </div>
    </div>
</div>

<script src="navegDesplegable.js"></script>
<script src="javaScript/solicitud.js"></script>
</body>
</html>