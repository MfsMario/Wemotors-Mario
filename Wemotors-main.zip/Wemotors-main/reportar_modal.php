<?php
// reportar_modal.php
require_once("php/funciones.php");
?>
<!-- Modal para reportar -->
<div class="modal fade" id="reportarModal" tabindex="-1" aria-labelledby="reportarModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="reportarModalLabel">Reportar</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="formReporte">
          <input type="hidden" id="tipoReporte" name="tipoReporte">
          <input type="hidden" id="idReportado" name="idReportado">
          
          <div class="mb-3">
            <label for="nombreReportado" class="form-label">Reportando a:</label>
            <input type="text" class="form-control" id="nombreReportado" disabled>
          </div>
          
          <div class="mb-3">
            <label for="descripcionReporte" class="form-label">Motivo del reporte:</label>
            <textarea class="form-control" id="descripcionReporte" name="descripcionReporte" rows="4" required></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-danger" id="enviarReporte">Enviar Reporte</button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Manejar el envío del reporte
  document.getElementById('enviarReporte').addEventListener('click', function() {
    const tipo = document.getElementById('tipoReporte').value;
    const idReportado = document.getElementById('idReportado').value;
    const descripcion = document.getElementById('descripcionReporte').value;
    
    if (!descripcion.trim()) {
      alert('Por favor, describe el motivo del reporte.');
      return;
    }
    
    const formData = new FormData();
    formData.append('accionP', 'reportar');
    formData.append('tipo', tipo);
    formData.append('idReportado', idReportado);
    formData.append('descripcion', descripcion);
    
    fetch('php/funciones.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('Reporte enviado correctamente.');
        const modal = bootstrap.Modal.getInstance(document.getElementById('reportarModal'));
        modal.hide();
      } else {
        alert('Error al enviar el reporte: ' + (data.message || 'Inténtalo de nuevo más tarde.'));
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Error al enviar el reporte.');
    });
  });
});

// Función para abrir el modal de reporte
function abrirReporteModal(tipo, id, nombre) {
  document.getElementById('tipoReporte').value = tipo;
  document.getElementById('idReportado').value = id;
  document.getElementById('nombreReportado').value = nombre;
  document.getElementById('descripcionReporte').value = '';
  
  const modal = new bootstrap.Modal(document.getElementById('reportarModal'));
  modal.show();
}
</script>