<?php
    require_once("php/funciones.php");
     if(!isset($_SESSION['usuario_id'])){
        header("Location: pagina_entrada.php"); 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir vehiculo</title>
    <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="css_inicio.css"/>
    <link rel="stylesheet" href="node_modules\bootstrap-icons\font\bootstrap-icons.css"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
</head>
<body class="h-100 bg-white m-0 p-0 ">
      <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="w-100  border border-black border-2 border-opacity-75" style="max-width: 400px;">
          <form class="p-4 shadow rounded-3 bg-light">
            <h2 class="text-center mb-4">Añadir Vehiculo</h2>
            <div id="errorMessage" class="alert alert-danger d-none"></div>
            
            <div class="mb-3">
                <label for="FotoVehiculo" class="form-label">Foto del vehiculo</label>
                <input class="form-control" type="file" id="FotoVehiculo">
            </div>
            <div class="mb-3">
                <label for="marcaCoche" class="form-label">Marca</label>
                <select id="marcaCoche" class="form-select" name="idMarca"  size="5" required>
                    <option value="" selected disabled>Cargando marcas...</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="modeloCoche" class="form-label">Modelo</label>
                <select id="modeloCoche" class="form-select" name="idModelo" size="3" required>
                    <option value="" selected disabled>Selecciona una marca primero</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="vehiculoAgno" class="form-label">Año del Vehículo</label>
                <select class="form-select" id="vehiculoAgno" size="4" required>
                    <option value="" selected disabled>Selecciona el año</option>
                    <?php 
                    $currentYear = date("Y");
                    for ($year = $currentYear; $year >= ($currentYear - 50); $year--) {
                        echo '<option value="'.$year.'">'.$year.'</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="d-grid gap-2">
              <button type="submit" id="AñadirVehiculos" class="btn btn-primary">Añadir vehiculo</button>
            </div>
            <div class="text-center mt-3">
                <a href="perfil_usuario.php" class="text-decoration-none">Volver</a>
            </div>
          </form>
        </div>
      </div>
      <script src="javaScript/crear_vehiculo.js"></script>
</body>
</html>