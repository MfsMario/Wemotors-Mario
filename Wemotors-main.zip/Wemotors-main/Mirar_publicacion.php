<?php
// mostrar_publicacion.php
require_once 'php/funciones.php';

$usuario = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Usuario';
// Verificar si se proporcionó un ID de publicación
if (!isset($_GET['idPubli'])) {
    die("ID de publicación no especificado");
}

$idPubli = $_GET['idPubli'];

// Obtener los datos de la publicación
$sql = "SELECT p.*, u.*, m.Nombre as marcaNombre, m.Pais 
        FROM publicaciones p
        INNER JOIN usuarios u ON u.idUsu = p.idUsu
        INNER JOIN marca m ON m.idMarca = p.idMarca
        WHERE p.idPubli = :idPubli";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(':idPubli', $idPubli, PDO::PARAM_INT);
$stmt->execute();

if ($stmt->rowCount() == 0) {
    die("Publicación no encontrada");
}

$publicacion = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar si el usuario actual dio like a esta publicación
$usuarioDioLike = isset($_SESSION['usuario_id']) ? yaDioLike($pdo, $publicacion['idPubli'], $_SESSION['usuario_id']) : false;

// Generar el HTML de la publicación (similar a ListarPublicaciones)
$imagenBase64 = base64_encode($publicacion["Foto"]);
$imagenSrc = 'data:image/jpeg;base64,'.$imagenBase64;
            
$perfilBase64 = base64_encode($publicacion["FotoPerfil"]);
$perfilSrc = 'data:image/jpeg;base64,'.$perfilBase64;

// Obtener cantidad de comentarios
$cantidadComentarios = obtenerCantidadComentarios($pdo, $publicacion['idPubli']);

// Generar el HTML
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publicación - <?php echo htmlspecialchars($publicacion["Nick"]); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="solicitudes.css">
    <link rel="stylesheet" href="css_inicio.css"/>
    <script src="javaScript\buscar_usuarios.js"></script>
    <script src="javaScript\likes.js"></script>
    <script src="javaScript\comentarios_publicaciones.js"></script>
    <link rel="icon" href="./imagenes/logo wemotors.png" type="image/png">
  <style>
        body {
            background-color: #f8f9fa;
            padding-top: 0;
        }
        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }
        .card-header {
            background-color: #343a40;
        }
        .like-btn:hover, .comment-btn:hover {
            transform: scale(1.1);
            transition: transform 0.2s;
        }

        .bi-heart-fill.text-danger {
            color: #dc3545 !important;
            fill: #dc3545 !important;
            -webkit-text-fill-color: #dc3545 !important;
        }

        .bi-heart {
            color: #6c757d !important;
            fill: transparent !important;
        }

        .bi-heart, .bi-heart-fill {
            transition: all 0.3s ease;
        }

        .comment-avatar {
            width: 40px !important;
            height: 40px !important;
            min-width: 40px;
            object-fit: cover;
            border-radius: 50% !important;
        }
        .comment-content {
            margin-left: 12px;
            flex-grow: 1;
            min-width: 0;
        }

        .comment-card {
            border: none !important;
            border-radius: 10px !important;
            background-color: #f8f9fa !important;
            margin-bottom: 12px !important;
        }

        /* Sidebar de comentarios */
        #commentsSidebar {
            border-radius: 0.5rem 0 0 0.5rem !important;
            box-shadow: -5px 0 15px rgba(80, 76, 76, 0.1);
        }

        #commentsContainer {
            overflow-y: auto;
            max-height: calc(100vh - 150px);
        }

        .comment-card {
            border: 1px solid #dee2e6 !important;
            border-radius: 10px !important;
            background-color: white !important;
            margin: 12px !important;
            padding: 12px !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        #commentInput:focus {
            border-color: #495057 !important;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }

        #sendComment {
            transition: all 0.2s ease;
        }

        #sendComment:hover {
            background-color: #0b5ed7 !important;
        }

        /* Estilos responsive */
        @media (max-width: 768px) {
            .container {
                padding-left: 10px;
                padding-right: 10px;
            }
            
            #commentsSidebar {
                width: 100% !important;
                height: 60vh !important;
                border-radius: 0.5rem !important;
            }
            
            .card-header span {
                font-size: 0.9rem;
            }
            
            .card-footer .d-flex {
                justify-content: center;
            }
        }

        @media (max-width: 576px) {
            .card-header {
                padding: 0.5rem;
            }
            
            .card-header span, .card-header .badge {
                font-size: 0.8rem;
            }
            
            .card-footer {
                padding: 0.75rem;
            }
            
            .bi-heart, .bi-chat-left-text {
                font-size: 1.2rem !important;
            }
        }
    </style>
</head>
<body class="h-100 bg-white m-0 p-0 d-flex flex-column min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand navbar-brand-custom" href="inicio.php">Wemotors</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="inicio.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="crews.php">Crew</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="eventos.php">Eventos</a>
                    </li>
                    <li class="nav-item position-relative">
                        <input type="text" class="form-control  ms-3" id="userSearch" placeholder="Buscar usuarios..." autocomplete="off">
                        <div id="searchResults" class="position-absolute w-100 bg-white mt-1 rounded shadow d-none" style="z-index: 1000;"></div>
                    </li>
                </ul>
                <div class="dropdown">
                    <button 
                        class="btn btn-outline-light dropdown-toggle" 
                        type="button" 
                        id="dropdownMenuButton" 
                        data-bs-toggle="dropdown" 
                        aria-expanded="false">
                        <?php echo $usuario; ?>

                         <span id="notificacionSolicitudes" class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle" 
                                style="display: <?php echo (tieneSolicitudesPendientes($pdo, $_SESSION['usuario_id'] ?? 0)) ? 'block' : 'none'; ?>;">
                                <span class="visually-hidden">Solicitudes pendientes</span>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" id="userDropdown">
                         <li class="dropdown-submenu">
                                <a class="dropdown-item dropdown-toggle" href="#">Solicitudes</a>
                                <ul class="dropdown-menu" id="listaSolicitudes">
                                    <?php echo generarHtmlSolicitudes($pdo); ?>
                                </ul>
                            </li>
                        <li><a class="dropdown-item" href="perfil_usuario.php">Perfil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar Sesión</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-12 col-md-10 col-lg-8">
                <div class="card text-center border border-dark border-2 border-opacity-75 mb-4">
                    <div class="card-header d-flex align-items-center bg-dark text-white">
                        <a href="perfil_ajeno.php?id=<?php echo $publicacion["idUsu"]; ?>">
                            <img src="<?php echo $perfilSrc; ?>" class="rounded-circle me-2" style="width: 40px; height: 40px;">
                        </a>
                        <span><?php echo htmlspecialchars($publicacion["Nick"]); ?></span>
                        <span class="badge bg-primary ms-2"><?php echo htmlspecialchars($publicacion["marcaNombre"]); ?></span>
                        
                        <?php if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] != $publicacion['idUsu']): ?>
                            <div class="ms-auto">
                                <button class="btn btn-link text-danger p-0" 
                                        onclick="abrirReporteModal('usuario', <?php echo $publicacion['idUsu']; ?>, '<?php echo htmlspecialchars($publicacion['Nick']); ?>')">
                                    <i class="bi bi-flag-fill"></i>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-body p-0">
                        <div style="width: 100%; height: 0; padding-bottom: 70%; overflow: hidden; position: relative;">
                            <img src="<?php echo $imagenSrc; ?>" alt="Publicación" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                        </div>
                    </div>
                    
                    <div class="card-footer text-body-secondary p-3 bg-dark text-white">
                        <div class="text-start mb-2">
                            <p class="m-0 text-white"><?php echo htmlspecialchars($publicacion["DescripcionPubli"]); ?></p>
                        </div>
                        <hr class="mt-2 mb-3 border-white border-3">
                        
                        <div class="d-flex align-items-center ps-1">
                            <i class="bi <?php echo ($usuarioDioLike ? 'bi-heart-fill text-danger' : 'bi-heart text-secondary'); ?> fs-4 like-btn text-white" 
                               data-publi-id="<?php echo $publicacion['idPubli']; ?>" 
                               style="cursor: pointer;"></i>
                            <span class="ms-2 like-count text-white"><?php echo $publicacion["NLikes"]; ?></span>
                            
                            <button class="btn btn-link text-dark p-0 ms-3 comment-btn" 
                                data-publi-id="<?php echo $publicacion['idPubli']; ?>"
                                data-bs-toggle="offcanvas" 
                                data-bs-target="#commentsSidebar">
                                <i class="bi bi-chat-left-text fs-4 text-white"></i>
                            </button>
                            <span class="ms-2 text-white"><?php echo $cantidadComentarios; ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-3">
                    <a href="javascript:history.back()" class="btn btn-dark mb-4">Volver</a>
                </div>
            </div>
        </div>
    </div>


    <!-- Sidebar de comentarios -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="commentsSidebar" aria-labelledby="commentsSidebarLabel" style="width: 450px; border-left: 3px solid #000;">
        <div class="offcanvas-header bg-light" style="border-bottom: 2px solid #4C585B; border-radius: 0 0.375rem 0 0;">
            <h5 class="offcanvas-title fw-bold" id="commentsSidebarLabel">Comentarios</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body p-0" id="commentsContainer" style="background-color: #f8f9fa; border-radius: 0.375rem;">
            <!-- Los comentarios se cargarán aquí dinámicamente -->
        </div>
        <div class="border-top p-3" style="border-top: 2px solid #000 !important; border-radius: 0 0 0.375rem 0.375rem;">
            <?php if(isset($_SESSION['usuario_id'])): ?>
            <div class="input-group mb-0">
                <input type="text" id="commentInput" class="form-control border-dark" placeholder="Escribe un comentario..." style="border-radius: 20px 0 0 20px;">
                <button class="btn btn-primary" type="button" id="sendComment" style="border-radius: 0 20px 20px 0;">
                <i class="bi bi-send-fill"></i>
                </button>
            </div>
            <?php else: ?>
            <div class="alert alert-warning mb-0">
                <a href="inicio_sesion.php" class="alert-link">Inicia sesión</a> 
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="offcanvas-backdrop fade show d-none" id="commentsBackdrop" style="display: none;"></div>
    <!-- Incluir scripts necesarios -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Función para manejar likes (similar a la que usarías en tu aplicación principal)
        document.querySelectorAll('.like-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const publiId = this.getAttribute('data-publi-id');
                const isLiked = this.classList.contains('bi-heart-fill');
                
                fetch('funciones.php?accion=dar_like', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `idPubli=${publiId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const likeCount = this.nextElementSibling;
                        likeCount.textContent = data.nuevoConteo;
                        
                        if (isLiked) {
                            this.classList.remove('bi-heart-fill', 'text-danger');
                            this.classList.add('bi-heart', 'text-secondary');
                        } else {
                            this.classList.remove('bi-heart', 'text-secondary');
                            this.classList.add('bi-heart-fill', 'text-danger');
                        }
                    }
                });
            });
        });

        // Función para abrir modal de reporte (deberías implementarla según tu aplicación)
        function abrirReporteModal(tipo, id, nombre) {
            // Implementa esta función según tu aplicación
            console.log(`Reportar ${tipo} con ID ${id} y nombre ${nombre}`);
            // Aquí deberías mostrar tu modal de reporte
        }
    </script>
    <?php require_once("footer.html");?>
    <?php include("reportar_modal.php"); ?>
</body>
</html>